# SDK 0.2.31：通过 MCP 接入 Dota 2 项目

本指南用于将 `@eom/dota-platform-sdk` 0.2.31 嵌入现有 Dota 2 自定义游戏。MCP 服务复用 SDK 的项目识别、接入、校验、构建、加密和恢复接口；本地文件校验完成后，仍需在 Dota 2 中验证入口连接、大厅和战斗行为。

## 启动与连接

使用 Node.js 18.14.1 或更高版本，在 SDK 目录安装依赖。MCP 客户端通过 stdio 启动服务：

```json
{
  "mcpServers": {
    "eom-dota-platform": {
      "command": "node",
      "args": ["E:/Repository/dota-platform-sdk/scripts/mcp.cjs"]
    }
  }
}
```

将路径改为本机 SDK 的实际位置。SDK 包也提供 `eom-platform mcp`；源码仓库可运行 `npm run --silent mcp`。stdio 会话的标准输出用于 MCP 消息，通过 npm 启动时使用 `--silent` 隐藏命令横幅。此配置示例需要添加到所用 MCP 客户端中，不会自动修改客户端设置。

服务提供以下资源：

- `eom-platform://integration/guide`：本指南。
- `eom-platform://integration/config-example`：SDK 配置模板，其中 Workshop ID 和示例地址需要替换。
- 提示词 `integrate_dota_project`：传入项目绝对路径 `target`，取得接入工作指引。

## 接入现有项目

1. **识别项目。** 调用 `platform_discover`，传入游戏项目的绝对路径。确认 addon、服务端和客户端 Lua 入口，以及可用构建脚本。`content/<addon>`／`game/<addon>` 使用默认 `integration.layout: "flat"`；`content/dota_addons/<addon>`／`game/dota_addons/<addon>` 使用 `integration.layout: "dota_addons"`，以识别结果的 `layout` 为准。多个 addon 时明确选择目标。服务端入口必须存在；缺少客户端入口时 SDK 可生成。目录联接和符号链接在运行时自动识别，不需要写入配置。

2. **准备并检查配置。** 从配置资源取得模板，填写 `addon`、数字形式的 `workshopId`、`displayName` 的 `schinese`／`english`／`russian` 三语名称，以及至少一个大厅游戏服务器的 `host:port`。`lobbies` 的 key 为 `china`、`overseas`、`overseas2`。设置 `connection.region` 为已配置节点，使用 `integration.mode: "auto"`，再调用 `platform_validate_config`。可将配置保存为项目根目录的 `platform.config.json`；各项目工具省略 `config` 时读取此文件，显式传入 `config` 时使用该对象。

3. **检查当前接入状态。** 调用 `platform_project_status`，查看已安装版本、文件校验、加密状态和还原记录。若已有加密产物，先按下文恢复明文。停止项目的持续 watch 进程，再执行接入或构建。

4. **选择构建或接入。** 原项目尚未构建，或需要重新构建时，配置 `pipeline.build` 并调用 `platform_build`。此流程依次执行原项目构建、SDK 接入、文件校验、资源编译、必需编译产物校验和 `pipeline.package`。自动内嵌默认识别 Dota 2 开发工具并编译资源；`pipeline.compile` 为可选覆盖命令。已有可用构建产物时，调用 `platform_preview`，使用 `action: "install"`；检查返回的新增、覆盖、删除文件及目录清理信息后，将 `previewId` 传给 `platform_apply`。

5. **读取任务结果。** `platform_build` 和 `platform_apply` 返回任务 ID；调用 `platform_job`，直到状态为 `succeeded` 或 `failed`。查看 `report`、`log` 和错误信息。自动接入、同步和初始化后默认编译平台资源；关闭时按记录还原编译产物，并执行已配置的自定义编译命令。找不到开发工具、编译失败或必需产物缺失、为空时，任务失败并停止后续打包；已经应用的文件接入或恢复仍然生效。修复后调用 `platform_compile` 单独重新编译，再查询其任务结果。未配置的打包阶段返回 `not_configured`。

6. **复核与实机验证。** 调用 `platform_project_status` 确认文件状态，再在 Dota 2 中检查平台入口自动连接、区服切换、大厅、战斗地图和返回大厅。`requires_server_deployment` 表示仍需按返回信息配置大厅服务器；本 MCP 不执行远端部署。

7. **检查发布包。** 打包后调用 `platform_check_package`，传入最终 Workshop VPK 的绝对路径 `file`。`ready` 表示本地源文件校验通过且 8 项必需 Panorama 编译产物存在、非空；`needs-compile` 表示必需编译产物缺失或为空。实际 VPK 仍须包含动态加载的 `eom_platform/loading.vxml_c`、HUD 布局和相应脚本、样式、Lua 引导文件。缺资源会使检查失败。重新打包后复查新包，再上传；复用旧 VPK 不会带上新编译的资源。命令行等价命令为 `eom-platform check-package --package <VPK绝对路径>`。

自定义构建阶段使用有限执行的命令。Windows 配置示例（资源编译使用默认流程）：

```json
{
  "pipeline": {
    "build": [{ "command": "npm.cmd", "args": ["run", "build"] }],
    "package": []
  }
}
```

命令工作目录为游戏项目根目录。将 `build` 替换为原项目真实的一次性构建脚本；打包命令按项目填写。SDK 自动查找项目对应的 Dota 安装及 Steam 游戏库，要求 content/game addon 挂载指向项目，编译器由 Dota 2 Workshop Tools 提供。`.cmd`／`.bat` 参数须符合 SDK 的 shell 元字符限制。

## 更新、同步和关闭接入

项目自行构建后，可能覆盖 SDK 包装入口。优先使用 `platform_build` 完成构建和重新接入；若已经单独构建并确认产物为新的原生玩法入口，使用 `platform_preview` 的 `action: "sync"`，核对后执行。升级和同步仍校验文件冲突：`sync` 将新构建产物作为还原基线；普通 `install` 会阻止覆盖已被改动的托管文件。

预览 ID 仅在产生它的 MCP 会话中有效，30 分钟后过期，提交执行时即消耗。文件、配置或相关接入输入变化后，应重新预览。预览和执行期间保留项目路径及声明的挂载目标。

预览和任务记录保存在当前服务进程内，分别保留最近 32 条；重启服务后旧 ID 失效。项目中的接入和加密备份继续保留，可用新会话读取项目状态并重新预览。

关闭接入时，先预览 `action: "restore"`，再执行返回的 `previewId`。SDK 校验 `.eom-platform/<addon>/` 的完整记录后，恢复被覆盖的原文件、移除 SDK 新增文件和备份，并清理 SDK 创建的空目录。开启期间对 SDK 管理文件的修改或删除不予保留，关闭结果以还原记录为准；用户后来新增的独立文件保留。保留此管理目录直到关闭完成；还原记录损坏或旧版缺少完整记录时，应先解决问题。已有加密状态先恢复明文。SDK 运行时保存的原玩法入口副本随 addon 发布，管理备份无需发布。

默认资源编译自动登记 Panorama 产物以供还原。使用自定义 `pipeline.compile` 时，项目编译器须调用 `scripts/build-outputs.cjs` 的 `captureBuildOutputs` 和 `recordBuildOutputs` 才会纳入还原记录：编译前捕获目标文件，编译后登记结果，失败时也登记部分输出。未登记的自定义编译产物需要项目自行重新编译或恢复。

内置 `scripts/compile-panorama.cjs` 将动态加载的平台 XML、JS、CSS 显式传给 `resourcecompiler` 强制编译，再检查 8 项必需产物存在且非空；SDK 图片通过样式依赖生成。整个过程无需启动 Dota 或先加载界面。命令行可用 `eom-platform compile --target <项目绝对路径> --config <项目配置JSON>` 单独执行默认或自定义的编译阶段。

项目已有繁体中文源目录或提供 `displayName.tchinese` 时，接入也会生成繁体中文 SDK 源 VDF 和翻译输出。

新建空项目可使用 `action: "init"`；目标目录必须为空，并通过 `config` 参数传入配置。关闭新建项目的 SDK 接入后会保留原生项目骨架。

已有手动 TUI 接入时，在配置中显式选择 `integration.migration: "legacy-tui"`，保留原来的 `battleServer`、`battleClient` 和 `panorama.battleLoadingLayout`，再执行预览。普通自动接入项目无需填写这些旧模板字段。

## 可选 Lua 加密

完成构建、接入和校验后，使用 `platform_preview` 的 `action: "encrypt"`，通过 `legacyConfig` 指定项目内的加密配置 JS 相对路径；默认文件为 `encrypt-custom-game-config.js`，项目中同时需要已有的 `aes.lua`。核对预览后执行并查询任务结果。密钥由本地加密配置提供，不填入平台 JSON 或 MCP 参数。

加密配置在独立子进程加载，预览最多运行 30 秒，实际加密或恢复最多运行 5 分钟。超时会终止子进程并报告错误；重试前先核查项目文件与备份状态。

需要加密交付时，将完整构建中的 `pipeline.package` 留空；完成接入与加密后，使用项目自身的打包命令生成加密产物。打包、上传完成，再预览并执行 `action: "restore-encryption"` 恢复明文，之后继续开发。重新构建、更新 SDK 或关闭接入前也必须先恢复明文。加密记录与原文件保存在 `.eom-platform/<addon>/encryption.json` 和 `encryption-original/`；恢复会先检查文件冲突。`debug: true` 会将测试密钥写入产物，仅用于本地测试。

## 接入后的源码约定

SDK 在编译产物中包装 Lua 入口及 Panorama 加载、选队布局。平台地图 `platform_entry`、`platform_lobby` 初始化 SDK 并停留在 `CUSTOM_GAME_SETUP`；战斗地图执行保存的原玩法入口。修改玩法时编辑原 TypeScript／TSX／Lua 源文件，再使用项目构建流程接入。

玩家可见的 UI 文本写入 `content/<addon>/localization/schinese/**/*.vdf`，同步项目支持的其他语言，并从 UI 引用本地化 token。`game/<addon>/resource/addon_*.txt` 是生成输出；修改源 VDF 后重新生成。SDK 接入使用各语言的 `eom_platform.vdf`。

编辑 `.tsx` 时，父开始标签、子元素、父结束标签分别换行，子元素缩进一级，每个兄弟元素单独一行，自闭合标签在 `/>` 前保留空格：

```tsx
<Panel class="TDBHeader">
    <Label class="TDBTitle" text={loc('title')} />
    <Label text={loc('prototype')} />
</Panel>
```

## MCP 工具参考

| 工具 | 参数 | 结果或用途 |
| --- | --- | --- |
| `platform_integration_guide` | 无 | 读取接入指南 |
| `platform_discover` | `target` | 发现 addon、入口、挂载和 npm 脚本 |
| `platform_validate_config` | `config` | 校验 SDK 配置 |
| `platform_project_status` | `target`、可选 `config` | 接入版本、明文或加密状态、文件校验与服务器部署信息 |
| `platform_preview` | `target`、`action`、可选 `config`／`legacyConfig` | 生成操作预览和 `previewId`；`action` 为 `init`、`install`、`sync`、`restore`、`encrypt` 或 `restore-encryption` |
| `platform_apply` | `previewId` | 复核并执行同一会话的预览，返回任务 ID |
| `platform_build` | `target`、可选 `config` | 执行项目完整构建流程，返回任务 ID |
| `platform_compile` | `target`、可选 `config` | 单独执行资源编译和必需产物校验，返回任务 ID |
| `platform_job` | `jobId` | 查询任务状态、日志、执行报告或错误 |
| `platform_check_package` | `file`：最终 VPK 绝对路径 | 检查发布包的必需平台资源，返回 `ok`、缺失或不可读文件；失败时 MCP 返回错误结果 |

本 MCP 操作本地目标项目。构建和编译会执行所用配置中的命令，加密预览会加载项目内的 JS 配置；使用前确认项目路径和配置来自目标项目。工具成功表示相应文件或命令操作成功，连接握手和游戏行为以实机结果为准。

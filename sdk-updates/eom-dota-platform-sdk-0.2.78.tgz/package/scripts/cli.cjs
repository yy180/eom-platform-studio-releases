#!/usr/bin/env node
const fs = require('node:fs');
const { restore } = require('./automatic.cjs');
const { buildProject, installProject, compileProject, inspect, discover } = require('./pipeline.cjs');
const { resolveProjectPaths, getProjectMounts } = require('./project-paths.cjs');

async function main() {
	const [command, ...args] = process.argv.slice(2);
	if (command === 'check-package') {
		if (args.length !== 2 || args[0] !== '--package') throw new Error('Usage: eom-platform check-package --package <absolute VPK path>');
		const report = require('./check-package.cjs').checkPackage(args[1]);
		console.log(JSON.stringify(report, null, 2));
		if (!report.ok) process.exitCode = 1;
		return;
	}
	if (command === 'mcp') {
		if (args.length) throw new Error('Usage: eom-platform mcp');
		await require('./mcp.cjs').start();
		return;
	}
	if (command === 'studio') {
		if (args.length) throw new Error('Usage: eom-platform studio (set PORT to change the port)');
		const report = await require('./studio-launcher.cjs').launch({ fallbackRoot: require('node:path').resolve(__dirname, '..') });
		process.exitCode = report.exitCode;
		return;
	}
	if (!['init', 'install', 'build', 'compile', 'check', 'restore', 'discover', 'encrypt', 'restore-encryption'].includes(command)) throw new Error('Usage: eom-platform mcp | studio | <init|install|build|compile|check|restore|discover|encrypt|restore-encryption> --target <directory> [--config <json>] [--legacy-config <js>] [--dry-run]');
	const options = {};
	for (let index = 0; index < args.length; index++) {
		if (args[index] === '--dry-run') options.dryRun = true;
		else if (['--target', '--config', '--legacy-config'].includes(args[index]) && args[index + 1] && !args[index + 1].startsWith('--')) options[args[index++].slice(2)] = args[index];
		else throw new Error('Unknown or incomplete argument: ' + args[index]);
	}
	if (!options.target || (command !== 'discover' && !options.config)) throw new Error('--target and --config are required');
	if (command === 'discover') return console.log(JSON.stringify(discover(options.target), null, 2));
	options.target = fs.existsSync(options.target) ? fs.realpathSync(options.target) : require('node:path').resolve(options.target);
	const config = resolveProjectPaths(require('node:path').resolve(options.target), JSON.parse(fs.readFileSync(options.config, 'utf8')));
	if (command === 'encrypt' || command === 'restore-encryption') {
		require('./install.cjs').validate(config);
		const encryption = require('./lua-encryption.cjs');
		if (command === 'encrypt') {
			if (!options['legacy-config']) throw new Error('encrypt requires --legacy-config <project encryption config.js>');
			inspect(options.target, config);
			return console.log(JSON.stringify(encryption.encryptProject(options.target, config, require(require('node:path').resolve(options['legacy-config'])), { dryRun: options.dryRun }), null, 2));
		}
		return console.log(JSON.stringify(encryption.restoreEncryption(options.target, config, { dryRun: options.dryRun }), null, 2));
	}
	if (options.dryRun && ['build', 'compile', 'check'].includes(command)) throw new Error('--dry-run is supported by init, install and restore');
	if (command === 'compile') {
		require('./install.cjs').validate(config);
		const target = require('node:path').resolve(options.target);
		require('./project-activity.cjs').assertNoWatchers(target);
		const encryption = require('./automatic.cjs').safePath(target, '.eom-platform/' + config.addon + '/encryption.json', getProjectMounts(config));
		if (fs.existsSync(encryption)) throw new Error('Restore encrypted outputs with restore-encryption before compiling');
		return console.log(JSON.stringify(await compileProject(target, config, { log: text => process.stderr.write(text) }), null, 2));
	}
	const report = command === 'build' ? await buildProject(options.target, config, { log: text => process.stderr.write(text) })
		: command === 'check' ? inspect(options.target, config)
		: command === 'restore' ? restore(options.target, config, { dryRun: options.dryRun })
		: await installProject(options.target, config, { initialize: command === 'init', dryRun: options.dryRun, log: text => process.stderr.write(text) });
	console.log(JSON.stringify(report, null, 2));
}

main().catch(error => { console.error(error.message); process.exitCode = 1; });

'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { TextDecoder } = require('node:util');

const MAX_TREE_BYTES = 64 * 1024 * 1024;
const MAX_READ_BYTES = 256 * 1024 * 1024;
const embeddedArchive = 0x7fff;

function readExact(fd, bytes, position) {
	let offset = 0;
	while (offset < bytes.length) {
		const count = fs.readSync(fd, bytes, offset, bytes.length - offset, position + offset);
		if (count === 0) throw new Error('Truncated VPK data');
		offset += count;
	}
	return bytes;
}

function resourcePath(relative) {
	if (typeof relative !== 'string' || !relative) throw new Error('Invalid VPK resource path');
	const normalized = relative.replace(/\\/g, '/');
	if (/[:\x00-\x1f]/.test(normalized) || normalized.split('/').some(part => !part || part === '.' || part === '..')) throw new Error('Invalid VPK resource path: ' + relative);
	return normalized;
}

// Parse only the bounded directory tree; archive bodies are read on demand.
function openVpk(input) {
	const file = path.resolve(input);
	const fd = fs.openSync(file, 'r');
	let version, headerSize, treeSize, dataSize;
	const entries = new Map();
	try {
		const stats = fs.fstatSync(fd);
		if (!stats.isFile() || !Number.isSafeInteger(stats.size)) throw new Error('Expected a regular VPK file');
		const header = readExact(fd, Buffer.alloc(12), 0);
		if (header.readUInt32LE(0) !== 0x55aa1234) throw new Error('Invalid VPK signature');
		version = header.readUInt32LE(4);
		headerSize = version === 1 ? 12 : version === 2 ? 28 : 0;
		if (!headerSize) throw new Error('Unsupported VPK version: ' + version);
		treeSize = header.readUInt32LE(8);
		if (treeSize > MAX_TREE_BYTES) throw new Error('VPK directory tree exceeds 64 MiB');
		if (headerSize + treeSize > stats.size) throw new Error('Truncated VPK directory tree');
		dataSize = stats.size - headerSize - treeSize;
		if (version === 2) {
			const sections = readExact(fd, Buffer.alloc(16), 12);
			dataSize = sections.readUInt32LE(0);
			const total = headerSize + treeSize + dataSize + sections.readUInt32LE(4) + sections.readUInt32LE(8) + sections.readUInt32LE(12);
			if (total > stats.size) throw new Error('Truncated VPK sections');
		}
		const tree = readExact(fd, Buffer.alloc(treeSize), headerSize);
		const decoder = new TextDecoder('utf-8', { fatal: true });
		let cursor = 0;
		function string() {
			const end = tree.indexOf(0, cursor);
			if (end < 0) throw new Error('Truncated VPK tree string');
			if (end - cursor > 32768) throw new Error('VPK tree string exceeds 32 KiB');
			const value = decoder.decode(tree.subarray(cursor, end));
			cursor = end + 1;
			return value;
		}
		for (let extension; (extension = string()) !== '';) {
			if (/[\\/]/.test(extension)) throw new Error('Invalid VPK extension');
			for (let directory; (directory = string()) !== '';) {
				for (let name; (name = string()) !== '';) {
					if (/[\\/]/.test(name)) throw new Error('Invalid VPK file name');
					if (cursor + 18 > tree.length) throw new Error('Truncated VPK entry');
					const crc = tree.readUInt32LE(cursor), preloadLength = tree.readUInt16LE(cursor + 4);
					const archive = tree.readUInt16LE(cursor + 6), offset = tree.readUInt32LE(cursor + 8), length = tree.readUInt32LE(cursor + 12);
					if (tree.readUInt16LE(cursor + 16) !== 0xffff) throw new Error('Invalid VPK entry terminator');
					cursor += 18;
					if (cursor + preloadLength > tree.length) throw new Error('Truncated VPK preload data');
					if (archive === embeddedArchive && offset + length > dataSize) throw new Error('VPK entry exceeds embedded data section');
					const preload = Buffer.from(tree.subarray(cursor, cursor + preloadLength));
					cursor += preloadLength;
					const relative = resourcePath((directory === ' ' ? '' : directory + '/') + name + (extension === ' ' ? '' : '.' + extension));
					const key = relative.toLowerCase();
					if (entries.has(key)) throw new Error('Duplicate VPK entry: ' + relative);
					entries.set(key, { relative, crc, archive, offset, length, preload });
				}
			}
		}
		if (tree.subarray(cursor).some(byte => byte !== 0)) throw new Error('Unexpected trailing VPK directory data');
	} finally { fs.closeSync(fd); }

	function read(relative) {
		const entry = entries.get(resourcePath(relative).toLowerCase());
		if (!entry) return null;
		if (entry.length + entry.preload.length > MAX_READ_BYTES) throw new Error('VPK resource exceeds 256 MiB read limit: ' + relative);
		if (entry.length === 0) return Buffer.from(entry.preload);
		if (entry.archive !== embeddedArchive && !/\.vpk$/i.test(file)) throw new Error('External VPK archive requires a .vpk directory file');
		const archive = entry.archive === embeddedArchive ? file : file.replace(/(?:_dir)?\.vpk$/i, '_' + String(entry.archive).padStart(3, '0') + '.vpk');
		const stream = fs.openSync(archive, 'r');
		try {
			const position = entry.offset + (entry.archive === embeddedArchive ? headerSize + treeSize : 0);
			if (position + entry.length > fs.fstatSync(stream).size) throw new Error('Truncated VPK resource: ' + relative);
			const bytes = readExact(stream, Buffer.alloc(entry.length), position);
			return Buffer.concat([entry.preload, bytes]);
		} finally { fs.closeSync(stream); }
	}
	return { version, entries, read };
}

module.exports = { openVpk };

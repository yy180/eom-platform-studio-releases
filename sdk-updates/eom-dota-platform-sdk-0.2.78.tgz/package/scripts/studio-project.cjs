const fs = require('node:fs');
const path = require('node:path');
const { safePath, hash, restorationStatus } = require('./automatic.cjs');
const { validate } = require('./install.cjs');
const { inspect, normalizeCompileConfig } = require('./pipeline.cjs');
const { serverDeployment } = require('./deployment.cjs');

const { addonRoots, resolveProjectPaths, getProjectMounts, portableProjectConfig } = require('./project-paths.cjs');
const { inspectCompiledResources } = require('./platform-resources.cjs');

function projectTarget(root, input) {
	if (typeof input.target !== 'string' || !input.target.trim()) throw new Error('请填写项目目录');
	const selected = path.resolve(root, input.target);
	const target = fs.existsSync(selected) ? fs.realpathSync(selected) : selected;
	if (target === fs.realpathSync(root)) throw new Error('请选择游戏项目目录，不能使用 SDK 仓库本身');
	return target;
}

function projectConfig(root, input) {
	const target = projectTarget(root, input);
	const file = safePath(target, 'platform.config.json');
	const config = resolveProjectConfig(target, JSON.parse(fs.readFileSync(file, 'utf8')));
	return { target, config, path: file };
}

function resolveProjectConfig(target, stored) {
	const config = normalizeCompileConfig(portableProjectConfig(stored));
	validate(config);
	return resolveProjectPaths(target, config);
}

function projectStatus(root, input) {
	validate(input.config);
	const target = projectTarget(root, input);
	input = { ...input, config: resolveProjectPaths(target, input.config) };
	const resolve = file => safePath(target, file, getProjectMounts(input.config));
	const manifestFile = addonRoots(input.config).game + '/scripts/eom_platform_manifest.json';
	const encryptionFile = '.eom-platform/' + input.config.addon + '/encryption.json';
	const manifestExists = fs.existsSync(resolve(manifestFile));
	const installed = manifestExists && (input.config.integration?.mode === 'manual' || fs.existsSync(resolve('.eom-platform/' + input.config.addon + '/state.json')));
	const encrypted = fs.existsSync(resolve(encryptionFile));
	const encryption = encrypted ? JSON.parse(fs.readFileSync(resolve(encryptionFile), 'utf8')) : null;
	let manifest = null, validation = null, compiledPanorama = null, error = null;
	try {
		if (manifestExists) manifest = JSON.parse(fs.readFileSync(resolve(manifestFile), 'utf8'));
		if (installed) {
			validation = inspect(target, input.config);
			if (input.config.integration?.mode !== 'manual') compiledPanorama = inspectCompiledResources(target, input.config);
		}
	}
	catch (problem) { error = problem.message; }
	return { target, installed, encrypted, version: manifest?.version ?? null, checked: validation?.checked ?? 0, serverDeployment: serverDeployment(input.config),
		embedding: restorationStatus(target, input.config),
		encryptedModules: encryption?.encrypted.length ?? 0, compiledPanorama, error,
		state: error ? (encrypted ? 'encryption-conflict' : 'needs-sync') : compiledPanorama && !compiledPanorama.ok ? 'needs-compile' : encrypted ? 'encrypted' : installed ? 'ready' : 'uninitialized' };
}

function projectMaps(root, input) {
	const target = projectTarget(root, input), config = resolveProjectPaths(target, input.config);
	const file = addonRoots(config).game + '/addoninfo.txt';
	const resolve = relative => safePath(target, relative, getProjectMounts(config));
	if (!fs.existsSync(resolve(file))) return { maps: [], source: file };
	let data = fs.readFileSync(resolve(file));
	const stateFile = resolve('.eom-platform/' + config.addon + '/state.json');
	if (fs.existsSync(stateFile)) {
		const state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
		if (state.generated?.[file] === hash(data)) {
			const original = state.originals?.[file];
			if (!original?.backup) throw new Error('缺少原始 addoninfo.txt 备份');
			data = fs.readFileSync(resolve(original.backup));
			if (hash(data) !== original.sha256) throw new Error('原始 addoninfo.txt 备份已变化');
		}
	}
	return { maps: require('./addon-info.cjs').addonMaps(data.toString('utf8')), source: file };
}

function prepareEncryption(root, input) {
	const { encryptProject, restoreEncryption } = require('./lua-encryption.cjs');
	if (!['encrypt', 'restore-encryption'].includes(input.action)) throw new Error('未知加密操作');
	validate(input.config);
	const target = projectTarget(root, input);
	input = { ...input, config: resolveProjectPaths(target, input.config) };
	const resolve = file => safePath(target, file, getProjectMounts(input.config));
	const files = new Map();
	const snapshot = file => {
		const full = resolve(file);
		files.set(file, fs.existsSync(full) ? hash(fs.readFileSync(full)) : null);
	};
	const encryptionFile = '.eom-platform/' + input.config.addon + '/encryption.json';
	let report, legacy;
	if (input.action === 'encrypt') {
		inspect(target, input.config);
		const legacyFile = input.legacyConfig || 'encrypt-custom-game-config.js';
		if (!/\.(?:js|cjs)$/.test(legacyFile)) throw new Error('请选择项目内的加密配置 JS 文件');
		const legacyPath = resolve(legacyFile);
		delete require.cache[require.resolve(legacyPath)];
		legacy = require(legacyPath);
		snapshot(legacyFile);
		snapshot('aes.lua');
		const visit = (relative, ancestors = new Set()) => {
			const full = resolve(relative), real = fs.realpathSync(full);
			if (ancestors.has(real)) throw new Error('Lua 目录存在循环链接：' + relative);
			const next = new Set([...ancestors, real]);
			for (const name of fs.readdirSync(full).sort()) {
				const file = relative + '/' + name;
				if (fs.statSync(resolve(file)).isDirectory()) visit(file, next);
				else if (file.endsWith('.lua')) snapshot(file);
			}
		};
		visit(addonRoots(input.config).game + '/scripts/vscripts');
		report = encryptProject(target, input.config, legacy, { dryRun: true });
	} else {
		report = restoreEncryption(target, input.config, { dryRun: true });
		const state = JSON.parse(fs.readFileSync(resolve(encryptionFile), 'utf8'));
		for (const [file, item] of Object.entries(state.originals)) {
			snapshot(file);
			if (item.backup) snapshot(item.backup);
		}
	}
	snapshot(encryptionFile);
	const manifestFile = addonRoots(input.config).game + '/scripts/eom_platform_manifest.json';
	snapshot(manifestFile);
	if (fs.existsSync(resolve(manifestFile))) {
		for (const item of JSON.parse(fs.readFileSync(resolve(manifestFile), 'utf8')).files) snapshot(item.file);
	}
	const signature = hash(Buffer.from(JSON.stringify([input, getProjectMounts(input.config), [...files], legacy])));
	const luaRoot = addonRoots(input.config).game + '/scripts/vscripts/';
	const affected = [...files.keys()].filter(file => file.startsWith(luaRoot) && file.endsWith('.lua'));
	if (input.action === 'encrypt' && !affected.includes(luaRoot + 'encrypt.lua')) affected.push(luaRoot + 'encrypt.lua');
	return {
		preview: { action: input.action, target, signature, files: affected.sort(),
			encrypted: report.encrypted?.length, publicModules: report.publicModules?.length, restored: report.restored },
		execute: () => input.action === 'encrypt' ? encryptProject(target, input.config, legacy) : restoreEncryption(target, input.config),
	};
}

module.exports = { projectTarget, projectConfig, resolveProjectConfig, projectStatus, projectMaps, prepareEncryption };

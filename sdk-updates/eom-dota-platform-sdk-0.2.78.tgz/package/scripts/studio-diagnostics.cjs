'use strict';
const fs = require('node:fs');
const os = require('node:os');
const crypto = require('node:crypto');
const { writePlan } = require('./write-plan.cjs');

const MAX_REPORT_BYTES = 256 * 1024;
const escape = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function reportEndpoint(value) {
	if (!value) return null;
	const url = new URL(value);
	const local = ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname);
	if (url.protocol !== 'https:' && !(url.protocol === 'http:' && local) || url.username || url.password || url.search || url.hash) throw new Error('日志接收地址必须是不含凭据和查询参数的 HTTPS 地址');
	return url.href;
}

function redact(value, roots = []) {
	let text = String(value ?? '').replace(/\x1b\[[0-9;]*m/g, '');
	text = text.replace(/-----BEGIN [^-]*(?:PRIVATE KEY|CERTIFICATE)-----[\s\S]*?-----END [^-]+-----/g, '<REDACTED>');
	text = text.replace(/\bBearer\s+[a-z0-9._~+\/-]+=*/gi, 'Bearer <REDACTED>');
	text = text.replace(/((?:["']?)[\w-]*(?:token|secret|password|passwd|api[_-]?key|private[_-]?key|server[_-]?key|dedicated[_-]?key|cookie|authorization|\bkey)[\w-]*["']?\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;}\]]+)/gi, '$1"<REDACTED>"');
	text = text.replace(/(--[\w-]*(?:token|secret|password|key)[\w-]*\s+)(?:"[^"]*"|'[^']*'|[^\s]+)/gi, '$1<REDACTED>');
	text = text.replace(/https?:\/\/[^\s<>"']+/gi, raw => {
		try { const url = new URL(raw); url.username = ''; url.password = ''; const query = url.search; url.search = ''; url.hash = ''; return url.href + (query ? '?<REDACTED>' : ''); } catch { return '<URL>'; }
	});
	for (const root of [...new Set([...roots, os.homedir()])].filter(Boolean).sort((a, b) => b.length - a.length)) {
		text = text.replace(new RegExp(root.split(/[\\/]+/).map(escape).join('[\\\\/]'), process.platform === 'win32' ? 'gi' : 'g'), '<LOCAL>');
	}
	text = text.replace(/\b[a-z]:[\\/][^\r\n"'<>|]*/gi, '<PATH>').replace(/\\\\[^\r\n"'<>|]+/g, '<PATH>');
	text = text.replace(/\/(?:home|Users)\/[^/\s]+/g, '/<USER>');
	return text.replace(/\b\d{1,3}(?:\.\d{1,3}){3}\b/g, '<IP>').replace(/\[[0-9a-f]*:[0-9a-f:]+\]/gi, '[<IP>]');
}

function createDiagnostics({ workspaceFile, version, endpoint, roots = [], request = fetch, now = Date.now, launcherLog } = {}) {
	endpoint = reportEndpoint(endpoint);
	let state = { schema: 1, automatic: false, events: [] }, storageError = null, sending = false, lastAutomatic = 0;
	const previews = new Map();
	try {
		const file = workspaceFile('diagnostics.json');
		if (fs.existsSync(file)) {
			const saved = JSON.parse(fs.readFileSync(file, 'utf8'));
			if (saved.schema !== 1 || typeof saved.automatic !== 'boolean' || !Array.isArray(saved.events)) throw new Error('日志记录格式无效');
			state = { schema: 1, automatic: saved.automatic && saved.consentedEndpoint === endpoint, consentedEndpoint: saved.consentedEndpoint,
				events: saved.events.slice(-40), lastUpload: saved.lastUpload?.reportId && typeof saved.lastUpload.reportId === 'string' ? { reportId: saved.lastUpload.reportId.slice(0, 40), at: String(saved.lastUpload.at).slice(0, 40) } : null,
				uploadError: typeof saved.uploadError === 'string' ? redact(saved.uploadError, roots).slice(0, 1024) : null };
		}
	} catch (error) { storageError = redact(error.message, roots); }
	const clean = (text, limit) => redact(text, roots).slice(-limit);
	function persist() {
		if (storageError) return false;
		try {
			while (state.events.length && (state.events.length > 40 || Buffer.byteLength(JSON.stringify(state)) > 512 * 1024)) state.events.shift();
			writePlan([{ destination: workspaceFile('diagnostics.json'), data: Buffer.from(JSON.stringify(state, null, 2) + '\n') }]);
			return true;
		} catch (error) { storageError = clean(error.message, 1024); return false; }
	}
	function preview(description = '') {
		if (typeof description !== 'string' || description.length > 1000) throw new Error('问题说明最多 1000 个字符');
		let log = '';
		if (launcherLog) try {
			if (!fs.lstatSync(launcherLog).isSymbolicLink()) {
				const descriptor = fs.openSync(launcherLog, 'r');
				try {
					const size = fs.fstatSync(descriptor).size, bytes = Buffer.alloc(Math.min(size, 32768));
					fs.readSync(descriptor, bytes, 0, bytes.length, Math.max(0, size - bytes.length));
					log = clean(bytes.toString('utf8').split('\n').slice(size > bytes.length ? 1 : 0).join('\n'), 32768);
				} finally { fs.closeSync(descriptor); }
			}
		} catch { /* Launcher logs are optional when the tool starts from source. */ }
		const report = { schema: 1, application: 'eom-platform-studio', reportId: crypto.randomUUID(), createdAt: new Date(now()).toISOString(), version,
			platform: process.platform, arch: process.arch, node: process.versions.node, description: clean(description, 1000),
			events: state.events.map(item => ({ at: clean(item?.at, 40), source: clean(item?.source, 40), operation: clean(item?.operation, 160),
				message: clean(item?.message, 4096), stack: clean(item?.stack, 4096), log: clean(item?.log, 12000) })), launcherLog: log };
		while (Buffer.byteLength(JSON.stringify(report)) > MAX_REPORT_BYTES && report.events.length) report.events.shift();
		previews.set(report.reportId, { report, at: now() });
		while (previews.size > 5) previews.delete(previews.keys().next().value);
		return report;
	}
	async function upload({ reportId, consent } = {}) {
		if (consent !== true) throw new Error('请先同意上传诊断日志');
		if (!endpoint) throw new Error('开发者尚未配置日志接收服务，可先导出日志文件');
		const selected = previews.get(reportId);
		if (!selected || now() - selected.at > 10 * 60 * 1000) throw new Error('请重新查看待发送日志后再上传');
		if (sending) throw new Error('错误报告正在上传');
		sending = true;
		try {
			const response = await request(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(selected.report), redirect: 'error', signal: AbortSignal.timeout(15000) });
			if (!response.ok) throw new Error('日志接收服务返回 ' + response.status);
			const result = await response.json();
			if (typeof result.reportId !== 'string' || result.reportId !== reportId) throw new Error('日志接收服务未返回有效的报告编号');
			state.lastUpload = { reportId, at: new Date(now()).toISOString() };
			delete state.uploadError;
			persist();
			return state.lastUpload;
		} catch (error) {
			state.uploadError = clean(error.message, 1024);
			persist();
			throw new Error('错误报告未能上传，本地日志已保留：' + state.uploadError);
		} finally { sending = false; }
	}
	return {
		state: () => ({ enabled: !!endpoint, endpoint, automatic: state.automatic, count: state.events.length, lastUpload: state.lastUpload ?? null, error: state.uploadError ?? storageError, storageError, sending }),
		setAutomatic(enabled) {
			if (typeof enabled !== 'boolean') throw new Error('请选择是否自动上传错误日志');
			if (enabled && !endpoint) throw new Error('开发者尚未配置日志接收服务');
			const before = state.automatic;
			const previousEndpoint = state.consentedEndpoint;
			state.automatic = enabled;
			state.consentedEndpoint = enabled ? endpoint : null;
			if (!persist()) { state.automatic = before; state.consentedEndpoint = previousEndpoint; throw new Error('无法保存日志上传偏好：' + storageError); }
			return this.state();
		},
		record(source, details = {}) {
			const event = { at: new Date(now()).toISOString(), source: clean(source, 40), operation: clean(details.operation, 160),
				message: clean(details.message, 4096), stack: clean(details.stack, 4096), log: clean(details.log, 12000) };
			const previous = state.events.at(-1);
			if (previous && previous.source === event.source && previous.message === event.message && previous.operation === event.operation && now() - Date.parse(previous.at) < 10000) return;
			state.events.push(event);
			persist();
			if (state.automatic && endpoint && !sending && now() - lastAutomatic >= 60000) {
				lastAutomatic = now();
				const report = preview();
				upload({ reportId: report.reportId, consent: true }).catch(() => {});
			}
		},
		preview, upload,
	};
}

module.exports = { createDiagnostics, reportEndpoint, redact, MAX_REPORT_BYTES };

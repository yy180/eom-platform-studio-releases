const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { mergeEvents, parseKV } = require('./kv.cjs');
const { retainedMaps, mergeKV3AddonInfo } = require('./addon-info.cjs');
const { assertNoWatchers } = require('./project-activity.cjs');
const { addonRoots, resolveProjectPaths, getProjectMounts } = require('./project-paths.cjs');
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
const marker = '-- EOM SDK managed entry v1';

function safePath(target, relative, mounts = {}) {
	if (typeof relative !== 'string' || !relative || relative.includes('\\') || relative.split('/').some(part => !part || part === '..' || part === '.') || path.isAbsolute(relative)) throw new Error('Invalid project-relative path: ' + relative);
	const destination = path.resolve(target, relative);
	if (!destination.startsWith(path.resolve(target) + path.sep)) throw new Error('Path escapes target: ' + relative);
	let current = destination;
	while (true) {
		if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) {
			const key = path.relative(path.resolve(target), current).replace(/\\/g, '/');
			const declared = mounts[key] ?? (process.platform === 'win32' ? Object.entries(mounts).find(([name]) => name.toLowerCase() === key.toLowerCase())?.[1] : undefined);
			const normalize = value => process.platform === 'win32' ? value.toLowerCase() : value;
			if (!declared || !path.isAbsolute(declared) || normalize(fs.realpathSync(current)) !== normalize(path.resolve(declared))) throw new Error('Project symlinks/junctions point outside addon directories or their targets changed: ' + current);
		}
		const parent = path.dirname(current);
		if (parent === current) break;
		current = parent;
	}
	return fs.existsSync(destination) && fs.lstatSync(destination).isSymbolicLink() ? fs.realpathSync(destination) : destination;
}

function routeLayout(name, battle, platform) {
	return {
		xml: '<root>\n    <scripts>\n        <include src="file://{resources}/scripts/custom_game/eom_platform/integration/route.js" />\n        <include src="file://{resources}/scripts/custom_game/eom_platform/integration/' + name + '.js" />\n    </scripts>\n    <Panel style="width: 100%; height: 100%;" hittest="false" hittestchildren="true" />\n</root>\n',
		js: 'EOMPlatformRoute(' + JSON.stringify(battle) + ', ' + JSON.stringify(platform) + ');\n',
	};
}

function mergeAddonInfo(text, selected = []) {
	if (!text.includes('<!-- kv3 ')) return mergeLegacyAddonInfo(text, selected);
	return mergeKV3AddonInfo(text, selected);
}

function mergeLegacyAddonInfo(text, selected = []) {
	retainedMaps(text, selected);
	const roots = parseKV(text);
	if (roots.length !== 1 || roots[0].key.toLowerCase() !== 'addoninfo' || !roots[0].children) throw new Error('Expected AddonInfo KeyValues object');
	const root = roots[0], edits = [], newline = text.includes('\r\n') ? '\r\n' : '\n';
	let additions = '';
	function entry(object, name) {
		const matches = object.children.filter(item => item.key.toLowerCase() === name.toLowerCase());
		if (matches.length > 1) throw new Error('Duplicate addoninfo declaration: ' + name);
		return matches[0];
	}
	for (const [name, value] of [['maps', ['platform_entry', ...selected].join(' ')], ['DefaultMap', 'platform_entry']]) {
		const existing = entry(root, name), replacement = '"' + name + '" "' + value + '"';
		if (existing?.children) throw new Error('Expected scalar addoninfo.' + name);
		if (existing) edits.push({ start: existing.start, end: existing.end, text: replacement });
		else additions += '\t' + replacement + newline;
	}
	const platform = entry(root, 'platform_entry');
	if (platform) {
		if (!platform.children) throw new Error('Expected platform_entry map options object');
		let options = '';
		for (const name of ['MinPlayers', 'MaxPlayers']) {
			const existing = entry(platform, name), replacement = '"' + name + '" "1"';
			if (existing?.children) throw new Error('Expected scalar platform_entry.' + name);
			if (existing) edits.push({ start: existing.start, end: existing.end, text: replacement });
			else options += '\t\t' + replacement + newline;
		}
		if (options) edits.push({ start: platform.close, end: platform.close, text: newline + options + '\t' });
	} else additions += '\t"platform_entry"' + newline + '\t{' + newline + '\t\t"MinPlayers" "1"' + newline + '\t\t"MaxPlayers" "1"' + newline + '\t}' + newline;
	if (additions) edits.push({ start: root.close, end: root.close, text: newline + additions });
	for (const edit of edits.sort((left, right) => right.start - left.start)) text = text.slice(0, edit.start) + edit.text + text.slice(edit.end);
	return text;
}

// Build a complete write plan before any destination is changed. Originals live outside
// compiler outputs; the manifest detects both rebuilds and edits to managed wrappers.
function automatic(target, config, changes, { rebuilt = false, initializing = false } = {}) {
	config = resolveProjectPaths(target, config);
	const { content, game } = addonRoots(config);
	const stateFile = '.eom-platform/' + config.addon + '/state.json';
	const read = file => { const full = safePath(target, file, getProjectMounts(config)); return initializing && changes.has(file) ? changes.get(file) : fs.existsSync(full) ? fs.readFileSync(full) : null; };
	const previous = read(stateFile);
	const state = previous ? JSON.parse(previous) : { schema: 1, originals: {}, generated: {} };
	if (![1, 2].includes(state.schema)) throw new Error('Unsupported integration state');
	const next = { schema: state.schema, version: require('../package.json').version, originals: {}, generated: {} };
	for (const [file, checksum] of Object.entries(state.auxiliary ?? {})) {
		const data = read(file);
		if (!data && rebuilt) continue;
		if (!data || hash(data) !== checksum) throw new Error('Preserved runtime artifact changed: ' + file);
	}
	next.auxiliary = {};
	const put = (file, data) => changes.set(file, Buffer.isBuffer(data) ? data : Buffer.from(data));
	function original(file, { required = true } = {}) {
		const current = read(file);
		const old = state.originals[file];
		const generated = state.generated[file];
		let data = current;
		if (generated && current && hash(current) === generated) {
			data = old === null ? null : read(old.backup);
			if (old !== null && (!data || hash(data) !== old.sha256)) throw new Error('Original backup missing or changed: ' + file);
		} else if (generated && (!rebuilt || current?.toString().includes(marker))) throw new Error('Managed file changed; rebuild through eom-platform build or restore first: ' + file);
		if (!data && required) throw new Error('Missing project artifact: ' + file + '; build the project first');
		if (data) {
			const backup = '.eom-platform/' + config.addon + '/original/' + file;
			put(backup, data);
			next.originals[file] = { backup, sha256: hash(data) };
		} else next.originals[file] = null;
		return data?.toString('utf8') ?? '';
	}
	function managed(file, data) { put(file, data); next.generated[file] = hash(Buffer.from(data)); }
	function auxiliary(file, data) {
		if (!state.auxiliary?.[file] && read(file) && !initializing) throw new Error('Reserved SDK artifact already exists: ' + file);
		put(file, data); next.auxiliary[file] = hash(Buffer.from(data));
	}
	const integration = config.integration ?? {};
	const serverPath = integration.serverEntry ?? game + '/scripts/vscripts/addon_game_mode.lua';
	const clientPath = integration.clientEntry ?? game + '/scripts/vscripts/addon_game_mode_client.lua';
	for (const file of [serverPath, clientPath]) if (!file.startsWith(game + '/scripts/vscripts/') || !file.endsWith('.lua') || /["'\r\n]/.test(file)) throw new Error('Entry must be a Lua artifact under scripts/vscripts');
	if (serverPath === clientPath || [serverPath, clientPath].some(file => file.includes('/eom_platform/') || file.includes('/__eom_'))) throw new Error('Project entries must be distinct original Lua artifacts');
	const inputs = { serverPath, clientPath, migration: integration.migration ?? null };
	if (state.inputs && JSON.stringify(state.inputs) !== JSON.stringify(inputs)) throw new Error('Entry configuration changed; restore before selecting different entries');
	next.inputs = inputs;
	const serverDestination = game + '/scripts/vscripts/addon_game_mode.lua';
	const clientDestination = game + '/scripts/vscripts/addon_game_mode_client.lua';
	const serverBefore = original(serverDestination, { required: serverPath === serverDestination });
	const clientBefore = original(clientDestination, { required: false });
	let server = serverPath === serverDestination ? serverBefore : read(serverPath)?.toString('utf8');
	let client = clientPath === clientDestination ? clientBefore : read(clientPath)?.toString('utf8');
	if (!server || client == null) throw new Error('Missing configured original entry');
	const legacy = config.integration?.migration === 'legacy-tui';
	if (legacy) {
		if (!config.battleServer || !config.battleClient) throw new Error('legacy-tui migration requires battleServer and battleClient');
		if (server.includes('ActivateBattle') && server.includes('eom_platform.server')) {
			require('./legacy-tui.cjs').validateLegacy(server, client);
			server = 'require(' + JSON.stringify(config.battleServer) + ')\nActivate = ActivateBattle\nPrecache = PrecacheBattle\nSpawnGroupPrecache = SpawnGroupPrecacheBattle\n';
			client = 'require(' + JSON.stringify(config.battleClient) + ')\n';
		} else if (!previous) throw new Error('Unrecognized legacy TUI entries');
		for (const field of ['battleServer', 'battleClient']) if (!read(game + '/scripts/vscripts/' + config[field] + '.lua')) throw new Error('Missing legacy battle module: ' + config[field]);
	} else if (server.includes('eom_platform.server') || client.includes('eom_platform.client') || client.includes('ConnectTuiEntryLobby')) throw new Error('Existing manual SDK integration detected; select an explicit migration');
	const moduleName = file => file.slice((game + '/scripts/vscripts/').length, -4);
	const serverOriginal = path.posix.join(path.posix.dirname(serverPath), '__eom_original_server.lua');
	const clientOriginal = path.posix.join(path.posix.dirname(clientPath), '__eom_original_client.lua');
	auxiliary(serverOriginal, server);
	auxiliary(clientOriginal, client);
	managed(serverDestination, marker + '\nlocal map = (GetMapName() or ""):gsub("^maps/", ""):gsub("%.vpk$", "")\nif map == "platform_entry" or map == "platform_lobby" then\n    local sdk = require("eom_platform.server")\n    function Activate() sdk.ActivatePlatform() end\n    function Precache(context) end\n    function SpawnGroupPrecache(group, context) end\nelse\n    local result = require(' + JSON.stringify(moduleName(serverOriginal)) + ')\n    local activate, precache, spawnGroupPrecache = Activate, Precache, SpawnGroupPrecache\n    function Activate(...) if activate then return activate(...) end end\n    function Precache(...) if precache then return precache(...) end end\n    function SpawnGroupPrecache(...) if spawnGroupPrecache then return spawnGroupPrecache(...) end end\n    return result\nend\n');
	managed(clientDestination, marker + '\nreturn require("eom_platform.client").Initialize(' + JSON.stringify(moduleName(clientOriginal)) + ')\n');
	const layoutRoot = content + '/panorama/layout/custom_game/';
	const loadingPath = layoutRoot + 'custom_loading_screen.xml';
	let loading = original(loadingPath, { required: false });
	if (config.panorama?.battleLoadingLayout) loading = fs.readFileSync(safePath(target, layoutRoot + config.panorama.battleLoadingLayout, getProjectMounts(config)), 'utf8');
	const originalLoading = 'eom_platform/original_loading.xml';
	auxiliary(layoutRoot + originalLoading, loading || '<root><Panel /></root>\n');
	const router = routeLayout('loading_route', originalLoading, 'eom_platform/loading.xml');
	managed(loadingPath, router.xml);
	put(content + '/panorama/scripts/custom_game/eom_platform/integration/loading_route.js', router.js);
	const manifestPath = layoutRoot + 'custom_ui_manifest.xml';
	let manifest = original(manifestPath);
	let count = 0;
	manifest = manifest.replace(/<CustomUIElement\b[^>]*\btype\s*=\s*["']CustomGameSetup["'][^>]*\/?\s*>/g, (tag, offset) => {
		const match = /\blayoutfile\s*=\s*(["'])(.*?)\1/.exec(tag);
		const prefix = 'file://{resources}/layout/custom_game/';
		function fail(reason, action = '请在项目源文件或构建配置中修正布局引用和输出名称；文件名和目录名使用英文字母、数字、下划线或横线，目录用 / 分隔，以小写 .xml 结尾。例如 ' + prefix + 'setup_v2.xml。重新构建后再预览接入。') {
			throw new Error([
				'无法接入选队界面（CustomGameSetup）。',
				'文件：' + manifestPath + ':' + (manifest.slice(0, offset).split('\n').length),
				match ? 'layoutfile：' + JSON.stringify(match[2]) : '元素：' + tag,
				'原因：' + reason,
				'处理：' + action,
				'本次操作已停止，未写入接入改动。',
			].join('\n'));
		}
		if (!match) fail('缺少有效的 layoutfile 属性，属性值必须使用单引号或双引号包裹。');
		if (!match[2]) fail('layoutfile 为空，未指定选队界面的 XML 文件。');
		if (!match[2].startsWith(prefix)) fail('layoutfile 必须以 ' + prefix + ' 开头。');
		const layout = match[2].slice(prefix.length);
		if (!layout.endsWith('.xml')) fail('布局文件必须以小写 .xml 结尾。');
		const unsupported = [...new Set(layout.slice(0, -4).match(/[^a-zA-Z0-9_/-]/g) ?? [])];
		if (unsupported.length) fail('当前 SDK 路径校验不支持文件名或目录名中的字符：' + unsupported.map(character => JSON.stringify(character)).join('、') + '（扩展名 .xml 除外）。');
		if (!/^[a-zA-Z0-9_/-]+\.xml$/.test(layout)) fail('布局文件名不能为空。');
		if (layout.split('/').some(part => !part)) fail('布局路径包含空目录层级，请检查开头的 / 或重复的 //。');
		if (layout.startsWith('eom_platform/')) fail('选队界面已经指向 SDK 的 eom_platform 目录，无法再次包装。', '请恢复项目原始的选队界面引用；已有手动 SDK 接入的项目需使用对应迁移方式。');
		if (!read(layoutRoot + layout)) fail('布局文件不存在：' + layoutRoot + layout, '请检查项目源文件或构建配置，确认已生成该 XML，或将 layoutfile 改为实际生成的布局路径；重新构建后再预览接入。');
		const name = 'setup_route_' + count++;
		const route = routeLayout(name, layout, null);
		put(layoutRoot + 'eom_platform/' + name + '.xml', route.xml);
		put(content + '/panorama/scripts/custom_game/eom_platform/integration/' + name + '.js', route.js);
		return tag.replace(match[0], 'layoutfile="file://{resources}/layout/custom_game/eom_platform/' + name + '.xml"');
	});
	managed(manifestPath, manifest);
	// Some addons use the conventional team_select.xml directly, without a
	// CustomGameSetup manifest element. Route that engine entry as well.
	const teamSelectPath = layoutRoot + 'team_select.xml';
	if (read(teamSelectPath)) {
		const teamSelect = original(teamSelectPath);
		const preserved = 'eom_platform/original_team_select.xml';
		auxiliary(layoutRoot + preserved, teamSelect);
		const route = routeLayout('team_select_route', preserved, null);
		managed(teamSelectPath, route.xml);
		put(content + '/panorama/scripts/custom_game/eom_platform/integration/team_select_route.js', route.js);
	}
	const eventFile = game + '/scripts/custom.gameevents';
	managed(eventFile, mergeEvents(original(eventFile, { required: false })));
	const addonInfo = game + '/addoninfo.txt';
	managed(addonInfo, mergeAddonInfo(original(addonInfo), config.integration?.retainedMaps));
	put(stateFile, JSON.stringify(next, null, 2) + '\n');
	return { stateFile, migration: legacy ? 'legacy-tui' : null };
}

function restore(target, config, { dryRun = false } = {}) {
	config = resolveProjectPaths(target, config);
	assertNoWatchers(target);
	const resolve = file => safePath(target, file, getProjectMounts(config));
	if (fs.existsSync(resolve('.eom-platform/' + config.addon + '/encryption.json'))) throw new Error('Restore encrypted outputs with restore-encryption before restoring integration');
	return require('./integration-state.cjs').restoreIntegration(target, config, { dryRun });
}

module.exports = { automatic, restore, safePath, routeLayout, mergeAddonInfo, hash, restorationStatus: (...args) => require('./integration-state.cjs').restorationStatus(...args) };

const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');

const directory = root => path.join(path.resolve(root), '.scratch/eom-platform-watch');

function alive(pid) {
    try { process.kill(pid, 0); return true; }
    catch (error) { if (error.code === 'ESRCH') return false; return true; }
}

function assertNoWatchers(root) {
    const folder = directory(root);
    if (!fs.existsSync(folder)) return;
    const active = [];
    for (const entry of fs.readdirSync(folder, { withFileTypes: true })) {
        const match = /^(\d+)-[a-f0-9-]+\.json$/.exec(entry.name);
        if (!match || !entry.isFile()) continue;
        const file = path.join(folder, entry.name);
        if (!alive(Number(match[1]))) {
            try { fs.unlinkSync(file); } catch (error) { if (error.code !== 'ENOENT') throw error; }
            continue;
        }
        let kind = 'watch';
        try {
            const record = JSON.parse(fs.readFileSync(file, 'utf8'));
            if (typeof record.kind === 'string' && /^[a-z0-9_-]+$/.test(record.kind)) kind = record.kind;
        } catch (error) { if (error.code === 'ENOENT') continue; }
        active.push(kind + ' (PID ' + match[1] + ')');
    }
    if (active.length) throw new Error('请先停止项目监听进程，再切换或构建版本：' + active.join(', '));
}

function assertNative(root) {
    const config = JSON.parse(fs.readFileSync(path.join(root, 'platform.config.json'), 'utf8'));
    if (!/^[a-z][a-z0-9_]*$/.test(config.addon ?? '')) throw new Error('Invalid addon in platform.config.json');
    const { safePath, restorationStatus } = require('./automatic.cjs');
    if (fs.existsSync(safePath(root, '.eom-platform/' + config.addon + '/encryption.json'))) {
        throw new Error('请先停止监听、恢复 Lua 明文并切换到 native 模式，再启动监听。');
    }
    if (restorationStatus(root, config).enabled) throw new Error('监听仅支持 native 模式；请先停止监听并切换到 native 模式。');
}

function registerWatcher(root, kind = 'watch') {
    root = path.resolve(root);
    if (!/^[a-z0-9_-]+$/.test(kind)) throw new Error('Invalid watcher kind');
    assertNative(root);
    const folder = directory(root);
    fs.mkdirSync(folder, { recursive: true });
    const file = path.join(folder, process.pid + '-' + randomUUID() + '.json');
    fs.writeFileSync(file, JSON.stringify({ pid: process.pid, kind }) + '\n', { flag: 'wx' });
    let released = false;
    const release = () => {
        if (released) return;
        released = true;
        process.removeListener('exit', release);
        try { fs.unlinkSync(file); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    };
    process.once('exit', release);
    try { assertNative(root); } catch (error) { release(); throw error; }
    return release;
}

module.exports = { registerWatcher, assertNoWatchers };

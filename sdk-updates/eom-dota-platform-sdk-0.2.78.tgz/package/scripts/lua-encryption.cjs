const { resolveProjectPaths, getProjectMounts } = require('./project-paths.cjs');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { safePath, hash } = require('./automatic.cjs');
const { writePlan } = require('./write-plan.cjs');

const marker = '-- EOM encrypted module v1\n';
// These modules must run on the local entry map before a dedicated server exists.
const publicModules = new Set(['addon_init', 'addon_game_mode', 'addon_game_mode_client', 'encrypt', 'eom_platform/server', 'eom_platform/client', 'eom_platform/connection_client']);

function encrypt(code, key) {
	const iv = crypto.randomBytes(16);
	const data = Buffer.from(code);
	const cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
	cipher.setAutoPadding(false);
	return Buffer.concat([iv, cipher.update(Buffer.concat([data, Buffer.alloc(16 - data.length % 16)])), cipher.final()]).toString('hex');
}

function encryptionSettings(legacy) {
	const keyDomain = legacy.keyDomain ?? 'encrypted_modules';
	if (typeof keyDomain !== 'string' || !/^[a-zA-Z0-9_.-]{1,64}$/.test(keyDomain)) throw new Error('Encryption keyDomain must be a 1-64 character key identifier');
	if (legacy.serverOnly !== undefined && typeof legacy.serverOnly !== 'boolean') throw new Error('Encryption serverOnly must be a boolean');
	return { keyDomain, serverOnly: legacy.serverOnly === true };
}

function runtime(aes, key, debug, options = {}) {
	const { keyDomain, serverOnly } = encryptionSettings(options);
	const probe = encrypt('EOM encryption key check v1', key);
	return `-- EOM encryption bootstrap v1
local runtime = {}
${aes}
local function fromHex(value)
    return (value:gsub('..', function(pair) return string.char(tonumber(pair,16)) end))
end
local function decode(value, key)
    local raw = fromHex(value)
    local plain = ciphermode.decryptString({string.byte(fromHex(key),1,16)}, raw:sub(17), ciphermode.decryptCBC, {string.byte(raw,1,16)})
    return (plain:gsub('%z+$',''))
end
local function valid(key)
    return type(key)=='string' and #key==32 and key:match('^[%x]+$') ~= nil
end
local lastKey, checked, warned
local function readKey()
    if IsServer() then
        return ${debug ? JSON.stringify(key.toString('hex')) : 'tostring(GetDedicatedServerKeyV3(' + JSON.stringify(keyDomain) + ')):sub(1,32)'}
    end
    ${serverOnly ? 'return nil' : "return (CustomNetTables:GetTableValue('common','encrypt_key') or {})._"}
end
function runtime.Ready()
    ${serverOnly ? 'if not IsServer() then return true end' : ''}
    local key = readKey()
    if key ~= lastKey then lastKey, checked, warned = key, nil, nil end
    if checked then return true end
    if valid(key) then
        local ok, result = pcall(decode, '${probe}', key)
        checked = ok and result == 'EOM encryption key check v1'
    end
    if not checked then
        if IsServer() then error('[platform encryption] ${keyDomain} ServerKey is missing or does not match this build',0) end
        if key and key ~= '' and not warned then
            print('[platform encryption] Waiting for a matching server encryption key')
            warned = true
        end
        return false
    end
    ${serverOnly ? '' : "if IsServer() then CustomNetTables:SetTableValue('common','encrypt_key',{_=key}) end"}
    return true
end
function runtime.Decrypt(encrypted)
    ${serverOnly ? "assert(IsServer(), '[platform encryption] Server-only module cannot load on the client')" : ''}
    assert(runtime.Ready(), '[platform encryption] Client key is not ready')
    return decode(encrypted,lastKey)
end
function runtime.Module(encrypted, chunkName, environment, ...)
    local code = runtime.Decrypt(encrypted)
    local prefix = ${JSON.stringify(marker)}
    assert(code:sub(1,#prefix)==prefix, '[platform encryption] Invalid payload: '..chunkName)
    local chunk, problem = load(code,chunkName,nil,environment)
    assert(chunk,problem)
    return chunk(...)
end
_G.EOMPlatformEncryptionReady = runtime.Ready
_G.decrypt = runtime.Decrypt
_G.decryptModule = function(encrypted, chunkName, ...)
    return runtime.Module(encrypted, chunkName, getfenv(2), ...)
end
return runtime
`;
}

function context(target, config) {
	return {
		resolve: file => safePath(target, file.replace(/\/$/, ''), getProjectMounts(config)),
		state: '.eom-platform/' + config.addon + '/encryption.json',
		root: require('./project-paths.cjs').addonRoots(config).game + '/scripts/vscripts/',
	};
}

function binding(target, config) {
	const canonical = file => {
		const full = fs.realpathSync(file);
		return process.platform === 'win32' ? full.toLowerCase() : full;
	};
	return { target: canonical(target), mounts: Object.fromEntries(Object.entries(getProjectMounts(config) || {}).sort(([a], [b]) => a.localeCompare(b)).map(([file, destination]) => [file, canonical(destination)])) };
}

function createdDirectories(files, resolve) {
	const directories = new Set();
	for (const file of files) {
		let current = path.posix.dirname(file);
		while (current !== '.') {
			const full = resolve(current);
			if (!fs.existsSync(full)) directories.add(current);
			else if (!fs.statSync(full).isDirectory()) throw new Error('Encryption parent is not a directory: ' + current);
			current = path.posix.dirname(current);
		}
	}
	return [...directories].sort((a, b) => b.split('/').length - a.split('/').length || a.localeCompare(b));
}

function encryptProject(target, config, legacy, { dryRun = false } = {}) {
	config = resolveProjectPaths(target, config);
	const { resolve, state, root } = context(target, config);
	if (![config.addon, require('./project-paths.cjs').addonRoots(config).game.slice('game/'.length)].includes(legacy.addonName)) throw new Error('Encryption addonName must match the selected project');
	if (!/^[a-f\d]{32}$/i.test(legacy.key ?? '')) throw new Error('Encryption key must contain exactly 32 hexadecimal characters');
	const settings = encryptionSettings(legacy);
	if (fs.existsSync(resolve(state))) throw new Error('Encrypted outputs already exist; restore-encryption before rebuilding or encrypting again');
	const micromatch = require('micromatch');
	const minify = require('luamin').minify;
	const key = Buffer.from(legacy.key, 'hex');
	const aes = fs.readFileSync(safePath(target, 'aes.lua', getProjectMounts(config)), 'utf8');
	const operations = [], originals = {}, backupOriginals = {}, changedFiles = [state], encrypted = [], publicFiles = [];
	function put(file, output) {
		const destination = resolve(file);
		const before = fs.existsSync(destination) ? fs.readFileSync(destination) : null;
		const backup = '.eom-platform/' + config.addon + '/encryption-original/' + file;
		if (before) {
			const backupPath = resolve(backup);
			const prior = fs.existsSync(backupPath) ? fs.readFileSync(backupPath) : null;
			backupOriginals[backup] = prior ? { data: prior.toString('base64'), sha256: hash(prior) } : null;
			operations.push({ destination: backupPath, data: before });
			changedFiles.push(backup);
		}
		const data = Buffer.from(output);
		originals[file] = { backup: before ? backup : null, before: before ? hash(before) : null, after: hash(data) };
		operations.push({ destination, data });
		changedFiles.push(file);
	}
	function visit(relative, ancestors = new Set()) {
		const real = fs.realpathSync(resolve(relative));
		if (ancestors.has(real)) throw new Error('Cyclic Lua directory link: ' + relative);
		const parents = new Set([...ancestors, real]);
		for (const item of fs.readdirSync(resolve(relative), { withFileTypes: true })) {
			const file = relative + item.name;
			if (item.isDirectory() || item.isSymbolicLink() && fs.statSync(resolve(file)).isDirectory()) visit(file + '/', parents);
			else if (item.isFile() || item.isSymbolicLink() && fs.statSync(resolve(file)).isFile()) {
				if (!file.endsWith('.lua') || file === root + 'encrypt.lua') continue;
				const module = file.slice(root.length, -4);
				let code = fs.readFileSync(resolve(file), 'utf8');
				if (/EOM encrypted module v1|return\s*\(?decryptModule\s*\(/.test(code)) throw new Error('Already encrypted Lua artifact: ' + file);
				if (publicModules.has(module)) {
					publicFiles.push(module);
					// Load only the lazy key reader; entry-map connection never needs a key.
					if (module === 'addon_game_mode_client' && !settings.serverOnly) code = 'require("encrypt")\n' + code;
				} else if (micromatch([module], legacy.vscripts.server).length === 1) {
					code = marker + 'local runtime = require("encrypt")\nreturn runtime.Module("' + encrypt(marker + code, key) + '", ' + JSON.stringify('@' + module + '.lua') + ', getfenv(1), ...)\n';
					encrypted.push(module);
				} else if (micromatch([module], legacy.vscripts.minify ?? []).length === 1) code = minify(code);
				put(file, code);
			}
		}
	}
	visit(root);
	put(root + 'encrypt.lua', runtime(aes, key, legacy.debug === true, settings));
	const directories = createdDirectories(changedFiles, resolve);
	operations.push({ destination: resolve(state), data: Buffer.from(JSON.stringify({ schema: 2, version: require('../package.json').version, originals, encrypted, publicModules: publicFiles, backupOriginals, createdDirectories: directories, binding: binding(target, config) }, null, 2) + '\n') });
	if (!dryRun) writePlan(operations);
	return { encrypted, publicModules: publicFiles, dryRun };
}

function restoreEncryption(target, config, { dryRun = false } = {}) {
	config = resolveProjectPaths(target, config);
	const { resolve, state } = context(target, config);
	const manifest = JSON.parse(fs.readFileSync(resolve(state), 'utf8'));
	if (![1, 2].includes(manifest.schema)) throw new Error('Unsupported encryption state');
	if (manifest.schema === 2 && JSON.stringify(manifest.binding) !== JSON.stringify(binding(target, config))) throw new Error('Encryption project location or link targets changed; restore the original paths before retrying');
	const operations = [];
	const backups = [];
	for (const [file, item] of Object.entries(manifest.originals)) {
		if (!fs.existsSync(resolve(file)) || hash(fs.readFileSync(resolve(file))) !== item.after) throw new Error('Encrypted output changed: ' + file + '; restore the matching output before retrying');
		const data = item.backup ? fs.readFileSync(resolve(item.backup)) : null;
		if (data && hash(data) !== item.before) throw new Error('Encryption backup changed: ' + file);
		operations.push({ destination: resolve(file), data });
		if (item.backup) backups.push(item.backup);
	}
	let removedBackups = 0, restoredBackupFiles = 0;
	const directories = [];
	if (manifest.schema === 2) {
		if (!manifest.backupOriginals || typeof manifest.backupOriginals !== 'object' || Object.keys(manifest.backupOriginals).length !== backups.length || !Array.isArray(manifest.createdDirectories)) throw new Error('Invalid encryption cleanup state');
		for (const backup of backups) {
			if (!Object.hasOwn(manifest.backupOriginals, backup)) throw new Error('Invalid encryption backup cleanup state');
			const prior = manifest.backupOriginals[backup];
			let data = null;
			if (prior !== null) {
				if (typeof prior?.data !== 'string' || typeof prior?.sha256 !== 'string') throw new Error('Invalid original encryption backup');
				data = Buffer.from(prior.data, 'base64');
				if (data.toString('base64') !== prior.data || hash(data) !== prior.sha256) throw new Error('Original encryption backup changed: ' + backup);
				restoredBackupFiles++;
			} else removedBackups++;
			operations.push({ destination: resolve(backup), data });
		}
		const knownParents = new Set();
		for (const file of [state, ...backups, ...Object.keys(manifest.originals)]) {
			let parent = path.posix.dirname(file);
			while (parent !== '.') { knownParents.add(parent); parent = path.posix.dirname(parent); }
		}
		for (const directory of manifest.createdDirectories) {
			if (!knownParents.has(directory) || directories.includes(directory)) throw new Error('Invalid encryption cleanup directory');
			const full = resolve(directory);
			if (fs.existsSync(full) && !fs.statSync(full).isDirectory()) throw new Error('Encryption cleanup directory changed: ' + directory);
			directories.push(directory);
		}
	}
	operations.push({ destination: resolve(state), data: null });
	if (!dryRun) writePlan(operations, { removeDirectories: directories.map(resolve) });
	return { restored: Object.keys(manifest.originals).length, removedBackups, restoredBackupFiles, retainedLegacyBackups: manifest.schema === 1 && backups.length > 0, cleanupDirectories: directories, dryRun };
}

async function runLegacy(target, args = process.argv.slice(2)) {
	const path = require('node:path');
	if (args.some(arg => !['--restore', '--dry-run', '--keep'].includes(arg))) throw new Error('Usage: node encrypt-custom-game.js [--keep | --restore] [--dry-run]');
	const config = resolveProjectPaths(target, require(path.resolve(target, 'platform.config.json')));
	require('./install.cjs').validate(config);
	const dryRun = args.includes('--dry-run');
	if (args.includes('--restore')) return console.log(JSON.stringify(restoreEncryption(target, config, { dryRun })));
	const legacy = require(path.resolve(target, 'encrypt-custom-game-config.js'));
	const keep = legacy.noRestore === true || args.includes('--keep');
	if (!keep && !dryRun && !process.stdin.isTTY) throw new Error('Interactive restore requires a terminal; use --keep and later --restore, or --dry-run');
	const automatic = require('./automatic.cjs');
	const integration = automatic.restorationStatus(target, config);
	const integrationFile = safePath(target, '.eom-platform/' + config.addon + '/state.json', getProjectMounts(config));
	let integrationState;
	if (fs.existsSync(integrationFile)) {
		integrationState = JSON.parse(fs.readFileSync(integrationFile, 'utf8'));
		const record = value => value && typeof value === 'object' && !Array.isArray(value);
		if (![1, 2].includes(integrationState.schema) || !record(integrationState.originals) || !record(integrationState.generated) || (integrationState.schema === 2 && integration.restoration !== 'exact')) throw new Error('Invalid SDK integration restoration state');
	}
	if (integration.enabled) {
		require('./pipeline.cjs').inspect(target, config);
		if (integrationState?.schema === 2) automatic.restore(target, config, { dryRun: true });
	}
	else {
		const entry = safePath(target, require('./project-paths.cjs').addonRoots(config).game + '/scripts/vscripts/addon_game_mode.lua', getProjectMounts(config));
		if (!fs.existsSync(entry) || !fs.statSync(entry).isFile()) throw new Error('Build the native addon_game_mode.lua before encryption');
		if (fs.readFileSync(entry, 'utf8').includes('-- EOM SDK managed entry v1')) throw new Error('SDK entry exists without its integration restoration record');
	}
	const report = encryptProject(target, config, legacy, { dryRun });
	console.log('[platform] ' + (dryRun ? 'Would encrypt ' : 'Encrypted ') + report.encrypted.length + ' Lua modules; retained ' + report.publicModules.length + ' public bootstrap modules');
	if (keep || dryRun) return;
	try {
		console.log('Press any key to restore the original Lua outputs');
		process.stdin.setRawMode(true);
		process.stdin.resume();
		await new Promise(resolve => process.stdin.once('data', resolve));
	} finally {
		process.stdin.setRawMode(false);
		process.stdin.pause();
		restoreEncryption(target, config);
	}
}

module.exports = { encryptProject, restoreEncryption, runtime, encrypt, publicModules, runLegacy };

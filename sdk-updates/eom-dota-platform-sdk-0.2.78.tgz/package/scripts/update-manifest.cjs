'use strict';
const fs = require('node:fs');
const crypto = require('node:crypto');
const { stableVersion } = require('./studio-launcher.cjs');
const MAX_ARCHIVE_BYTES = 64 * 1024 * 1024;

function httpsURL(value) {
	let url;
	try { url = new URL(value); } catch { throw new Error('更新地址必须是完整的 HTTPS 地址'); }
	if (url.protocol !== 'https:' || url.username || url.password || url.hash) throw new Error('更新地址必须是完整的 HTTPS 地址');
	return url.href;
}

function payload(value) {
	if (value?.schema !== 1 || !stableVersion(value.version) || !/^[a-f0-9]{64}$/.test(value.sha256)
		|| !Number.isSafeInteger(value.size) || value.size < 1 || value.size > MAX_ARCHIVE_BYTES
		|| !Number.isSafeInteger(value.launcherProtocol) || value.launcherProtocol < 1
		|| typeof value.archiveSignature !== 'string' || Buffer.from(value.archiveSignature, 'base64').length !== 64) throw new Error('更新版本清单无效');
	return { schema: 1, version: value.version, launcherProtocol: value.launcherProtocol, url: httpsURL(value.url), sha256: value.sha256, size: value.size, archiveSignature: value.archiveSignature };
}

function verifyManifest(value, publicKey) {
	const data = payload(value);
	if (typeof value.signature !== 'string' || !crypto.verify(null, Buffer.from(JSON.stringify(data)), publicKey, Buffer.from(value.signature, 'base64'))
		|| !crypto.verify(null, Buffer.from(data.sha256), publicKey, Buffer.from(data.archiveSignature, 'base64'))) throw new Error('更新版本清单签名校验失败');
	return data;
}

function createManifest({ version, archive, url, privateKey, launcherProtocol = 1 }) {
	const bytes = fs.readFileSync(archive), sha256 = crypto.createHash('sha256').update(bytes).digest('hex');
	const data = payload({ schema: 1, version, launcherProtocol, url, sha256, size: bytes.length, archiveSignature: crypto.sign(null, Buffer.from(sha256), privateKey).toString('base64') });
	return { ...data, signature: crypto.sign(null, Buffer.from(JSON.stringify(data)), privateKey).toString('base64') };
}

module.exports = { createManifest, verifyManifest, httpsURL, MAX_ARCHIVE_BYTES };

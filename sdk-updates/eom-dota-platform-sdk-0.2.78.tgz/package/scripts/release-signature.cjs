'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const packageName = '@eom/dota-platform-sdk';
const signatureFile = 'studio-release.json';
const stableVersion = value => typeof value === 'string' && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(value);
const digest = data => crypto.createHash('sha256').update(data).digest('hex');

function rejectLinkedAncestors(target) {
	let current = path.resolve(target);
	while (true) {
		if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) throw new Error('Release paths cannot contain symbolic links');
		const parent = path.dirname(current);
		if (parent === current) return;
		current = parent;
	}
}

function validFile(file) {
	return typeof file === 'string' && file && !file.includes('\\') && !file.includes(':') && !file.includes('\0') && !path.posix.isAbsolute(file) && !path.win32.isAbsolute(file) && file.split('/').every(part => part && part !== '.' && part !== '..');
}

function releaseFiles(root) {
	root = path.resolve(root);
	rejectLinkedAncestors(root);
	if (!fs.statSync(root).isDirectory()) throw new Error('Release root must be a directory');
	const files = [];
	function visit(directory, prefix) {
		for (const name of fs.readdirSync(directory).sort()) {
			const file = prefix + name;
			if (!validFile(file)) throw new Error('Invalid release file path');
			const full = path.join(directory, name);
			const stat = fs.lstatSync(full);
			if (stat.isSymbolicLink()) throw new Error('Release paths cannot contain symbolic links');
			if (stat.isDirectory()) visit(full, file + '/');
			else if (!stat.isFile()) throw new Error('Release contains a non-regular file');
			else if (file !== signatureFile) files.push({ file, sha256: digest(fs.readFileSync(full)) });
		}
	}
	visit(root, '');
	return files.sort((left, right) => left.file < right.file ? -1 : left.file > right.file ? 1 : 0);
}

function metadata(root, expectedVersion) {
	const value = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
	if (value.name !== packageName || !stableVersion(value.version) || expectedVersion !== undefined && value.version !== expectedVersion) throw new Error('Release package identity does not match');
	return value;
}

function privateKey(value) {
	const key = crypto.createPrivateKey(value);
	if (key.asymmetricKeyType !== 'ed25519') throw new Error('Release signing requires an Ed25519 private key');
	return key;
}

function publicKey(value) {
	const key = crypto.createPublicKey(value);
	if (key.asymmetricKeyType !== 'ed25519') throw new Error('Release verification requires an Ed25519 public key');
	return key;
}

function signRelease(root, privateKeyPem) {
	root = path.resolve(root);
	const files = releaseFiles(root);
	const value = metadata(root);
	const manifest = { schema: 1, packageName, version: value.version, files };
	const signature = crypto.sign(null, Buffer.from(JSON.stringify(manifest)), privateKey(privateKeyPem)).toString('base64');
	const envelope = { manifest, signature };
	const destination = path.join(root, signatureFile);
	fs.writeFileSync(destination, JSON.stringify(envelope, null, 2) + '\n');
	return envelope;
}

function verifyRelease(root, publicKeyPem, expectedVersion) {
	root = path.resolve(root);
	rejectLinkedAncestors(root);
	const envelopePath = path.join(root, signatureFile);
	if (!fs.lstatSync(envelopePath).isFile() || fs.lstatSync(envelopePath).isSymbolicLink()) throw new Error('Release signature must be a regular file');
	const envelope = JSON.parse(fs.readFileSync(envelopePath, 'utf8'));
	const manifest = envelope?.manifest;
	if (!manifest || manifest.schema !== 1 || manifest.packageName !== packageName || !stableVersion(manifest.version) || expectedVersion !== undefined && manifest.version !== expectedVersion || !Array.isArray(manifest.files) || !manifest.files.length) throw new Error('Invalid release signature manifest');
	const seen = new Set();
	for (const item of manifest.files) {
		if (!item || !validFile(item.file) || item.file === signatureFile || seen.has(item.file) || typeof item.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(item.sha256)) throw new Error('Invalid release signature file list');
		seen.add(item.file);
	}
	if (typeof envelope.signature !== 'string' || !/^[A-Za-z0-9+/]{86}==$/.test(envelope.signature)) throw new Error('Invalid release signature');
	const signature = Buffer.from(envelope.signature, 'base64');
	if (signature.length !== 64 || signature.toString('base64') !== envelope.signature || !crypto.verify(null, Buffer.from(JSON.stringify(manifest)), publicKey(publicKeyPem), signature)) throw new Error('Release signature verification failed');
	const actual = releaseFiles(root);
	if (actual.length !== manifest.files.length || actual.some(item => !seen.has(item.file))) throw new Error('Release file set does not match the signed manifest');
	const signedHashes = new Map(manifest.files.map(item => [item.file, item.sha256]));
	if (actual.some(item => item.sha256 !== signedHashes.get(item.file))) throw new Error('Release file hash does not match the signed manifest');
	const value = metadata(root, manifest.version);
	return { version: value.version, packageName: value.name, files: actual };
}

function ensureSigningKey(keyPath) {
	keyPath = path.resolve(keyPath);
	rejectLinkedAncestors(keyPath);
	if (!fs.statSync(path.dirname(keyPath)).isDirectory()) throw new Error('Signing key parent must be a directory');
	if (!fs.existsSync(keyPath)) {
		const pair = crypto.generateKeyPairSync('ed25519', { publicKeyEncoding: { type: 'spki', format: 'pem' }, privateKeyEncoding: { type: 'pkcs8', format: 'pem' } });
		fs.writeFileSync(keyPath, pair.privateKey, { flag: 'wx', mode: 0o600 });
	}
	if (!fs.lstatSync(keyPath).isFile() || fs.lstatSync(keyPath).isSymbolicLink()) throw new Error('Signing key must be a regular file');
	const pem = fs.readFileSync(keyPath, 'utf8');
	const key = privateKey(pem);
	return { privateKey: pem, publicKey: crypto.createPublicKey(key).export({ type: 'spki', format: 'pem' }) };
}

module.exports = { signRelease, verifyRelease, ensureSigningKey };

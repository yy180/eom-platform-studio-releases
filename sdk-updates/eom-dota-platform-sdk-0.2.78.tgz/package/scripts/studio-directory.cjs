'use strict';
const fs = require('node:fs');
const { spawn } = require('node:child_process');

function pickDirectory(initial = '') {
	if (process.platform !== 'win32') throw new Error('系统目录选择目前支持 Windows，请填写项目目录');
	const script = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = '选择游戏项目目录（包含 content 和 game 文件夹）'
$dialog.ShowNewFolderButton = $false
if ($env:EOM_STUDIO_PICK_DIRECTORY -and (Test-Path -LiteralPath $env:EOM_STUDIO_PICK_DIRECTORY -PathType Container)) { $dialog.SelectedPath = $env:EOM_STUDIO_PICK_DIRECTORY }
$owner = New-Object System.Windows.Forms.Form
$owner.TopMost = $true
$owner.ShowInTaskbar = $false
$owner.Opacity = 0
$owner.Show()
try { if ($dialog.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.SelectedPath) } }
finally { $dialog.Dispose(); $owner.Dispose() }
`;
	return new Promise((resolve, reject) => {
		const child = spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-STA', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], {
			windowsHide: true, shell: false, env: { ...process.env, EOM_STUDIO_PICK_DIRECTORY: typeof initial === 'string' && fs.existsSync(initial) ? initial : '' }, stdio: ['ignore', 'pipe', 'pipe'],
		});
		let output = '';
		child.stdout.setEncoding('utf8');
		child.stdout.on('data', data => { output += data; });
		child.stderr.resume();
		child.on('error', () => reject(new Error('无法打开系统目录选择窗口，请填写项目目录')));
		child.on('close', code => code === 0 ? resolve(output.trim() || null) : reject(new Error('系统目录选择窗口未能打开，请填写项目目录')));
	});
}

module.exports = { pickDirectory };

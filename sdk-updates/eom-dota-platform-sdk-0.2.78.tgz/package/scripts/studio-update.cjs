'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { installSeed, runNpm, ensureHome, acquireLock, compareVersions, validateRelease, readActive } = require('./studio-launcher.cjs');
const { verifyManifest, httpsURL } = require('./update-manifest.cjs');

async function download(url, limit, fetcher = fetch, progress = () => {}, timeout = 60000) {
	const controller = new AbortController(), timer = setTimeout(() => controller.abort(), timeout);
	try {
		const response = await fetcher(httpsURL(url), { redirect: 'error', signal: controller.signal, headers: { Accept: 'application/octet-stream, application/json' } });
		if (!response.ok || !response.body) throw new Error('更新服务器返回 HTTP ' + response.status);
		const length = Number(response.headers.get('content-length'));
		if (length > limit) throw new Error('更新文件超过大小限制');
		const chunks = []; let bytes = 0;
		for await (const chunk of response.body) {
			bytes += chunk.length;
			if (bytes > limit) throw new Error('更新文件超过大小限制');
			chunks.push(Buffer.from(chunk)); progress(bytes);
		}
		return Buffer.concat(chunks);
	} finally { clearTimeout(timer); }
}

function createUpdater({ home, version, currentRoot, trust, managed = false, npm = runNpm, fetcher = fetch, canUpdate = () => {} } = {}) {
	let manifest = null, busy = false;
	const enabled = !!(managed && trust?.updateUrl);
	const state = { enabled, status: enabled ? 'idle' : 'unconfigured', currentVersion: version, availableVersion: null, downloaded: 0, total: 0,
		message: managed ? '尚未配置在线更新服务' : '请通过接入助手启动器使用在线更新' };
	if (enabled) state.message = '点击检查更新';
	const snapshot = () => ({ ...state });
	function available() {
		if (!enabled) throw new Error(state.message);
		if (busy) throw new Error('正在处理更新，请稍后再试');
		canUpdate();
	}
	function failed(error) { state.status = 'error'; state.message = error.message; }
	async function check() {
		available(); busy = true; state.status = 'checking'; state.message = '正在检查更新…';
		try {
			manifest = verifyManifest(JSON.parse((await download(trust.updateUrl, 65536, fetcher, undefined, 10000)).toString('utf8')), trust.publicKey);
			state.availableVersion = manifest.version; state.total = manifest.size; state.downloaded = 0;
			if (compareVersions(manifest.version, version) <= 0) { state.status = 'current'; state.message = '当前已是最新版本'; }
			else if (manifest.launcherProtocol > 1) { state.status = 'unsupported'; state.message = '此版本需要更新完整安装包'; }
			else {
				const active = readActive(home)?.current;
				const prepared = active?.version === manifest.version && active.root !== currentRoot;
				if (prepared) validateRelease(active.root, active.version, home, trust);
				state.status = prepared ? 'ready' : 'available';
				state.message = prepared ? '更新已安装，重启应用即可使用' : '发现新版本 v' + manifest.version;
			}
			return snapshot();
		} catch (error) { manifest = null; failed(error); throw error; }
		finally { busy = false; }
	}
	async function install(expectedVersion) {
		available();
		if (!manifest || state.status !== 'available' || expectedVersion !== manifest.version) throw new Error('请先检查更新并确认当前版本');
		ensureHome(home);
		const unlock = acquireLock(home);
		if (!unlock) throw new Error('另一个进程正在更新接入助手');
		busy = true; let archive;
		try {
			state.status = 'downloading'; state.message = '正在下载更新…'; state.downloaded = 0;
			const bytes = await download(manifest.url, manifest.size, fetcher, count => { state.downloaded = count; });
			if (bytes.length !== manifest.size || crypto.createHash('sha256').update(bytes).digest('hex') !== manifest.sha256) throw new Error('更新文件完整性校验失败');
			archive = path.join(home, 'update-' + crypto.randomUUID() + '.tgz');
			fs.writeFileSync(archive, bytes, { flag: 'wx' });
			state.status = 'installing'; state.message = '正在校验并安装更新…';
			const previous = validateRelease(currentRoot, version, undefined, trust);
			await installSeed({ home, seedPath: archive, npm, env: { ...process.env, npm_config_cache: path.join(home, 'npm-cache') },
				trust: { ...trust, seedVersion: manifest.version, seedSha256: manifest.sha256, seedSignature: manifest.archiveSignature }, previous, log: () => {} });
			state.status = 'ready'; state.message = '更新已安装，重启应用即可使用';
			return snapshot();
		} catch (error) { failed(error); throw error; }
		finally { try { if (archive) fs.unlinkSync(archive); } finally { busy = false; unlock(); } }
	}
	function restart() {
		available();
		if (state.status !== 'ready' || !manifest) throw new Error('尚未安装可重启的更新');
		const active = readActive(home)?.current;
		if (active?.version !== manifest.version) throw new Error('待更新版本发生变化，请重新检查');
		validateRelease(active.root, active.version, home, trust);
		busy = true; state.status = 'restarting'; state.message = '正在重启应用…';
		return snapshot();
	}
	return { state: snapshot, running: () => busy, check, install, restart };
}

module.exports = { createUpdater, download };

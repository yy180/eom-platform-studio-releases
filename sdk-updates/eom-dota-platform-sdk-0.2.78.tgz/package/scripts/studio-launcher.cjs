#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { verifyRelease } = require('./release-signature.cjs');

const packageName = '@eom/dota-platform-sdk';
function loadTrust(file = path.join(__dirname, 'studio-trust.json')) {
	if (!fs.existsSync(file) || fs.lstatSync(file).isSymbolicLink()) throw new Error('缺少发布公钥配置，请使用重新生成的签名启动器');
	const trust = JSON.parse(fs.readFileSync(file, 'utf8'));
	return normalizeTrust(trust);
}

function normalizeTrust(trust) {
	if (trust?.schema !== 1 || typeof trust.publicKey !== 'string' || crypto.createPublicKey(trust.publicKey).asymmetricKeyType !== 'ed25519') throw new Error('发布公钥配置无效');
	if (trust.seedSha256 !== undefined && !/^[a-f0-9]{64}$/.test(trust.seedSha256)) throw new Error('安装包校验配置无效');
	if (trust.seedVersion !== undefined && !stableVersion(trust.seedVersion)) throw new Error('安装包版本配置无效');
	if (trust.updateUrl !== undefined) {
		const url = new URL(trust.updateUrl);
		if (url.protocol !== 'https:' || url.username || url.password || url.hash) throw new Error('在线更新地址必须使用 HTTPS');
	}
	return { schema: 1, publicKey: trust.publicKey, seedSha256: trust.seedSha256, seedSignature: trust.seedSignature, seedVersion: trust.seedVersion, updateUrl: trust.updateUrl };
}
const stableVersion = value => typeof value === 'string' && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(value) && value.split('.').every(part => Number.isSafeInteger(Number(part)));
function compareVersions(left, right) {
	if (!stableVersion(left) || !stableVersion(right)) throw new Error('Invalid stable SDK version');
	const a = left.split('.').map(Number), b = right.split('.').map(Number);
	for (let index = 0; index < 3; index++) if (a[index] !== b[index]) return a[index] > b[index] ? 1 : -1;
	return 0;
}

function getHome(env = process.env, platform = process.platform, userHome = os.homedir()) {
	return path.resolve(env.EOM_STUDIO_HOME || (platform === 'win32' && env.LOCALAPPDATA ? path.join(env.LOCALAPPDATA, 'EomPlatformStudio') : path.join(userHome, '.eom-platform-studio')));
}

function inside(parent, child) {
	const relative = path.relative(parent, child);
	return relative !== '' && !path.isAbsolute(relative) && relative !== '..' && !relative.startsWith('..' + path.sep);
}

function ensureHome(home) {
	fs.mkdirSync(home, { recursive: true });
	if (fs.lstatSync(home).isSymbolicLink()) throw new Error('Studio data directory cannot be a symbolic link');
	const releases = path.join(home, 'releases');
	fs.mkdirSync(releases, { recursive: true });
	if (fs.lstatSync(releases).isSymbolicLink()) throw new Error('Studio releases directory cannot be a symbolic link');
}

function regularPath(root, relative, directory = false) {
	let current = root;
	for (const part of relative.split('/')) {
		current = path.join(current, part);
		if (fs.lstatSync(current).isSymbolicLink()) throw new Error('SDK package contains a symbolic link');
	}
	const stat = fs.statSync(current);
	if (directory ? !stat.isDirectory() : !stat.isFile()) throw new Error('SDK package is incomplete');
}

function validateRelease(root, expectedVersion, home, trust = loadTrust()) {
	root = path.resolve(root);
	if (home) {
		const releases = path.join(path.resolve(home), 'releases');
		const relative = path.relative(releases, root);
		if (!inside(releases, root) || relative.split(path.sep).length !== 4 || !root.endsWith(path.join('node_modules', '@eom', 'dota-platform-sdk'))) throw new Error('SDK release path is outside the managed directory');
		regularPath(releases, relative.split(path.sep).join('/'), true);
	}
	if (fs.lstatSync(root).isSymbolicLink()) throw new Error('SDK package root cannot be a symbolic link');
	regularPath(root, 'package.json');
	const metadata = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
	if (metadata.name !== packageName || !stableVersion(metadata.version) || expectedVersion && metadata.version !== expectedVersion) throw new Error('SDK package identity does not match the requested version');
	verifyRelease(root, trust.publicKey, expectedVersion);
	for (const file of ['scripts/studio.cjs', 'studio/index.html', 'studio/app.js', 'studio/style.css', 'platform.config.example.json']) regularPath(root, file);
	for (const directory of ['dist/content', 'dist/game', 'templates', 'content/platform/maps', 'game/platform/maps', 'content/platform/localization/schinese', 'content/platform/localization/english', 'content/platform/localization/russian']) regularPath(root, directory, true);
	return { version: metadata.version, root };
}

function activeFile(home) { return path.join(home, 'active.json'); }
function readActive(home) {
	try {
		const file = activeFile(home);
		if (fs.lstatSync(file).isSymbolicLink()) return null;
		const state = JSON.parse(fs.readFileSync(file, 'utf8'));
		return state.schema === 1 ? state : null;
	} catch { return null; }
}
function writeActive(home, state) {
	const destination = activeFile(home);
	if (fs.existsSync(destination) && fs.lstatSync(destination).isSymbolicLink()) throw new Error('Studio active version file cannot be a symbolic link');
	const temporary = destination + '.' + crypto.randomUUID() + '.tmp';
	fs.writeFileSync(temporary, JSON.stringify({ schema: 1, current: state.current, previous: state.previous || null }, null, 2) + '\n', { flag: 'wx' });
	fs.renameSync(temporary, destination);
}

function processExists(pid) {
	if (!Number.isSafeInteger(pid) || pid < 1) return true;
	try { process.kill(pid, 0); return true; } catch (error) { return error.code !== 'ESRCH'; }
}
function acquireLock(home) {
	const file = path.join(home, 'update.lock');
	const owner = JSON.stringify({ pid: process.pid, nonce: crypto.randomUUID() });
	for (let attempt = 0; attempt < 2; attempt++) {
		try {
			fs.writeFileSync(file, owner, { flag: 'wx' });
			return () => {
				try { if (!fs.lstatSync(file).isSymbolicLink() && fs.readFileSync(file, 'utf8') === owner) fs.unlinkSync(file); } catch { /* Another process may already have recovered the lock. */ }
			};
		} catch (error) {
			if (error.code !== 'EEXIST') throw error;
			try {
				if (fs.lstatSync(file).isSymbolicLink()) throw new Error('Studio update lock cannot be a symbolic link');
				const contents = fs.readFileSync(file, 'utf8');
				if (processExists(JSON.parse(contents).pid)) return null;
				if (fs.readFileSync(file, 'utf8') === contents) fs.unlinkSync(file);
			} catch (problem) { if (problem.message === 'Studio update lock cannot be a symbolic link') throw problem; return null; }
		}
	}
	return null;
}

function npmCommand(env = process.env) {
	const executableDirectory = path.dirname(process.execPath);
	const pathValue = env[Object.keys(env).find(key => key.toLowerCase() === 'path')] || '';
	const candidates = [env.npm_execpath,
		path.join(executableDirectory, 'node_modules/npm/bin/npm-cli.js'),
		path.join(executableDirectory, '../lib/node_modules/npm/bin/npm-cli.js'),
		...pathValue.split(path.delimiter).filter(Boolean).map(directory => path.join(directory.replace(/^"|"$/g, ''), 'node_modules/npm/bin/npm-cli.js'))];
	try { candidates.push(path.join(path.dirname(require.resolve('npm/package.json')), 'bin/npm-cli.js')); } catch { /* npm need not be a dependency of this launcher. */ }
	for (const candidate of candidates) if (candidate && path.basename(candidate) === 'npm-cli.js' && fs.existsSync(candidate)) return { command: process.execPath, args: [candidate] };
	if (process.platform !== 'win32') return { command: 'npm', args: [] };
	throw new Error('Node.js 的 npm 未找到，请安装包含 npm 的 Node.js 18 或更高版本。');
}

function runNpm(args, { cwd, timeoutMs = 20000, env = process.env } = {}) {
	const command = npmCommand(env);
	return new Promise((resolve, reject) => {
		const child = spawn(command.command, [...command.args, ...args], { cwd, env, windowsHide: true, shell: false, stdio: ['ignore', 'pipe', 'ignore'] });
		let output = '', timedOut = false;
		const timer = setTimeout(() => { timedOut = true; child.kill(); }, timeoutMs);
		child.stdout.on('data', data => { output = (output + data.toString()).slice(-65536); });
		child.on('error', () => { clearTimeout(timer); reject(new Error('npm 无法运行，请检查 Node.js 安装。')); });
		child.on('close', code => {
			clearTimeout(timer);
			if (timedOut) reject(new Error('npm 本地安装超时。'));
			else if (code !== 0) reject(new Error('npm 本地安装失败，请重新获取完整安装包。'));
			else resolve(output);
		});
	});
}

function* availableReleases(home, fallbackRoot, trust) {
	const state = readActive(home);
	const candidates = [];
	for (const item of [state?.current, state?.previous]) {
		if (item && typeof item.root === 'string' && stableVersion(item.version)) candidates.push({ ...item, home });
	}
	if (fallbackRoot) {
		try {
			const metadata = JSON.parse(fs.readFileSync(path.join(fallbackRoot, 'package.json'), 'utf8'));
			if (metadata.name === packageName && stableVersion(metadata.version)) candidates.push({ root: fallbackRoot, version: metadata.version });
		} catch { /* Missing bundled payloads may fall back to the managed cache. */ }
	}
	const attempted = new Set(), verified = new Set();
	for (const item of candidates.sort((left, right) => compareVersions(right.version, left.version))) {
		const root = path.resolve(item.root), key = process.platform === 'win32' ? root.toLowerCase() : root;
		const attempt = JSON.stringify([key, item.version, item.home]);
		if (verified.has(key) || attempted.has(attempt)) continue;
		attempted.add(attempt);
		let release;
		try { release = validateRelease(root, item.version, item.home, trust); } catch { continue; }
		verified.add(key);
		yield release;
	}
}

async function installSeed({ home, seedPath, npm, env, trust, previous, log }) {
	if (!seedPath || !fs.existsSync(seedPath) || !fs.lstatSync(seedPath).isFile() || fs.lstatSync(seedPath).isSymbolicLink()) throw new Error('Invalid SDK seed archive');
	const seedHash = crypto.createHash('sha256').update(fs.readFileSync(seedPath)).digest('hex');
	if (!trust.seedSha256 || seedHash !== trust.seedSha256 || typeof trust.seedSignature !== 'string' || !crypto.verify(null, Buffer.from(seedHash), trust.publicKey, Buffer.from(trust.seedSignature, 'base64'))) throw new Error('SDK seed signature does not match');
	log('正在离线安装启动器附带的签名 SDK' + (trust.seedVersion ? ' v' + trust.seedVersion : '') + '…');
	const directory = path.join(home, 'releases', (trust.seedVersion || 'seed') + '-' + crypto.randomUUID());
	fs.mkdirSync(directory);
	fs.writeFileSync(path.join(directory, 'package.json'), JSON.stringify({ name: 'eom-platform-studio-cache', version: '1.0.0', private: true }) + '\n', { flag: 'wx' });
	await npm(['install', '--prefix', directory, path.resolve(seedPath), '--offline', '--ignore-scripts', '--bin-links=false', '--git=' + path.join(directory, 'git-disabled-' + crypto.randomUUID()), '--omit=dev', '--no-audit', '--no-fund', '--no-package-lock'], { cwd: directory, timeoutMs: 120000, env });
	const release = validateRelease(path.join(directory, 'node_modules/@eom/dota-platform-sdk'), trust.seedVersion, home, trust);
	writeActive(home, { current: release, previous: previous && inside(path.join(home, 'releases'), previous.root) ? previous : null });
	return { release, previous, warning: '', seeded: true };
}

async function prepareRelease({ home = getHome(), fallbackRoot, seedPath = path.join(__dirname, 'sdk.tgz'), npm = runNpm, log = console.log, env = process.env, trust = loadTrust() } = {}) {
	trust = normalizeTrust(trust);
	home = path.resolve(home);
	ensureHome(home);
	env = { ...env, npm_config_cache: path.join(home, 'npm-cache'), npm_config_update_notifier: 'false' };
	let candidates = availableReleases(home, fallbackRoot, trust);
	let current = candidates.next().value;
	const needsSeed = () => !current || trust.seedVersion !== undefined && compareVersions(trust.seedVersion, current.version) > 0;
	const selection = warning => ({ release: current, fallback: () => candidates.next().value || null, warning, seeded: false });
	if (!needsSeed()) return selection('');
	const releaseLock = acquireLock(home);
	if (!releaseLock) {
		if (!current) throw new Error('另一个启动器正在安装 SDK，请稍后重新启动。');
		return { ...selection('另一个启动器正在安装 SDK，本次使用已安装版本。'), busy: true };
	}
	try {
		candidates = availableReleases(home, fallbackRoot, trust);
		current = candidates.next().value;
		if (!needsSeed()) return selection('');
		if (!seedPath || !fs.existsSync(seedPath)) {
			if (current) return selection('附带 SDK 安装或签名校验失败，继续使用本机签名版本。');
			throw new Error('没有签名有效的本机版本，请重新获取完整的签名安装包。');
		}
		try { return await installSeed({ home, seedPath, npm, env, trust, previous: current || null, log }); }
		catch {
			if (current) return selection('附带 SDK 安装或签名校验失败，继续使用本机签名版本。');
			throw new Error('附带 SDK 安装或签名校验失败，请重新获取完整的签名安装包。');
		}
	} finally { releaseLock(); }
}

function runStudio(release, { env, spawnProcess = spawn, readyTimeoutMs = 30000 } = {}) {
	return new Promise(resolve => {
		let ready = false, interrupted = false, failureCode = '', done = false, restartRequested = false;
		const child = spawnProcess(process.execPath, [path.join(release.root, 'scripts/studio.cjs')], { cwd: release.root, env, windowsHide: true, shell: false, stdio: ['inherit', 'inherit', 'inherit', 'ipc'] });
		const timer = setTimeout(() => { failureCode = 'READY_TIMEOUT'; child.kill(); }, readyTimeoutMs);
		const interrupt = signal => { interrupted = true; child.kill(signal); };
		const onInterrupt = () => interrupt('SIGINT'), onTerminate = () => interrupt('SIGTERM');
		process.on('SIGINT', onInterrupt);
		process.on('SIGTERM', onTerminate);
		const finish = (code, signal) => {
			if (done) return;
			done = true;
			clearTimeout(timer);
			process.removeListener('SIGINT', onInterrupt);
			process.removeListener('SIGTERM', onTerminate);
			resolve({ ready, interrupted, failureCode, exitCode: interrupted ? 130 : Number.isInteger(code) ? code : 1, signal, ...(restartRequested ? { restartRequested: true } : {}) });
		};
		child.on('message', message => {
			if (message?.type === 'eom-studio-ready') { ready = true; clearTimeout(timer); }
			if (message?.type === 'eom-studio-error' && typeof message.code === 'string') failureCode = message.code;
			if (message?.type === 'eom-studio-restart' && ready && !restartRequested) { restartRequested = true; child.kill(); }
		});
		child.on('error', () => finish(1));
		child.on('close', finish);
	});
}

function rollback(home, failed, previous) {
	const releaseLock = acquireLock(home);
	if (!releaseLock) return;
	try {
		if (readActive(home)?.current?.root === failed.root) writeActive(home, { current: inside(path.join(home, 'releases'), previous.root) ? previous : null, previous: null });
	} finally { releaseLock(); }
}

async function launch({ home = getHome(), fallbackRoot = path.join(__dirname, 'sdk'), seedPath = path.join(__dirname, 'sdk.tgz'), npm = runNpm, startStudio = runStudio, log = console.log, env = process.env, readyTimeoutMs, trust = loadTrust() } = {}) {
	trust = normalizeTrust(trust);
	if (Number(process.versions.node.split('.')[0]) < 18) throw new Error('请安装 Node.js 18 或更高版本。');
	home = path.resolve(home);
	const selection = await prepareRelease({ home, fallbackRoot, seedPath, npm, log, env, trust });
	if (selection.warning) log(selection.warning);
	const childEnv = { ...env, EOM_STUDIO_HOME: path.join(home, 'workspace'), EOM_STUDIO_LAUNCHER_HOME: home, EOM_STUDIO_CONSUMER: '1', EOM_STUDIO_LAUNCHER: '1', EOM_STUDIO_OPEN_BROWSER: env.EOM_STUDIO_NATIVE === '1' ? '0' : '1', PORT: env.PORT || '4173' };
	let release = selection.release;
	let previousRelease = selection.previous;
	let result;
	let rolledBack = false;
	while (true) {
		result = await startStudio(release, { env: childEnv, readyTimeoutMs });
		if (result.failureCode === 'EADDRINUSE') {
			log('工作台已在运行：http://127.0.0.1:' + childEnv.PORT + '。请使用已打开的工作台。');
			return { version: release.version, root: release.root, seeded: selection.seeded, exitCode: 0, existing: true, rolledBack };
		}
		if (!result.ready && !result.interrupted) {
			const previous = previousRelease
				? validateRelease(previousRelease.root, previousRelease.version, inside(path.join(home, 'releases'), previousRelease.root) ? home : undefined, trust)
				: selection.fallback?.();
			if (previous) {
				log('工作台启动失败，正在回退到 v' + previous.version + '…');
				rollback(home, release, previous);
				release = previous;
				rolledBack = true;
				result = await startStudio(release, { env: childEnv, readyTimeoutMs });
			}
		}
		if (!result.restartRequested || result.interrupted) break;
		const next = readActive(home)?.current;
		if (!next || compareVersions(next.version, release.version) <= 0) throw new Error('没有已验证的新版本可用于重启');
		previousRelease = release;
		release = validateRelease(next.root, next.version, home, trust);
		childEnv.EOM_STUDIO_OPEN_BROWSER = '0';
	}
	return { version: release.version, root: release.root, seeded: selection.seeded, exitCode: result.exitCode, rolledBack };
}

if (require.main === module) launch().then(result => { process.exitCode = result.exitCode; }).catch(error => { console.error(error.message); process.exitCode = 1; });
module.exports = { launch, prepareRelease, runStudio, validateRelease, readActive, writeActive, acquireLock, getHome, stableVersion, compareVersions, npmCommand, loadTrust, installSeed, runNpm, ensureHome };

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { writePlan } = require('./write-plan.cjs');
const { addonRoots, resolveProjectPaths, getProjectMounts } = require('./project-paths.cjs');

const hash = data => crypto.createHash('sha256').update(data).digest('hex');
const stateName = config => '.eom-platform/' + config.addon + '/state.json';
const resolver = (target, config) => file => require('./automatic.cjs').safePath(target, file, getProjectMounts(config));
const read = file => fs.existsSync(file) ? fs.readFileSync(file) : null;
const checksum = data => data === null ? null : hash(data);
const canonical = file => {
	const resolved = fs.existsSync(file) ? fs.realpathSync(file) : path.resolve(file);
	return process.platform === 'win32' ? resolved.toLowerCase() : resolved;
};
const identity = (target, config) => ({ target: canonical(target), mounts: Object.fromEntries(Object.entries(getProjectMounts(config) || {}).sort(([left], [right]) => left.localeCompare(right)).map(([key, value]) => [key, canonical(value)])) });
const orderedDirectories = directories => [...new Set(directories)].sort((left, right) => right.split('/').length - left.split('/').length || left.localeCompare(right));

function sameManagedDestinations(target, config, ledger) {
	const previous = ledger.identity, current = identity(target, config);
	if (!previous || previous.target !== current.target || !ledger.files || !Array.isArray(ledger.createdDirectories)) return false;
	const roots = Object.values(addonRoots(config));
	const validMounts = mounts => mounts && typeof mounts === 'object' && !Array.isArray(mounts) && Object.entries(mounts).every(([key, value]) =>
		!key.includes('\\') && !key.split('/').some(part => !part || part === '.' || part === '..') && roots.some(root => key === root || key.startsWith(root + '/') || root.startsWith(key + '/')) && typeof value === 'string' && path.isAbsolute(value));
	if (!validMounts(previous.mounts) || !validMounts(current.mounts)) return false;
	const projection = binding => {
		const mounts = Object.entries(binding.mounts).sort(([left], [right]) => right.length - left.length);
		return file => {
			const comparison = process.platform === 'win32' ? file.toLowerCase() : file;
			const mount = mounts.find(([key]) => {
				const prefix = process.platform === 'win32' ? key.toLowerCase() : key;
				return comparison === prefix || comparison.startsWith(prefix + '/');
			});
			const destination = mount ? path.resolve(mount[1], file.slice(mount[0].length + 1)) : path.resolve(binding.target, file);
			return process.platform === 'win32' ? destination.toLowerCase() : destination;
		};
	};
	const before = projection(previous), after = projection(current);
	return [...Object.keys(ledger.files), ...ledger.createdDirectories].every(file => before(file) === after(file));
}

function validateLedger(target, config, state) {
	const ledger = state.ledger;
	if (state.schema !== 2 || !ledger || ledger.schema !== 1 || ledger.exact !== true || !ledger.files || !Array.isArray(ledger.createdDirectories)) throw new Error('This integration has no complete restoration record; use a backup from before SDK integration');
	if (!sameManagedDestinations(target, config, ledger)) throw new Error('Project location or link targets changed; restore using the original project and link targets');
	const { content, game } = addonRoots(config);
	const resolve = resolver(target, config), roots = [content + '/', game + '/', '.eom-platform/' + config.addon + '/'];
	for (const [file, item] of Object.entries(ledger.files)) {
		if (file === stateName(config) || !roots.some(root => file.startsWith(root)) || !item || !(item.before === null || typeof item.before === 'string' && Buffer.from(item.before, 'base64').toString('base64') === item.before) || !(item.after === null || /^[a-f0-9]{64}$/.test(item.after))) throw new Error('Invalid complete restoration file record: ' + file);
		resolve(file);
	}
	if (ledger.compiledOutputs !== undefined && (!Array.isArray(ledger.compiledOutputs) || ledger.compiledOutputs.some(file => !ledger.files[file] || !file.startsWith(game + '/panorama/') || !/\.(?:vjs|vcss|vxml|vtex)_c$/.test(file)))) throw new Error('Invalid compiled output restoration record');
	for (const directory of ledger.createdDirectories) {
		if (!['content', 'game', '.eom-platform', ...(config.integration?.layout === 'dota_addons' ? ['content/dota_addons', 'game/dota_addons'] : [])].includes(directory) && !roots.some(root => directory === root.slice(0, -1) || directory.startsWith(root))) throw new Error('Invalid restoration directory record');
		resolve(directory);
	}
	return ledger;
}

function missingParents(target, config, files, baseline = new Map()) {
	const resolve = resolver(target, config), preserved = new Set();
	for (const file of baseline.keys()) for (let directory = path.posix.dirname(file); directory !== '.'; directory = path.posix.dirname(directory)) preserved.add(directory);
	const directories = new Set();
	for (const file of files) {
		for (let directory = path.posix.dirname(file); directory !== '.'; directory = path.posix.dirname(directory)) {
			if (!fs.existsSync(resolve(directory)) && !preserved.has(directory)) directories.add(directory);
		}
	}
	return [...directories];
}

function directoryPlan(target, config, directories, changes) {
	const resolve = resolver(target, config), removed = new Set(), retained = [];
	for (const directory of orderedDirectories(directories)) {
		const full = resolve(directory);
		if (!fs.existsSync(full)) continue;
		if (fs.lstatSync(path.join(target, directory)).isSymbolicLink() || !fs.statSync(full).isDirectory()) throw new Error('SDK-created directory was replaced: ' + directory);
		const writes = [...changes].some(([file, data]) => data !== null && file.startsWith(directory + '/'));
		const remaining = fs.readdirSync(full).some(name => {
			const child = directory + '/' + name;
			return !removed.has(child) && !(changes.has(child) && changes.get(child) === null);
		});
		if (!writes && !remaining) removed.add(directory);
		else retained.push(directory);
	}
	return { directories: [...removed], retainedDirectories: retained };
}

function directoryChecks(target, config, directories) {
	const resolve = resolver(target, config);
	return orderedDirectories(directories).map(directory => {
		const full = resolve(directory);
		return [directory, fs.existsSync(full) ? fs.readdirSync(full, { withFileTypes: true }).map(entry => [entry.name, entry.isSymbolicLink() ? 'link:' + fs.readlinkSync(path.join(full, entry.name)) : entry.isDirectory() ? 'directory' : 'file']).sort(([left], [right]) => left.localeCompare(right)) : null];
	});
}

function finalizeIntegration(target, config, changes, { rebuilt = false, nativeBaseline = new Map(), retainedFiles = [] } = {}) {
	config = resolveProjectPaths(target, config);
	const resolve = resolver(target, config), name = stateName(config), previousBytes = read(resolve(name));
	const previous = previousBytes ? JSON.parse(previousBytes) : null;
	if (previous && previous.schema !== 2) return { exact: false, baseline: 'legacy', directories: [] };
	const next = JSON.parse(changes.get(name).toString('utf8'));
	const previousLedger = previous ? validateLedger(target, config, previous) : null;
	if (previousLedger) for (const [file, item] of Object.entries(previousLedger.files)) {
		const current = read(resolve(file));
		if (checksum(current) === item.after) continue;
		if (rebuilt && previous.generated[file]) continue;
		if (rebuilt && current === null && item.before === null && changes.has(file)) continue;
		throw new Error('Managed SDK file changed; cannot update integration: ' + file);
	}
	const records = {};
	for (const [file, data] of changes) {
		if (file === name) continue;
		const current = read(resolve(file)), old = previousLedger?.files[file];
		let before = old ? old.before : nativeBaseline.has(file) ? nativeBaseline.get(file).toString('base64') : current?.toString('base64') ?? null;
		if (old && rebuilt && previous.generated[file] && checksum(current) !== old.after) {
			const original = next.originals[file];
			before = original ? changes.get(original.backup).toString('base64') : null;
		}
		records[file] = { before, after: checksum(data) };
	}
	for (const [file, item] of Object.entries(previousLedger?.files || {})) if (!changes.has(file)) {
		if (retainedFiles.includes(file) || previousLedger.compiledOutputs?.includes(file)) records[file] = item;
		else if (rebuilt && previous.generated[file] && !next.generated[file] && checksum(read(resolve(file))) !== item.after) continue;
		else changes.set(file, item.before === null ? null : Buffer.from(item.before, 'base64'));
	}
	const createdDirectories = orderedDirectories([...(previousLedger?.createdDirectories || []), ...missingParents(target, config, [...changes].filter(([, data]) => data !== null).map(([file]) => file), nativeBaseline)]);
	const cleanup = directoryPlan(target, config, createdDirectories, changes);
	next.schema = 2;
	next.ledger = { schema: 1, exact: true, baseline: previousLedger?.baseline || (nativeBaseline.size ? 'native-template' : 'existing-project'), identity: identity(target, config), files: records, createdDirectories: createdDirectories.filter(directory => !cleanup.directories.includes(directory)) };
	if (previousLedger?.compiledOutputs) next.ledger.compiledOutputs = previousLedger.compiledOutputs.filter(file => records[file]);
	changes.set(name, Buffer.from(JSON.stringify(next, null, 2) + '\n'));
	return { exact: true, baseline: next.ledger.baseline, directories: cleanup.directories };
}

function restoreIntegration(target, config, { dryRun = false } = {}) {
	config = resolveProjectPaths(target, config);
	const resolve = resolver(target, config), name = stateName(config), stateBytes = read(resolve(name));
	if (!stateBytes) throw new Error('No SDK integration restoration record was found');
	const state = JSON.parse(stateBytes), ledger = validateLedger(target, config, state), changes = new Map(), checks = [], changedFiles = [];
	for (const [file, item] of Object.entries(ledger.files)) {
		const actual = checksum(read(resolve(file)));
		if (actual !== item.after) changedFiles.push({ file, change: actual === null ? 'deleted' : item.after === null ? 'created' : 'modified' });
		checks.push({ file, sha256: actual });
		changes.set(file, item.before === null ? null : Buffer.from(item.before, 'base64'));
	}
	checks.push({ file: name, sha256: hash(stateBytes) });
	changes.set(name, null);
	const cleanup = directoryPlan(target, config, ledger.createdDirectories, changes);
	const fingerprint = hash(Buffer.from(JSON.stringify([checks, directoryChecks(target, config, ledger.createdDirectories)])));
	if (!dryRun) writePlan([...changes].map(([file, data]) => ({ destination: resolve(file), data })), { removeDirectories: cleanup.directories.map(resolve) });
	return { exact: true, baseline: ledger.baseline, files: [...changes.keys()], actions: [...changes].map(([file, data]) => ({ file, action: data === null ? 'remove' : 'restore' })), ...cleanup, changedFiles, checks, fingerprint, signatureDigest: fingerprint, dryRun };
}

function restorationStatus(target, config) {
	config = resolveProjectPaths(target, config);
	const resolve = resolver(target, config), name = stateName(config);
	if (!fs.existsSync(resolve(name))) {
		const enabled = fs.existsSync(resolve(addonRoots(config).game + '/scripts/eom_platform_manifest.json'));
		return { enabled, canDisable: false, restoration: enabled ? 'legacy' : 'none', reason: enabled ? 'This SDK integration has no complete restoration record' : null };
	}
	try {
		const state = JSON.parse(fs.readFileSync(resolve(name), 'utf8'));
		if (state.schema !== 2 || state.ledger?.exact !== true) return { enabled: true, canDisable: false, restoration: 'legacy', reason: 'This older integration cannot be completely disabled without a pre-integration backup' };
		if (!sameManagedDestinations(target, config, state.ledger)) return { enabled: true, canDisable: false, restoration: 'exact', reason: 'Project location or link targets changed; use the original project and link targets', baseline: state.ledger.baseline };
		const encrypted = fs.existsSync(resolve('.eom-platform/' + config.addon + '/encryption.json'));
		return { enabled: true, canDisable: !encrypted, restoration: 'exact', reason: encrypted ? 'Restore encrypted outputs before disabling the SDK' : null, baseline: state.ledger.baseline };
	} catch (error) { return { enabled: true, canDisable: false, restoration: 'legacy', reason: error.message }; }
}

module.exports = { finalizeIntegration, restoreIntegration, restorationStatus };

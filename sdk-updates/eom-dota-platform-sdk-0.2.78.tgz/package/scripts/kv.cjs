// Valve KeyValues 1: retain source ranges so unrelated entries keep their formatting.
function parseKV(text) {
	const tokens = [];
	const pattern = /\s+|\/\/[^\r\n]*|\/\*[\s\S]*?\*\/|"(?:\\.|[^"\\])*"|[{}]|[^\s{}"]+/gy;
	let offset = 0;
	while (offset < text.length) {
		pattern.lastIndex = offset;
		const match = pattern.exec(text);
		if (!match) throw new Error('Unsupported KeyValues at ' + offset);
		offset = pattern.lastIndex;
		if (/^\s|^\/\//.test(match[0]) || match[0].startsWith('/*')) continue;
		tokens.push({ value: match[0][0] === '"' ? match[0].slice(1, -1).replace(/\\(["\\])/g, '$1') : match[0], start: match.index, end: offset });
	}
	let index = 0;
	function entries(nested) {
		const result = [];
		while (index < tokens.length && tokens[index].value !== '}') {
			const key = tokens[index++];
			const value = tokens[index++];
			if (!value || key.value === '{' || value.value === '}') throw new Error('Malformed KeyValues');
			if (value.value === '{') {
				const children = entries(true);
				const close = tokens[index++];
				if (close?.value !== '}') throw new Error('Unclosed KeyValues object');
				result.push({ key: key.value, children, start: key.start, end: close.end, close: close.start });
			} else result.push({ key: key.value, value: value.value, start: key.start, end: value.end });
		}
		if (!nested && index !== tokens.length) throw new Error('Unexpected KeyValues closing brace');
		return result;
	}
	return entries(false);
}

function mergeEvents(text) {
	if (!text) text = '"CustomEvents"\n{\n}\n';
	const roots = parseKV(text);
	if (roots.length !== 1 || roots[0].key !== 'CustomEvents' || !roots[0].children) throw new Error('Expected CustomEvents KeyValues object');
	const root = roots[0];
	const matches = root.children.filter(entry => entry.key === 'client_side_event');
	if (matches.length > 1) throw new Error('Duplicate client_side_event declarations');
	const existing = matches[0];
	if (existing) {
		for (const field of ['event_name', 'event_data']) {
			const entries = existing.children?.filter(entry => entry.key === field) ?? [];
			if (entries.length !== 1 || entries[0].value !== 'string') throw new Error('Conflicting client_side_event.' + field);
		}
		return text;
	}
	return text.slice(0, root.close) + '\t"client_side_event"\n\t{\n\t\t"event_name" "string"\n\t\t"event_data" "string"\n\t}\n' + text.slice(root.close);
}

module.exports = { parseKV, mergeEvents };

const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');

// Stage every file next to its destination before replacing any file. On a failed
// replacement, restore already changed files; never leave a half-written Lua entry.
function writePlan(operations, { removeDirectories = [] } = {}) {
	const staged = [], applied = [], createdDirectories = [], removedDirectories = [];
	const directoryOrder = (left, right) => right.split(path.sep).length - left.split(path.sep).length;
	function ensureDirectory(directory) {
		const missing = [];
		let current = directory;
		while (!fs.existsSync(current)) { missing.push(current); current = path.dirname(current); }
		for (const item of missing.reverse()) { fs.mkdirSync(item); createdDirectories.push(item); }
	}
	try {
		for (const { destination, data } of operations) {
			const before = fs.existsSync(destination) ? fs.readFileSync(destination) : null;
			if (data && before?.equals(data)) continue;
			if (data) ensureDirectory(path.dirname(destination));
			const temporary = data ? destination + '.eom-' + randomUUID() : null;
			const item = { destination, data, before, temporary };
			staged.push(item);
			if (temporary) fs.writeFileSync(temporary, data, { flag: 'wx' });
		}
		for (const item of staged) {
			if (item.temporary) fs.renameSync(item.temporary, item.destination);
			else if (item.before) fs.unlinkSync(item.destination);
			applied.push(item);
		}
		for (const directory of [...new Set(removeDirectories)].sort(directoryOrder)) {
			if (!fs.existsSync(directory)) continue;
			const stats = fs.lstatSync(directory);
			if (stats.isSymbolicLink() || !stats.isDirectory()) throw new Error('Refusing to remove a linked or non-directory path: ' + directory);
			if (fs.readdirSync(directory).length) continue;
			fs.rmdirSync(directory);
			removedDirectories.push(directory);
		}
	} catch (error) {
		const failures = [];
		for (const directory of removedDirectories.reverse()) {
			try { fs.mkdirSync(directory, { recursive: true }); }
			catch (rollback) { failures.push(directory + ': ' + rollback.message); }
		}
		for (const item of applied.reverse()) {
			try {
				if (item.before) fs.writeFileSync(item.destination, item.before);
				else if (fs.existsSync(item.destination)) fs.unlinkSync(item.destination);
			} catch (rollback) { failures.push(item.destination + ': ' + rollback.message); }
		}
		if (failures.length) error.message += '\nRollback requires attention:\n' + failures.join('\n');
		throw error;
	} finally {
		for (const item of staged) if (item.temporary && fs.existsSync(item.temporary)) fs.unlinkSync(item.temporary);
		for (const directory of createdDirectories.reverse()) {
			if (fs.existsSync(directory) && !fs.lstatSync(directory).isSymbolicLink() && fs.statSync(directory).isDirectory() && !fs.readdirSync(directory).length) fs.rmdirSync(directory);
		}
	}
}

module.exports = { writePlan };

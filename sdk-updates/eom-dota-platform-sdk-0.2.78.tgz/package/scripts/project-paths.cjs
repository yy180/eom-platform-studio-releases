'use strict';
const fs = require('node:fs');
const path = require('node:path');
const runtimePaths = Symbol('project filesystem paths');

function portableProjectConfig(config) {
	if (!config || typeof config !== 'object') return config;
	if (!config[runtimePaths] && !Object.hasOwn(config.integration ?? {}, 'mounts')) return config;
	const portable = { ...config };
	delete portable[runtimePaths];
	if (Object.hasOwn(config.integration ?? {}, 'mounts')) {
		portable.integration = { ...config.integration };
		delete portable.integration.mounts;
	}
	return portable;
}

function getProjectMounts(config) {
	return config?.[runtimePaths]?.mounts ?? {};
}

// A filesystem snapshot belongs to one operation, never to portable settings.
// Enumerable symbols survive config spreads but cannot enter JSON exports.
function resolveProjectPaths(target, config, { refresh = false } = {}) {
	const full = path.resolve(target), key = process.platform === 'win32' ? full.toLowerCase() : full;
	const snapshot = config?.[runtimePaths];
	if (!refresh && snapshot?.target === key && snapshot.addon === config.addon && snapshot.layout === (config.integration?.layout ?? 'flat')) {
		return Object.hasOwn(config.integration ?? {}, 'mounts') ? { ...portableProjectConfig(config), [runtimePaths]: snapshot } : config;
	}
	const portable = portableProjectConfig(config);
	const mounts = Object.freeze(discoverAddonMounts(full, portable));
	return { ...portable, [runtimePaths]: Object.freeze({ target: key, addon: portable.addon, layout: portable.integration?.layout ?? 'flat', mounts }) };
}

function addonRoots(config) {
	if (!config || !/^[a-z][a-z0-9_]*$/.test(config.addon)) throw new Error('addon must be a lowercase addon directory name');
	const layout = config.integration?.layout ?? 'flat';
	if (!['flat', 'dota_addons'].includes(layout)) throw new Error('integration.layout must be flat or dota_addons');
	const directory = (layout === 'dota_addons' ? 'dota_addons/' : '') + config.addon;
	return { content: 'content/' + directory, game: 'game/' + directory };
}

function discoverAddonMounts(target, config) {
	const mounts = {};
	const canonical = value => process.platform === 'win32' ? value.toLowerCase() : value;
	function inspect(relative) {
		const full = path.join(target, relative), stats = fs.lstatSync(full, { throwIfNoEntry: false });
		if (!stats) return null;
		if (!stats.isSymbolicLink()) return { full, stats };
		try {
			mounts[relative] = fs.realpathSync(full);
			return { full, stats: fs.statSync(full) };
		} catch (error) {
			const destination = path.resolve(path.dirname(full), fs.readlinkSync(full));
			const issue = ['ENOENT', 'ENOTDIR'].includes(error.code) ? '目录链接已断开' : '目录链接目标无法访问';
			throw new Error(relative.split('/')[0] + ' ' + issue + '。\n项目目录：' + full + '\n链接目标：' + destination + '\n请检查目标盘符和目录是否可访问，并恢复正确的目录链接。（' + error.code + '）');
		}
	}
	function visit(relative, ancestors = new Set()) {
		const entry = inspect(relative);
		if (!entry?.stats.isDirectory()) return;
		const real = canonical(fs.realpathSync(entry.full));
		if (ancestors.has(real)) throw new Error('项目目录存在循环链接：' + entry.full);
		const next = new Set([...ancestors, real]);
		for (const child of fs.readdirSync(entry.full, { withFileTypes: true })) {
			if (child.isDirectory() || child.isSymbolicLink()) visit(relative + '/' + child.name, next);
		}
	}
	for (const root of Object.values(addonRoots(config))) {
		const parts = root.split('/');
		for (let count = 1; count < parts.length; count++) inspect(parts.slice(0, count).join('/'));
		visit(root);
	}
	return Object.fromEntries(Object.entries(mounts).sort(([left], [right]) => left.localeCompare(right)));
}

module.exports = { addonRoots, discoverAddonMounts, resolveProjectPaths, getProjectMounts, portableProjectConfig };

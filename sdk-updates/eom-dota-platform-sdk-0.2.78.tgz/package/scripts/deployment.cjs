function serverDeployment(config) {
	return {
		status: 'requires_server_deployment',
		addon: config.workshopId,
		lobbies: Object.keys(config.lobbies).filter(region => config.lobbies[region]).map(region => ({
			region, address: config.lobbies[region],
			lua: 'if IsServer() and IsDedicatedServer() then\n' +
				'assert(type(PlatformLobbyConfig) == "table", "Missing lobby gateway configuration")\n' +
				'PlatformLobbyConfig.lobbyAddress = ' + JSON.stringify(config.lobbies[region]) + '\nend\n',
		})),
	};
}

module.exports = { serverDeployment };

#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawn, spawnSync } = require('node:child_process');
const { parseKV } = require('./kv.cjs');
const { validate } = require('./install.cjs');
const { safePath } = require('./automatic.cjs');
const { addonRoots, resolveProjectPaths, getProjectMounts } = require('./project-paths.cjs');
const { captureBuildOutputs, recordBuildOutputs } = require('./build-outputs.cjs');
const { assertNoWatchers } = require('./project-activity.cjs');
const { panoramaResources, assertCompiledResources } = require('./platform-resources.cjs');

const compiledExtensions = { '.xml': '.vxml_c', '.js': '.vjs_c', '.css': '.vcss_c', '.png': '_png.vtex_c', '.jpg': '_jpg.vtex_c', '.jpeg': '_jpeg.vtex_c' };
const canonical = file => {
	const real = fs.realpathSync(file);
	return process.platform === 'win32' ? real.toLowerCase() : real;
};

function steamInstallations() {
	const directories = new Set();
	if (process.platform === 'win32') {
		for (const [key, name, view] of [
			['HKCU\\Software\\Valve\\Steam', 'SteamPath'],
			['HKLM\\Software\\Valve\\Steam', 'InstallPath', '/reg:32'],
			['HKLM\\Software\\Valve\\Steam', 'InstallPath', '/reg:64'],
		]) {
			const result = spawnSync('reg.exe', ['query', key, '/v', name, ...(view ? [view] : [])], { encoding: 'utf8', windowsHide: true, timeout: 1000 });
			const registered = new RegExp(name + '\\s+REG_SZ\\s+([^\\r\\n]+)', 'i').exec(result.stdout ?? '');
			if (registered) directories.add(registered[1].trim());
		}
		for (const variable of ['ProgramFiles(x86)', 'ProgramFiles']) if (process.env[variable]) directories.add(path.join(process.env[variable], 'Steam'));
	}
	return [...directories];
}

function linkedPaths(file) {
	const paths = [], seen = new Set();
	let current = path.resolve(file);
	while (paths.length < 64) {
		const key = process.platform === 'win32' ? current.toLowerCase() : current;
		if (seen.has(key)) break;
		seen.add(key);
		paths.push(current);
		const root = path.parse(current).root, parts = current.slice(root.length).split(path.sep);
		let prefix = root, next;
		for (let index = 0; index < parts.length; index++) {
			prefix = path.join(prefix, parts[index]);
			if (!fs.lstatSync(prefix, { throwIfNoEntry: false })?.isSymbolicLink()) continue;
			next = path.resolve(path.dirname(prefix), fs.readlinkSync(prefix), ...parts.slice(index + 1));
			break;
		}
		if (!next) break;
		current = next;
	}
	return paths;
}

function readValveObject(file, name) {
	try { return parseKV(fs.readFileSync(file, 'utf8')).find(entry => entry.key.toLowerCase() === name)?.children ?? []; }
	catch { return []; }
}

function addonDirectory(file) {
	const links = linkedPaths(file);
	let actual;
	try { if (fs.statSync(file).isDirectory()) actual = fs.realpathSync(file); } catch {}
	return { path: file, actual, linked: links.length > 1, linkTarget: links.length > 1 ? links.at(-1) : null };
}

function addonMismatch(directory, config, project) {
	const differences = [], matched = [];
	for (const layer of ['content', 'game']) {
		const installed = addonDirectory(path.join(directory, layer, 'dota_addons', config.addon));
		const selected = addonDirectory(project[layer]);
		if (installed.actual && selected.actual && canonical(installed.actual) === canonical(selected.actual)) matched.push(layer);
		else differences.push({ layer, installed, selected });
	}
	return { directory, differences, matched };
}

function describeAddonMismatch(report) {
	const issue = ({ installed, selected }) => [installed, selected].some(entry => entry.linked && !entry.actual) ? '链接已断开' : installed.linked || selected.linked ? '链接指向了其他位置' : '链接未生效';
	const lines = [report.differences.map(item => item.layer + ' 目录' + issue(item)).join('；') + '。', '已找到 Dota 2 开发工具。'];
	if (report.matched.length) lines.push(report.matched.join('、') + ' 目录连接正常。');
	function describe(label, entry) {
		lines.push(label + '：' + entry.path);
		if (entry.actual) lines.push('  实际路径：' + entry.actual + (entry.linked ? '（目录链接）' : '（普通目录）'));
		else if (entry.linked) lines.push('  链接目标：' + entry.linkTarget + '（无法访问，链接已断开）');
		else lines.push('  该目录不存在或无法访问。');
	}
	for (const { layer, installed, selected } of report.differences) {
		const linked = installed.linked || selected.linked;
		lines.push('Dota 和所选项目的 ' + layer + ' 目录没有连接到同一份文件。');
		describe('项目 ' + layer + ' 目录（项目路径）', selected);
		describe('Dota ' + layer + ' 目录', installed);
		if (!linked) lines.push('如果之前建立过链接，它可能已失效或被删除；Git 恢复文件后可能生成普通目录，但不会重建目录链接。');
		lines.push('请检查并重新建立 ' + layer + ' 目录链接，使上述两个目录连接到同一份项目文件。重新建立前请先保留两侧现有文件。');
	}
	return lines.join('\n');
}

function findPanoramaCompiler(target, config, { dotaRoot, steamRoots } = {}) {
	config = resolveProjectPaths(target, config);
	const roots = addonRoots(config);
	const project = Object.fromEntries(Object.entries(roots).map(([layer, relative]) => {
		const full = safePath(target, relative, getProjectMounts(config));
		if (!fs.existsSync(full) || !fs.statSync(full).isDirectory()) throw new Error('项目缺少 ' + layer + ' 目录，无法编译 Panorama：' + full);
		return [layer, path.join(target, relative)];
	}));
	const candidates = new Set(dotaRoot ? [path.resolve(dotaRoot)] : []);
	if (!dotaRoot) for (const layer of ['content', 'game']) {
		// Keep intermediate junction targets: realpath alone can erase the Dota
		// installation when its addon directory links back to a source repository.
		for (const addon of linkedPaths(path.join(target, roots[layer]))) {
			const directory = path.dirname(addon), parent = path.dirname(directory);
			if (path.basename(addon).toLowerCase() === config.addon && path.basename(directory).toLowerCase() === 'dota_addons' && path.basename(parent).toLowerCase() === layer) candidates.add(path.dirname(parent));
		}
	}
	const missingTools = new Set(), mismatched = new Map(), checked = new Set();
	function find() {
		for (const directory of candidates) {
			const key = process.platform === 'win32' ? directory.toLowerCase() : directory;
			if (checked.has(key)) continue;
			checked.add(key);
			const compiler = path.join(directory, 'game/bin/win64/resourcecompiler.exe');
			const tools = fs.existsSync(compiler) && fs.statSync(compiler).isFile();
			if (!tools && !fs.existsSync(path.join(directory, 'game/dota/gameinfo.gi'))) continue;
			const report = addonMismatch(directory, config, project);
			if (!report.differences.length && tools) return { dotaRoot: directory, compiler };
			if (!tools) missingTools.add(directory);
			else mismatched.set(directory, report);
		}
	}
	let found = find();
	if (found) return found;
	if (!dotaRoot) {
		for (const steam of steamRoots ?? steamInstallations()) {
			const libraries = new Set([steam]);
			for (const relative of ['steamapps/libraryfolders.vdf', 'config/libraryfolders.vdf']) {
				for (const folder of readValveObject(path.join(steam, relative), 'libraryfolders')) {
					const library = folder.children?.find(entry => entry.key === 'path')?.value ?? (/^\d+$/.test(folder.key) ? folder.value : undefined);
					if (library && path.isAbsolute(library)) libraries.add(library);
				}
			}
			for (const library of libraries) {
				const manifest = readValveObject(path.join(library, 'steamapps/appmanifest_570.acf'), 'appstate');
				const installation = manifest.find(entry => entry.key.toLowerCase() === 'installdir')?.value;
				if (installation && !/[\\/]/.test(installation) && !['.', '..'].includes(installation)) candidates.add(path.join(library, 'steamapps/common', installation));
				candidates.add(path.join(library, 'steamapps/common/dota 2 beta'));
			}
		}
		found = find();
		if (found) return found;
	}
	if (mismatched.size) throw new Error(describeAddonMismatch([...mismatched.values()].sort((a, b) => b.matched.length - a.matched.length)[0]));
	if (missingTools.size) throw new Error('已找到 Dota 2，但缺少资源编译器。请在 Steam 中安装 Dota 2 Workshop Tools：' + [...missingTools].join(', '));
	throw new Error('找不到与当前项目对应的 Dota 2 开发工具。请确认已安装 Dota 2 Workshop Tools，并将项目的 content/game 目录挂载到同一 Dota 安装目录的 dota_addons/' + config.addon + '。');
}

function runCompiler(command, args, { cwd, log }) {
	return new Promise((resolve, reject) => {
		const child = spawn(command, args, { cwd, shell: false, windowsHide: true });
		child.stdout.on('data', data => log(data.toString()));
		child.stderr.on('data', data => log(data.toString()));
		child.on('error', reject);
		child.on('close', (code, signal) => code === 0 ? resolve() : reject(new Error('Panorama resource compiler failed: ' + (signal ?? 'exit ' + code))));
	});
}

async function compilePanorama({ target, config, compiler, dotaRoot, run = runCompiler, log = text => process.stdout.write(text) }) {
	if (typeof target !== 'string' || !path.isAbsolute(target)) throw new Error('target must be an absolute project directory');
	config = resolveProjectPaths(target, config);
	validate(config);
	if (compiler === undefined) ({ compiler, dotaRoot } = findPanoramaCompiler(target, config, { dotaRoot }));
	if (typeof compiler !== 'string' || !path.isAbsolute(compiler) || !fs.statSync(compiler).isFile()) throw new Error('compiler must be an absolute resourcecompiler executable path');
	target = path.resolve(target);
	assertNoWatchers(target);
	const roots = addonRoots(config);
	const resolve = file => safePath(target, file, getProjectMounts(config));
	dotaRoot = path.resolve(dotaRoot ?? path.resolve(path.dirname(compiler), '../../..'));
	for (const root of Object.values(roots)) resolve(root);
	const mismatch = addonMismatch(dotaRoot, config, Object.fromEntries(Object.entries(roots).map(([layer, relative]) => [layer, path.join(target, relative)])));
	if (mismatch.differences.length) throw new Error(describeAddonMismatch(mismatch));
	const embedded = config.integration?.mode !== 'manual' && fs.existsSync(resolve(roots.game + '/scripts/eom_platform_manifest.json'));
	if (embedded) for (const relative of panoramaResources) {
		const file = roots.content + '/' + relative.replace(/\.v(xml|js|css)_c$/, '.$1');
		const full = resolve(file);
		if (!fs.existsSync(full) || !fs.statSync(full).isFile() || fs.statSync(full).size === 0) throw new Error('Missing or empty embedded platform Panorama source: ' + file + '; reinstall the SDK before compiling');
	}
	function walk(relative, onFile, onDirectory = () => {}, ancestors = new Set()) {
		const full = resolve(relative);
		if (!fs.existsSync(full)) return;
		const real = canonical(full);
		if (ancestors.has(real)) throw new Error('Circular Panorama directory: ' + relative);
		if (!fs.statSync(full).isDirectory()) { onFile(relative); return; }
		onDirectory(relative);
		const next = new Set([...ancestors, real]);
		for (const name of fs.readdirSync(full).sort()) walk(relative + '/' + name, onFile, onDirectory, next);
	}
	function compiledTree() {
		const files = [], directories = new Set();
		walk(roots.game + '/panorama', file => { if (/\.(?:vxml|vjs|vcss|vtex)_c$/i.test(file)) files.push(file); }, directory => directories.add(directory));
		return { files, directories };
	}
	const sources = [], batches = [], xml = new Set();
	function source(file) {
		const extension = path.posix.extname(file).toLowerCase();
		const addonRelative = file.slice(roots.content.length + 1);
		const output = roots.game + '/' + addonRelative.slice(0, -extension.length) + compiledExtensions[extension];
		resolve(output);
		sources.push({ file, output });
	}
	const groups = [
		['panorama/images/custom_game/eom_platform', ['.png', '.jpg', '.jpeg']],
		['panorama/styles/custom_game/eom_platform', ['.js', '.css']],
		['panorama/layout/custom_game', ['.js', '.css']],
		['panorama/scripts/custom_game/eom_platform', ['.js', '.css']],
	];
	for (const [directory, extensions] of groups) {
		const found = new Set();
		walk(roots.content + '/' + directory, file => {
			const extension = path.posix.extname(file).toLowerCase();
			if (!extensions.includes(extension)) return;
			source(file);
			found.add(extension);
		});
		// Panorama styles synthesize image texture resources from PNG/JPEG URLs;
		// resourcecompiler cannot compile the bitmap source as a top-level input.
		if (directory.startsWith('panorama/images/')) continue;
		for (const extension of [...found].sort()) {
			const args = ['-i', path.join(dotaRoot, 'content', 'dota_addons', config.addon, directory, '*' + extension), '-r', '-nop4'];
			if (directory.endsWith('/eom_platform')) args.push('-fshallow');
			if (!directory.startsWith('panorama/styles/custom_game/eom_platform')) args.push('-skiptype', 'vtex');
			batches.push(args);
		}
	}
	const layout = roots.content + '/panorama/layout/custom_game/';
	for (const file of ['custom_ui_manifest.xml', 'custom_loading_screen.xml', 'team_select.xml']) if (fs.existsSync(resolve(layout + file))) xml.add(layout + file);
	for (const directory of ['eom_platform', 'tooltips', 'popups', 'context_menu']) walk(layout + directory, file => { if (file.endsWith('.xml')) xml.add(file); });
	for (const file of [...xml].sort()) {
		source(file);
		const args = ['-i', path.join(dotaRoot, 'content', 'dota_addons', config.addon, file.slice(roots.content.length + 1)), '-r', '-nop4'];
		if (file.startsWith(layout + 'eom_platform/')) args.push('-fshallow');
		args.push('-skiptype', 'vtex');
		batches.push(args);
	}
	const outputs = [...new Set(sources.map(item => item.output))].sort();
	// Resourcecompiler may also rewrite dependency assets. Preserve the complete
	// existing Panorama output set, then register newly discovered outputs as additions.
	const baseline = compiledTree();
	const snapshot = captureBuildOutputs(target, config, [...new Set([...baseline.files, ...outputs])]);
	let failure, platform = null;
	try {
		for (const args of batches) {
			log('[platform] Compile Panorama: ' + args[1] + '\n');
			await run(compiler, args, { cwd: dotaRoot, log });
		}
		for (const file of outputs) if (!fs.existsSync(resolve(file))) throw new Error('Panorama compiler did not produce the expected output: ' + file);
		if (embedded) platform = assertCompiledResources(target, config);
	} catch (error) { failure = error; }
	finally {
		try {
			if (snapshot) {
				const after = compiledTree(), recorded = new Set(snapshot.entries.map(entry => entry.file));
				for (const file of after.files) if (!recorded.has(file)) snapshot.entries.push({ file, before: null, checksum: null });
				for (const directory of after.directories) if (!baseline.directories.has(directory)) snapshot.directories.push(directory);
			}
			recordBuildOutputs(target, config, snapshot);
		}
		catch (error) {
			if (failure) failure.message += '\nCompiled output restoration record failed: ' + error.message;
			else failure = error;
		}
	}
	if (failure) throw failure;
	return { target, addon: config.addon, compiler, dotaRoot, sources: sources.length, outputs: outputs.length, commands: batches.length, platform, tracked: snapshot !== null };
}

async function main() {
	const args = process.argv.slice(2), options = {};
	for (let index = 0; index < args.length; index++) {
		const key = args[index];
		if (!['--target', '--config', '--compiler', '--dota-root'].includes(key) || !args[index + 1] || args[index + 1].startsWith('--')) throw new Error('Usage: compile-panorama --target <absolute project> --config <json> [--compiler <absolute resourcecompiler>] [--dota-root <directory>]');
		options[key.slice(2)] = args[++index];
	}
	if (!options.target || !options.config) throw new Error('--target and --config are required');
	const config = JSON.parse(fs.readFileSync(path.resolve(options.config), 'utf8'));
	const report = await compilePanorama({ target: options.target, config, compiler: options.compiler, dotaRoot: options['dota-root'] });
	process.stdout.write(JSON.stringify(report, null, 2) + '\n');
}

if (require.main === module) main().catch(error => { process.stderr.write(error.message + '\n'); process.exitCode = 1; });
module.exports = { compilePanorama, findPanoramaCompiler };

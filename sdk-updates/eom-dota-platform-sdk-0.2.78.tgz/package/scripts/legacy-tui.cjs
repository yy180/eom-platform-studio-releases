const fs = require('node:fs');
const path = require('node:path');

function normalize(text) {
	text = text.replace(/^__TS__SourceMapTraceBack\(debug\.getinfo\(1\)\.short_src,\s*\{(?:\["\d+"\]\s*=\s*\d+\s*,?\s*)*\}\);?\r?$/gm, '');
	const tokens = text.match(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|--[^\r\n]*|\s+|[^]/g) ?? [];
	return tokens.filter(token => !/^\s|^--/.test(token)).join('').replace(/ifGameRules:State_Get\(\)<DOTA_GAMERULES_STATE_CUSTOM_GAME_SETUPthenreturnend/g, '');
}

function validateLegacy(server, client) {
	for (const [name, source] of [['server', server], ['client', client]]) {
		const known = fs.readFileSync(path.join(__dirname, '../templates/legacy_tui_' + name + '.lua'), 'utf8');
		const body = known.slice(known.indexOf('-- @noSelfInFile *') + '-- @noSelfInFile *'.length);
		const normalized = normalize(source);
		const clientOnly = ['platformClientModule="eom_platform.client"require(platformClientModule)', 'require("eom_platform.client")'];
		if (normalized !== normalize(known) && normalized !== normalize(body) && !(name === 'client' && clientOnly.includes(normalized))) throw new Error('Unrecognized legacy TUI ' + name + ' entry; original artifact contains changes outside the supported migration');
	}
}

module.exports = { validateLegacy };

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { loadingLayout, loadingConfigScript, layoutPath } = require('./loading.cjs');
const { automatic, safePath } = require('./automatic.cjs');
const { writePlan } = require('./write-plan.cjs');
const { assertNoWatchers } = require('./project-activity.cjs');
const { addonRoots, resolveProjectPaths, getProjectMounts } = require('./project-paths.cjs');

const root = path.resolve(__dirname, '..');
const languages = ['schinese', 'english', 'russian'];
const translationLanguages = values => values?.tchinese === undefined ? languages : [...languages, 'tchinese'];
const kv = value => '"' + String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n/g, '\\n') + '"';
const legacyRegions = ['china', 'overseas', 'overseas2'];
const legacyLanguageRegions = { schinese: 'china', english: 'overseas', russian: 'overseas2' };
const regionID = /^[a-z][a-z0-9_]{0,63}$/;
const reservedRegions = ['constructor', 'prototype', 'lobby_address', 'overseas_lobby_address', 'overseas2_lobby_address'];

function validate(config) {
	addonRoots(config);
	if (!/^\d+$/.test(config.workshopId ?? '')) throw new Error('workshopId must be the published Workshop ID');
	for (const language of translationLanguages(config.displayName)) if (typeof config.displayName?.[language] !== 'string' || !config.displayName[language].trim()) throw new Error('Missing displayName.' + language);
	const mapID = /^[A-Za-z0-9_-]{1,64}$/;
	if (config.defaultMap !== undefined && (typeof config.defaultMap !== 'string' || !mapID.test(config.defaultMap))) throw new Error('Invalid defaultMap');
	if (config.mapNames !== undefined) {
		if (!config.mapNames || typeof config.mapNames !== 'object' || Array.isArray(config.mapNames)) throw new Error('mapNames must be an object');
		for (const [id, names] of Object.entries(config.mapNames)) {
			if (!mapID.test(id) || !names || typeof names !== 'object' || Array.isArray(names)) throw new Error('Invalid mapNames.' + id);
			for (const language of translationLanguages(names)) if (typeof names[language] !== 'string' || !names[language].trim() || names[language].length > 120) throw new Error('Missing or invalid mapNames.' + id + '.' + language);
		}
	}
	if (config.connection?.mode !== undefined && !['auto', 'manual'].includes(config.connection.mode)) throw new Error('Invalid connection.mode');
	if (!config.lobbies || typeof config.lobbies !== 'object' || Array.isArray(config.lobbies)) throw new Error('lobbies must configure at least one server');
	const regions = Object.keys(config.lobbies);
	if (!regions.some(region => config.lobbies[region])) throw new Error('Configure at least one lobbies server');
	for (const region of regions) {
		if (!regionID.test(region) || reservedRegions.includes(region)) throw new Error('Invalid lobbies region: ' + region);
		if (!config.lobbies[region] && legacyRegions.includes(region)) continue;
		const match = /^([a-zA-Z0-9.-]+):(\d+)$/.exec(config.lobbies?.[region] ?? '');
		if (typeof config.lobbies[region] !== 'string' || !match || Number(match[2]) < 1 || Number(match[2]) > 65535) throw new Error('Invalid lobbies.' + region + ': expected host:port');
	}
	if (config.connection?.region !== undefined && (typeof config.connection.region !== 'string' || !regions.includes(config.connection.region) && !legacyRegions.includes(config.connection.region))) throw new Error('Invalid connection.region');
	if (config.connection?.languageRegions !== undefined) {
		const defaults = config.connection.languageRegions;
		if (!defaults || typeof defaults !== 'object' || Array.isArray(defaults)) throw new Error('connection.languageRegions must be an object');
		for (const language of Object.keys(defaults)) if (!languages.includes(language)) throw new Error('Invalid connection.languageRegions.' + language);
		for (const language of languages) if (typeof defaults[language] !== 'string' || !Object.hasOwn(config.lobbies, defaults[language]) || !config.lobbies[defaults[language]]) throw new Error('Invalid connection.languageRegions.' + language + ': select a configured lobby');
	}
	if (config.lobbyLabels !== undefined) {
		if (!config.lobbyLabels || typeof config.lobbyLabels !== 'object' || Array.isArray(config.lobbyLabels)) throw new Error('lobbyLabels must be an object');
		for (const [region, labels] of Object.entries(config.lobbyLabels)) {
			if ((!regions.includes(region) && !legacyRegions.includes(region)) || !labels || typeof labels !== 'object' || Array.isArray(labels)) throw new Error('Invalid lobbyLabels.' + region);
			for (const language of translationLanguages(labels)) if (typeof labels[language] !== 'string' || !labels[language].trim() || labels[language].length > 120) throw new Error('Missing or invalid lobbyLabels.' + region + '.' + language);
		}
	}
	if (config.integration?.mode && !['auto', 'manual'].includes(config.integration.mode)) throw new Error('Invalid integration.mode');
	if (config.integration?.retainedMaps !== undefined) {
		const maps = config.integration.retainedMaps;
		if (!Array.isArray(maps) || maps.some(map => typeof map !== 'string' || !mapID.test(map) || ['platform_entry', 'platform_lobby'].includes(map)) || new Set(maps).size !== maps.length) throw new Error('integration.retainedMaps must contain unique original map names');
	}
	if (config.integration?.migration && config.integration.migration !== 'legacy-tui') throw new Error('Invalid integration.migration');
	for (const stage of ['build', 'compile', 'package']) {
		const commands = config.pipeline?.[stage];
		if (commands !== undefined && (!Array.isArray(commands) || commands.some(command => !command || typeof command.command !== 'string' || !command.command.trim() || !Array.isArray(command.args) || command.args.some(arg => typeof arg !== 'string')))) throw new Error('pipeline.' + stage + ' must be an array of {command,args}');
	}
	for (const field of ['battleServer', 'battleClient']) {
		const name = config[field];
		if (name && (!/^[a-zA-Z_][a-zA-Z0-9_/]*$/.test(name) || ['addon_game_mode', 'addon_game_mode_client'].includes(name) || name.startsWith('eom_platform/'))) throw new Error('Invalid ' + field + ' module');
	}
	if (config.panorama?.battleLoadingLayout !== undefined) {
		layoutPath(config.panorama.battleLoadingLayout);
		if (config.panorama.battleLoadingLayout === 'custom_loading_screen.xml') throw new Error('battleLoadingLayout must name the original project layout, not the generated loading router');
	}
	return config;
}

function files(directory) {
	return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => entry.isDirectory()
		? files(path.join(directory, entry.name)) : [path.join(directory, entry.name)]);
}

function mergeLocalization(existing, source) {
	if (!/"Tokens"\s*\{/.test(existing) || !/\}\s*\}\s*$/.test(existing)) throw new Error('Unsupported localization structure; merge the source tokens manually');
	let output = existing;
	const additions = [];
	for (const match of source.matchAll(/^\s*"(platform_[^"]+)"\s+"((?:\\.|[^"\\])*)"\s*$/gm)) {
		const line = '\t\t' + kv(match[1]) + ' "' + match[2] + '"';
		const pattern = new RegExp('^[\\t ]*"' + match[1] + '"[\\t ]+"(?:\\\\.|[^"\\\\])*"[\\t ]*$', 'm');
		if (pattern.test(output)) output = output.replace(pattern, () => line);
		else additions.push(line);
	}
	if (additions.length) output = output.replace(/\}\s*\}\s*$/, () => additions.join('\n') + '\n\t}\n}\n');
	return output;
}

function install(target, input, { initialize = false, dryRun = false, rebuilt = false } = {}) {
	validate(input);
	target = path.resolve(target);
	const config = resolveProjectPaths(target, input);
	assertNoWatchers(target);
	if (config.integration?.mode === 'manual' && fs.existsSync(safePath(target, '.eom-platform/' + config.addon + '/state.json', getProjectMounts(config)))) throw new Error('Disable the existing automatic integration before switching to manual mode');
	if (fs.existsSync(safePath(target, '.eom-platform/' + config.addon + '/encryption.json', getProjectMounts(config)))) throw new Error('Restore encrypted outputs with restore-encryption before installing or upgrading the SDK');
	if (!fs.existsSync(path.join(root, 'dist/content'))) throw new Error('Build the SDK before installing it');
	if (initialize && fs.existsSync(target) && fs.readdirSync(target).length) throw new Error('init requires an empty target directory');
	const changes = new Map();
	const nativeBaseline = new Map();
	const skipped = [];
	function put(relative, data) { changes.set(relative.replace(/\\/g, '/'), Buffer.isBuffer(data) ? data : Buffer.from(data)); }
	const { content, game } = addonRoots(config);
	for (const layer of [content, game]) safePath(target, layer + '/.eom-path-check', getProjectMounts(config));
	for (const layer of ['content', 'game']) for (const file of files(path.join(root, 'dist', layer))) {
		put(({ content, game })[layer] + '/' + path.relative(path.join(root, 'dist', layer), file), fs.readFileSync(file));
	}
	for (const layer of ['content', 'game']) for (const name of ['platform_entry', 'platform_lobby']) {
		const relative = ({ content, game })[layer] + '/maps/' + name + (layer === 'content' ? '.vmap' : '.vpk');
		if (fs.existsSync(path.join(target, relative))) skipped.push(relative);
		else put(relative, fs.readFileSync(path.join(root, layer, 'platform/maps', path.basename(relative))));
	}
	const traditionalChinese = config.displayName.tchinese || (!initialize && fs.existsSync(safePath(target, content + '/localization/tchinese', getProjectMounts(config))));
	const projectLanguages = traditionalChinese ? [...languages, 'tchinese'] : languages;
	for (const language of projectLanguages) {
		let source = fs.readFileSync(path.join(root, 'content/platform/localization', language, 'platform.vdf'), 'utf8');
		source = source.replace(/("platform_game_title"\s+)"[^"\n]*"/, (_, prefix) => prefix + kv(config.displayName[language] ?? config.displayName.schinese));
		for (const [id, names] of Object.entries(config.mapNames ?? {})) {
			source = source.replace(/\}\s*\}\s*$/, () => '\t\t' + kv('platform_map_' + id) + ' ' + kv((names[language] ?? names.schinese).trim()) + '\n\t}\n}\n');
		}
		for (const [region, labels] of Object.entries(config.lobbyLabels ?? {})) {
			const token = new RegExp('("platform_entry_' + region + '"\\s+)"[^"\\n]*"');
			const text = kv((labels[language] ?? labels.schinese).trim());
			if (token.test(source)) source = source.replace(token, (_, prefix) => prefix + text);
			else source = source.replace(/\}\s*\}\s*$/, () => '\t\t' + kv('platform_entry_' + region) + ' ' + text + '\n\t}\n}\n');
		}
		put(content + '/localization/' + language + '/eom_platform.vdf', source);
		const resource = game + '/resource/addon_' + language + '.txt';
		put(resource, fs.existsSync(path.join(target, resource)) ? mergeLocalization(fs.readFileSync(path.join(target, resource), 'utf8'), source) : source);
	}
	const enabledRegions = Object.keys(config.lobbies).filter(region => config.lobbies[region]);
	const routeKeys = { ...Object.fromEntries(enabledRegions.map(region => [region, region])), china: 'lobby_address', overseas: 'overseas_lobby_address', overseas2: 'overseas2_lobby_address' };
	const routing = Object.fromEntries(enabledRegions.map(region => [routeKeys[region], config.lobbies[region]]));
	const labels = Object.fromEntries(enabledRegions.map(region => [routeKeys[region], config.lobbyLabels?.[region] || legacyRegions.includes(region) ? '#platform_entry_' + region : '#platform_region']));
	put(game + '/scripts/platform_routing.txt', '"platform_routing"\n{\n' + Object.entries(routing).map(([key, value]) => '\t' + kv(key) + ' ' + kv(value)).join('\n') + '\n}\n');
	const defaultRegion = enabledRegions.includes(config.connection?.region) ? config.connection.region : enabledRegions[0];
	const languageRegions = Object.fromEntries(languages.map(language => [language, routeKeys[config.connection?.languageRegions?.[language] ?? (enabledRegions.includes(legacyLanguageRegions[language]) ? legacyLanguageRegions[language] : defaultRegion)]]));
	put(content + '/panorama/scripts/custom_game/eom_platform/entry_config.js', 'GameUI.CustomUIConfig().EOMPlatformEntry = ' + JSON.stringify({
		schema: 2, mode: 'auto', routing, labels, languageRegions,
		defaultRegion: routeKeys[defaultRegion],
		...(config.defaultMap ? { defaultMap: config.defaultMap } : {}),
	}) + ';\n');
	put(game + '/scripts/eom_platform.txt', '"eom_platform"\n{\n\t"addon" ' + kv(config.workshopId) + '\n\t"battle_server" ' + kv(config.battleServer ?? '') + '\n\t"battle_client" ' + kv(config.battleClient ?? '') + '\n\t"managed_client" ' + kv(config.integration?.mode === 'manual' ? '0' : '1') + '\n\t"connection_mode" ' + kv('auto') + '\n\t"connection_region" ' + kv(defaultRegion) + '\n\t"language_regions"\n\t{\n' + Object.entries(languageRegions).map(([language, region]) => '\t\t' + kv(language) + ' ' + kv(region)).join('\n') + '\n\t}\n}\n');
	put(game + '/scripts/eom_platform.gameevents', '"CustomEvents"\n{\n\t"client_side_event"\n\t{\n\t\t"event_name" "string"\n\t\t"event_data" "string"\n\t}\n}\n');
	if (!initialize && config.integration?.mode === 'manual' && config.panorama?.battleLoadingLayout) {
		put(content + '/panorama/layout/custom_game/custom_loading_screen.xml', loadingLayout(config.panorama.battleLoadingLayout));
		put(content + '/panorama/scripts/custom_game/eom_platform/integration/loading_config.js', loadingConfigScript(config.panorama.battleLoadingLayout));
	}
	if (initialize) {
		for (const name of ['addon_game_mode', 'addon_game_mode_client']) put(game + '/scripts/vscripts/' + name + '.lua', fs.readFileSync(path.join(root, 'templates', name + '.lua')));
		put(game + '/scripts/custom.gameevents', '"CustomEvents"\n{\n\t"client_side_event"\n\t{\n\t\t"event_name" "string"\n\t\t"event_data" "string"\n\t}\n}\n');
		put(game + '/addoninfo.txt', '<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->\n{\n\tIsPlayable = true\n\tDefaultMap = "platform_entry"\n\tmaps = [ "platform_entry" ]\n\tMinPlayers = 1\n\tMaxPlayers = 64\n\tCheckAFKPlayers = false\n\tmap_options = [ { map = "platform_entry" MinPlayers = 1 MaxPlayers = 1 } ]\n}\n');
		put(content + '/panorama/layout/custom_game/custom_loading_screen.xml', fs.readFileSync(path.join(root, 'dist/content/panorama/layout/custom_game/eom_platform/loading.xml')));
		put(content + '/panorama/layout/custom_game/custom_ui_manifest.xml', '<root>\n\t<Panel>\n\t\t<CustomUIElement type="CustomGameSetup" layoutfile="file://{resources}/layout/custom_game/eom_platform/setup.xml" />\n\t</Panel>\n</root>\n');
		for (const [field, hook] of [['battleServer', 'ActivateBattle'], ['battleClient', null]]) {
			if (config[field]) put(game + '/scripts/vscripts/' + config[field] + '.lua', hook ? 'function ' + hook + '()\nend\n' : '-- Initialize the game client here.\n');
		}
		if (config.integration?.mode !== 'manual') {
			put(game + '/scripts/vscripts/addon_game_mode.lua', config.battleServer
				? 'require(' + JSON.stringify(config.battleServer) + ')\nActivate = ActivateBattle\nPrecache = PrecacheBattle\nSpawnGroupPrecache = SpawnGroupPrecacheBattle\n'
				: 'function Activate() end\nfunction Precache(context) end\nfunction SpawnGroupPrecache(group, context) end\n');
			put(game + '/scripts/vscripts/addon_game_mode_client.lua', config.battleClient ? 'require(' + JSON.stringify(config.battleClient) + ')\n' : '-- No project client.\n');
			put(content + '/panorama/layout/custom_game/custom_loading_screen.xml', '<root>\n    <Panel />\n</root>\n');
			put(content + '/panorama/layout/custom_game/custom_ui_manifest.xml', '<root>\n    <Panel />\n</root>\n');
			for (const file of [game + '/scripts/vscripts/addon_game_mode.lua', game + '/scripts/vscripts/addon_game_mode_client.lua', content + '/panorama/layout/custom_game/custom_loading_screen.xml', content + '/panorama/layout/custom_game/custom_ui_manifest.xml', ...['battleServer', 'battleClient'].filter(field => config[field]).map(field => game + '/scripts/vscripts/' + config[field] + '.lua')]) nativeBaseline.set(file, changes.get(file));
			nativeBaseline.set(game + '/scripts/custom.gameevents', Buffer.from('"CustomEvents"\n{\n}\n'));
			nativeBaseline.set(game + '/addoninfo.txt', Buffer.from(changes.get(game + '/addoninfo.txt').toString('utf8').replaceAll('platform_entry', 'battle')));
		}
	}
	if (config.integration?.mode !== 'manual') automatic(target, config, changes, { rebuilt, initializing: initialize });
	const manifest = { version: require('../package.json').version, addon: config.addon, files: [...changes].filter(([file]) => !file.startsWith('.eom-platform/')).map(([file, data]) => ({ file, sha256: crypto.createHash('sha256').update(data).digest('hex') })) };
	put(game + '/scripts/eom_platform_manifest.json', JSON.stringify(manifest, null, 2) + '\n');
	const restoration = config.integration?.mode === 'manual' ? { exact: false, directories: [] } : require('./integration-state.cjs').finalizeIntegration(target, config, changes, { rebuilt, nativeBaseline, retainedFiles: skipped });
	// Validate every destination, including pre-existing links, before writing anything.
	for (const relative of changes.keys()) safePath(target, relative, getProjectMounts(config));
	if (!dryRun) writePlan([...changes].map(([relative, data]) => ({ destination: safePath(target, relative, getProjectMounts(config)), data })), { removeDirectories: restoration.directories.map(relative => safePath(target, relative, getProjectMounts(config))) });
	return { files: [...changes.keys()], actions: [...changes].map(([file, data]) => ({ file, action: data === null ? 'remove' : 'write' })), skippedMaps: skipped, restoration, dryRun };
}

module.exports = { install, validate, mergeLocalization };

#!/usr/bin/env node
'use strict';
const path = require('node:path');
const { openVpk } = require('./vpk.cjs');
const { requiredRuntimeResources: required } = require('./platform-resources.cjs');

function checkPackage(file) {
	const archive = openVpk(file), missing = [], invalid = [];
	for (const relative of required) {
		if (!archive.entries.has(relative)) { missing.push(relative); continue; }
		try {
			if (archive.read(relative).length === 0) invalid.push({ file: relative, error: 'Empty runtime resource' });
		} catch (error) { invalid.push({ file: relative, error: error.message }); }
	}
	return { ok: missing.length === 0 && invalid.length === 0, file: path.resolve(file), version: archive.version, checked: required.length, entries: archive.entries.size, missing, invalid };
}

if (require.main === module) {
	const file = process.argv[2];
	try {
		if (process.argv.length !== 3 || !file || !path.isAbsolute(file)) throw new Error('Usage: node scripts/check-package.cjs <absolute VPK file>');
		const report = checkPackage(file);
		process.stdout.write(JSON.stringify(report, null, 2) + '\n');
		if (!report.ok) process.exitCode = 1;
	} catch (error) {
		process.stdout.write(JSON.stringify({ ok: false, file: file ? path.resolve(file) : null, error: error.message }, null, 2) + '\n');
		process.exitCode = 1;
	}
}

module.exports = { checkPackage, required };

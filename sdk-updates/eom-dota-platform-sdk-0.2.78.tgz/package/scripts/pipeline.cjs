const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { install, validate } = require('./install.cjs');
const { safePath, hash } = require('./automatic.cjs');
const { serverDeployment } = require('./deployment.cjs');
const { addonRoots, resolveProjectPaths, getProjectMounts } = require('./project-paths.cjs');
const { assertCompiledResources } = require('./platform-resources.cjs');
const panorama = require('./compile-panorama.cjs');

function sdkCompileStep(step) {
	if (!step || typeof step.command !== 'string' || !Array.isArray(step.args)) return false;
	if (!/(?:^|[\\/])node(?:\.exe)?$/i.test(step.command) || !/(?:^|[\\/])dota-platform-sdk[\\/]scripts[\\/]compile-panorama\.cjs$/i.test(step.args[0] ?? '')) return false;
	const flags = new Set();
	for (let index = 1; index < step.args.length; index += 2) {
		const flag = step.args[index], value = step.args[index + 1];
		if (!['--target', '--config', '--compiler', '--dota-root'].includes(flag) || flags.has(flag) || typeof value !== 'string' || !value || value.startsWith('--')) return false;
		flags.add(flag);
	}
	return flags.has('--target') && flags.has('--config');
}

function normalizeCompileConfig(config) {
	const steps = config?.pipeline?.compile;
	if (config?.integration?.mode === 'manual' || !Array.isArray(steps) || !steps.length || !steps.every(sdkCompileStep)) return config;
	const pipeline = { ...config.pipeline };
	delete pipeline.compile;
	const normalized = { ...config, pipeline };
	if (!Object.keys(pipeline).length) delete normalized.pipeline;
	return normalized;
}

function inspect(target, config) {
	config = resolveProjectPaths(target, config);
	validate(config);
	const { game } = addonRoots(config);
	const manifest = JSON.parse(fs.readFileSync(safePath(target, game + '/scripts/eom_platform_manifest.json', getProjectMounts(config)), 'utf8'));
	const encryptionFile = safePath(target, '.eom-platform/' + config.addon + '/encryption.json', getProjectMounts(config));
	const encryption = fs.existsSync(encryptionFile) ? JSON.parse(fs.readFileSync(encryptionFile, 'utf8')) : undefined;
	if (encryption) require('./lua-encryption.cjs').restoreEncryption(target, config, { dryRun: true });
	for (const item of manifest.files) {
		const file = safePath(target, item.file, getProjectMounts(config));
		const encrypted = encryption?.originals[item.file];
		if (!fs.existsSync(file) || (encrypted ? encrypted.before : hash(fs.readFileSync(file))) !== item.sha256) throw new Error('Integration check failed: ' + item.file);
	}
	return { checked: manifest.files.length, ...(encryption ? { encrypted: encryption.encrypted.length } : {}), serverDeployment: serverDeployment(config) };
}

function execute(target, step, log) {
	return new Promise((resolve, reject) => {
		log('$ ' + [step.command, ...step.args].join(' ') + '\n');
		// npm.cmd requires cmd.exe on Windows. Quote every argument and reject shell
		// metacharacters rather than treating a JSON argument as shell source.
		const batch = process.platform === 'win32' && /\.(cmd|bat)$/i.test(step.command);
		if (batch && [step.command, ...step.args].some(value => /["%\r\n&|<>^!]/.test(value))) return reject(new Error('Batch command arguments contain shell metacharacters; use an executable with argument arrays'));
		const pathKey = Object.keys(process.env).find(key => key.toLowerCase() === 'path') || 'PATH';
		const search = [path.join(target, 'node_modules/.bin'), ...(process.env[pathKey] || '').split(path.delimiter)];
		const batchPath = batch ? (/[\\/]/.test(step.command) ? path.resolve(target, step.command) : search.map(directory => path.join(directory.replace(/^"|"$/g, ''), step.command)).find(file => fs.existsSync(file))) : undefined;
		if (batch && !batchPath) return reject(new Error('Command not found: ' + step.command));
		const command = batch ? process.env.ComSpec || 'cmd.exe' : step.command;
		const args = batch ? ['/d', '/s', '/c', '"' + [batchPath, ...step.args].map(value => '"' + value + '"').join(' ') + '"'] : step.args;
		const child = spawn(command, args, { cwd: target, env: { ...process.env, [pathKey]: search.join(path.delimiter) }, windowsHide: true, shell: false, windowsVerbatimArguments: batch });
		child.stdout.on('data', data => log(data.toString()));
		child.stderr.on('data', data => log(data.toString()));
		child.on('error', reject);
		child.on('close', code => code === 0 ? resolve() : reject(new Error(step.command + ' exited with ' + code)));
	});
}

async function runStage(target, config, stage, { log = () => {}, panoramaCompiler } = {}) {
	config = resolveProjectPaths(target, config);
	validate(config);
	if (!['build', 'compile', 'package'].includes(stage)) throw new Error('Unsupported pipeline stage: ' + stage);
	target = path.resolve(target);
	const list = config.pipeline?.[stage] ?? [];
	log('[platform] Stage: ' + stage + (list.length ? '\n' : ' (not configured)\n'));
	for (const command of list) {
		if (stage === 'compile' && sdkCompileStep(command)) {
			log('[platform] 使用工具内置 Panorama 编译器，自动定位 Dota 2\n');
			await panorama.compilePanorama({ target, config, ...panoramaCompiler, log });
		} else await execute(target, command, log);
	}
	return { stage, status: list.length ? 'succeeded' : 'not_configured' };
}

async function compileProject(target, config, options = {}) {
	config = resolveProjectPaths(target, config);
	validate(config);
	target = path.resolve(target);
	const manifestFile = addonRoots(config).game + '/scripts/eom_platform_manifest.json';
	const embedded = config.integration?.mode !== 'manual' && fs.existsSync(safePath(target, manifestFile, getProjectMounts(config)));
	if (embedded) config = normalizeCompileConfig(config);
	let report;
	if (embedded && !config.pipeline?.compile?.length) {
		options.log?.('[platform] 正在自动编译平台界面资源\n');
		const resources = await panorama.compilePanorama({ target, config, ...options.panoramaCompiler, log: options.log ?? (() => {}) });
		report = { stage: 'compile', status: 'succeeded', mode: 'automatic', resources };
	} else report = await runStage(target, config, 'compile', options);
	if (embedded) {
		report.compiledPanorama = assertCompiledResources(target, config);
		options.log?.('[platform] Verified ' + report.compiledPanorama.checked + ' compiled Panorama resources\n');
	}
	return report;
}

function preflightCompilation(target, config) {
	const normalized = normalizeCompileConfig(config);
	const steps = normalized.pipeline?.compile ?? [];
	if ((normalized.integration?.mode !== 'manual' && !steps.length) || steps.some(sdkCompileStep)) {
		try { return panorama.findPanoramaCompiler(target, config); }
		catch (cause) {
			throw new Error(cause.message + '\n编译环境检查失败，本次操作已停止，未写入接入改动。', { cause });
		}
	}
}

async function installProject(target, config, { initialize = false, rebuilt = false, dryRun = false, log = () => {} } = {}) {
	config = resolveProjectPaths(target, config);
	validate(config);
	const panoramaCompiler = dryRun ? undefined : preflightCompilation(target, config);
	const report = install(target, config, { initialize, rebuilt, dryRun });
	if (dryRun) return report;
	let compilation;
	try {
		compilation = await compileProject(target, config, { log, panoramaCompiler });
		const validation = inspect(target, config);
		return { ...report, compilation, validation };
	} catch (problem) {
		const error = new Error('SDK sources were installed, but compilation or validation failed; the integration remains applied. ' + problem.message, { cause: problem });
		error.integrationApplied = true;
		error.install = report;
		error.stage = compilation ? 'verify' : 'compile';
		if (compilation) error.compilation = compilation;
		throw error;
	}
}

async function buildProject(target, config, { log = () => {} } = {}) {
	config = resolveProjectPaths(target, config);
	validate(config);
	target = path.resolve(target);
	if (fs.existsSync(safePath(target, '.eom-platform/' + config.addon + '/encryption.json', getProjectMounts(config)))) throw new Error('Restore encrypted outputs with restore-encryption before building');
	if (!config.pipeline?.build?.length) throw new Error('Configure pipeline.build with the original project build commands');
	if (config.integration?.mode === 'manual') throw new Error('build requires automatic integration');
	const report = { stages: [] };
	report.stages.push(await runStage(target, config, 'build', { log }));
	const panoramaCompiler = preflightCompilation(target, config);
	log('[platform] Stage: integrate\n');
	report.install = install(target, config, { rebuilt: true });
	report.stages.push({ stage: 'integrate', status: 'succeeded' });
	log('[platform] Stage: verify\n');
	report.validation = inspect(target, config);
	log('[platform] Verified ' + report.validation.checked + ' files\n');
	report.stages.push({ stage: 'verify', status: 'succeeded' });
	report.stages.push(await compileProject(target, config, { log, panoramaCompiler }));
	report.validation = inspect(target, config);
	report.stages.push(await runStage(target, config, 'package', { log }));
	return report;
}

function discover(target) {
	target = path.resolve(target);
	if (fs.existsSync(target)) target = fs.realpathSync(target);
	const directories = layer => fs.existsSync(path.join(target, layer)) ? fs.readdirSync(path.join(target, layer), { withFileTypes: true }).filter(item => item.isDirectory() || item.isSymbolicLink() && fs.statSync(path.join(target, layer, item.name)).isDirectory()).map(item => item.name) : [];
	const addons = ['flat', 'dota_addons'].flatMap(layout => {
		const prefix = layout === 'dota_addons' ? '/dota_addons' : '';
		const content = directories('content' + prefix);
		return directories('game' + prefix).filter(addon => addon !== 'dota_addons' && content.includes(addon)).map(addon => {
			const roots = addonRoots({ addon, integration: { layout } });
			return { addon, layout, serverEntry: roots.game + '/scripts/vscripts/addon_game_mode.lua', clientEntry: roots.game + '/scripts/vscripts/addon_game_mode_client.lua' };
		});
	});
	const packagePath = path.join(target, 'package.json');
	const scripts = fs.existsSync(packagePath) ? JSON.parse(fs.readFileSync(packagePath, 'utf8')).scripts ?? {} : {};
	return { target, addons, scripts };
}

module.exports = { buildProject, compileProject, installProject, runStage, inspect, discover, normalizeCompileConfig };

#!/usr/bin/env node
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { install, validate } = require('./install.cjs');
const { safePath, restore } = require('./automatic.cjs');
const { installProject, compileProject, discover, inspect, normalizeCompileConfig } = require('./pipeline.cjs');
const { projectTarget, projectConfig, resolveProjectConfig, projectStatus, projectMaps } = require('./studio-project.cjs');
const { createProjectStore } = require('./studio-workspace.cjs');
const { createDiagnostics } = require('./studio-diagnostics.cjs');
const { createUpdater } = require('./studio-update.cjs');
const { resolveProjectPaths, getProjectMounts, portableProjectConfig } = require('./project-paths.cjs');

const root = path.resolve(__dirname, '..');
const defaultWorkspace = path.resolve(process.env.EOM_STUDIO_HOME || path.join(root, '.studio'));
const digest = data => crypto.createHash('sha256').update(data).digest('hex');

// Tool settings stay outside versioned packages in desktop mode.
function writable(target, workspace = defaultWorkspace) {
	const resolved = path.resolve(target);
	if (!resolved.startsWith(workspace + path.sep)) throw new Error('写入目录必须位于工作台配置目录内');
	let current = resolved;
	while (true) {
		if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) throw new Error('写入路径不能包含符号链接或目录联接');
		const parent = path.dirname(current);
		if (parent === current) break;
		current = parent;
	}
	return resolved;
}

function createStudio(options = {}) {
	const workspace = path.resolve(options.workspace || defaultWorkspace);
	const workspaceFile = name => writable(path.join(workspace, name), workspace);
	const projects = createProjectStore(workspaceFile);
	const consumer = options.consumer ?? (require('../package.json').distribution?.type === 'studio-runtime' || process.env.EOM_STUDIO_CONSUMER === '1');
	const launcher = options.launcher ?? process.env.EOM_STUDIO_LAUNCHER === '1';
	const diagnostics = createDiagnostics({ workspaceFile, version: require('../package.json').version,
		endpoint: options.reportEndpoint ?? process.env.EOM_STUDIO_REPORT_URL ?? require('../package.json').diagnostics?.endpoint,
		roots: [root, workspace], launcherLog: process.env.EOM_STUDIO_NATIVE === '1' ? path.resolve(workspace, '../logs/launcher.log') : null });
	function saveConfig(config, target, options) {
		const selected = target ? projectTarget(root, { target }) : null;
		return projects.save(config, selected, options);
	}
	const token = crypto.randomBytes(32).toString('hex');
	let preview = null;
	let job = null;
	let embeddingPreview = null;
	let embeddingRunning = false;
	let directoryPicking = false;
	let updateTrust = options.updateTrust;
	if (!updateTrust) {
		try { updateTrust = require('./studio-launcher.cjs').loadTrust(); } catch { /* Source checkouts can run without release configuration. */ }
	}
	const updates = options.updater || createUpdater({ home: process.env.EOM_STUDIO_LAUNCHER_HOME || path.resolve(workspace, '..'), currentRoot: root,
		version: require('../package.json').version, trust: updateTrust, managed: launcher,
		canUpdate: () => { if (job?.status === 'running' || embeddingRunning || directoryPicking) throw new Error('请等待当前项目任务完成'); } });
	function plan(input) {
		if (!['init', 'install', 'sync'].includes(input.mode)) throw new Error('请选择初始化、更新或同步模式');
		if (typeof input.target !== 'string' || !input.target.trim()) throw new Error('请填写接入目录');
		const target = path.resolve(root, input.target);
		if (target === root) throw new Error('请使用独立的接入目录');
		input = { ...input, config: resolveProjectPaths(target, input.config, { refresh: true }) };
		const report = install(target, input.config, { initialize: input.mode === 'init', rebuilt: input.mode === 'sync', dryRun: true });
		const actions = new Map(report.actions?.map(item => [item.file, item.action]));
		const files = report.files.map(file => {
			const destination = path.join(target, file);
			return { file, action: actions.get(file) === 'remove' ? 'remove' : fs.existsSync(destination) ? 'update' : 'create', before: fs.existsSync(destination) ? digest(fs.readFileSync(destination)) : null };
		});
		// Changes to any installer input invalidate the preview.
		const sources = ['dist/content', 'dist/game', 'templates', 'content/platform/localization', 'game/platform/maps', 'content/platform/maps', 'scripts'];
		function fingerprint(directory) {
			return fs.readdirSync(directory, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name)).map(entry => {
				const file = path.join(directory, entry.name);
				return entry.isDirectory() ? fingerprint(file) : [file, digest(fs.readFileSync(file))];
			});
		}
		const signature = digest(JSON.stringify([input, getProjectMounts(input.config), files, report.skippedMaps, report.restoration, sources.map(source => fingerprint(path.join(root, source))), digest(fs.readFileSync(path.join(root, 'package.json')))]));
		let canApply = true;
		let restriction = '';
		try {
			for (const file of report.files) safePath(target, file, getProjectMounts(input.config));
		} catch (error) { canApply = false; restriction = error.message; }
		return { target, files, directories: report.restoration?.directories || [], skippedMaps: report.skippedMaps, signature, canApply, restriction };
	}
	function restorePlan(input) {
		validate(input.config);
		const target = projectTarget(root, input);
		input = { ...input, config: resolveProjectPaths(target, input.config, { refresh: true }) };
		const report = restore(target, input.config, { dryRun: true });
		const signature = digest(JSON.stringify([input, getProjectMounts(input.config), report]));
		return { ...report, target, signature };
	}
	function embeddingPlan(input) {
		if (typeof input.enabled !== 'boolean') throw new Error('请选择启用或关闭内嵌代码');
		validate(input.config);
		const config = { ...input.config, integration: { ...input.config.integration, mode: 'auto' } };
		const target = projectTarget(root, input);
		const status = projectStatus(root, { target, config });
		if (status.encrypted) throw new Error('请先恢复 Lua 明文，再切换内嵌代码');
		if (status.embedding.restoration === 'legacy') throw new Error(status.embedding.reason);
		if (!input.enabled) {
			if (!status.embedding.enabled) throw new Error('项目尚未启用内嵌代码');
			const report = restorePlan({ target, config });
			return { ...report, enabled: false, canApply: true, files: report.actions };
		}
		return { ...plan({ target, config, mode: 'install' }), enabled: true };
	}
	function startJob(action, input) {
		if (job?.status === 'running') throw new Error('已有任务正在运行');
		if (consumer && ['build', 'test', 'runtime', 'pack'].includes(action)) throw new Error('SDK 源码维护任务请在源码仓库的开发工作台运行');
		const commands = { build: [process.execPath, ['scripts/build.cjs']], test: [process.execPath, ['--test', 'tests']], runtime: [process.execPath, ['scripts/test-runtime.cjs']] };
		if (action === 'pack') {
			const destination = workspaceFile('packages');
			fs.mkdirSync(destination, { recursive: true });
			const npmCli = process.env.npm_execpath;
			commands.pack = npmCli && fs.existsSync(npmCli)
				? [process.execPath, [npmCli, 'pack', '--json', '--pack-destination', destination]]
				: [process.platform === 'win32' ? 'npm.cmd' : 'npm', ['pack', '--json', '--pack-destination', destination]];
		}
		if (!commands[action]) throw new Error('未知任务');
		const [command, args] = commands[action];
		job = { id: crypto.randomUUID(), action, status: 'running', log: '', startedAt: new Date().toISOString(), exitCode: null };
		const current = job;
		const child = spawn(command, args, { cwd: root, windowsHide: true, shell: command === 'npm.cmd', env: { ...process.env, ...(action === 'runtime' && input.python ? { PYTHON: input.python } : {}) } });
		const append = data => { current.log = (current.log + data.toString()).slice(-200000); };
		child.stdout.on('data', append);
		child.stderr.on('data', append);
		child.on('error', error => { append(error.message); current.status = 'failed'; });
		child.on('close', code => { current.exitCode = code; current.status = code === 0 ? 'succeeded' : 'failed'; current.finishedAt = new Date().toISOString(); if (code !== 0) diagnostics.record('job', { operation: action, message: action + ' failed: ' + code, log: current.log }); });
		return job;
	}
	const server = http.createServer(async (req, res) => {
		let authorized = false, failureStack;
		const send = (status, value, type = 'application/json; charset=utf-8') => {
			if (authorized && status >= 400 && !req.url.startsWith('/api/diagnostics')) diagnostics.record('api', { operation: req.url.split('?')[0], message: value?.error, stack: failureStack, log: value?.log });
			res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'" });
			res.end(type.startsWith('application/json') ? JSON.stringify(value) : value);
		};
		try {
			const origin = 'http://127.0.0.1:' + server.address().port;
			if (req.headers.host !== new URL(origin).host) return send(403, { error: '仅允许通过本机地址访问' });
			const url = new URL(req.url, origin);
			if (url.pathname.startsWith('/api/')) {
				if (req.headers['x-studio-token'] !== token || (req.headers.origin && req.headers.origin !== origin)) return send(403, { error: '会话无效，请刷新工作台' });
				authorized = true;
				let input = {};
				if (req.method === 'POST') {
					let body = '';
					for await (const chunk of req) { body += chunk; if (Buffer.byteLength(body) > 128000) throw new Error('请求内容过大'); }
					input = JSON.parse(body || '{}');
					if (input.config) input.config = normalizeCompileConfig(portableProjectConfig(input.config));
					if (consumer && Object.hasOwn(input, 'target') && !(['/api/config', '/api/browse-directory'].includes(url.pathname) && !input.target) && (typeof input.target !== 'string' || !path.isAbsolute(input.target))) throw new Error('请选择游戏项目的绝对路径');
				}
				if (req.method === 'GET' && url.pathname === '/api/state') {
					const saved = projects.state(JSON.parse(fs.readFileSync(path.join(root, 'platform.config.example.json'), 'utf8')));
					const packages = workspaceFile('packages');
					return send(200, { root, workspace, consumer, launcher, ...saved, version: require('../package.json').version, update: updates.state(), built: fs.existsSync(path.join(root, 'dist/content')), job,
						packages: fs.existsSync(packages) ? fs.readdirSync(packages).filter(file => /^eom-dota-platform-sdk-[\w.-]+\.tgz$/.test(file)).sort((a, b) => b.localeCompare(a, undefined, { numeric: true })).map(file => ({ name: file, path: path.join(packages, file), url: '/packages/' + encodeURIComponent(file) })) : [] });
				}
				if (req.method === 'GET' && url.pathname === '/api/job') return send(200, { job });
				if (req.method === 'GET' && url.pathname === '/api/update') return send(200, updates.state());
				if (req.method === 'POST' && url.pathname.startsWith('/api/update/')) {
					if (url.pathname === '/api/update/check') return send(200, await updates.check());
					if (url.pathname === '/api/update/install') return send(200, await updates.install(input.version));
					if (url.pathname === '/api/update/restart') {
						if (!options.onRestart && !process.connected) throw new Error('请关闭并重新打开接入助手以使用新版本');
						const state = updates.restart();
						res.once('finish', () => options.onRestart ? options.onRestart() : process.send({ type: 'eom-studio-restart' }));
						return send(200, state);
					}
					return send(404, { error: '接口不存在' });
				}
				if (req.method === 'GET' && url.pathname === '/api/diagnostics') return send(200, diagnostics.state());
				if (req.method === 'POST' && url.pathname.startsWith('/api/diagnostics')) {
					if (url.pathname === '/api/diagnostics/event') {
						diagnostics.record('ui', { message: input.message, stack: input.stack, operation: input.operation });
						return send(200, { recorded: true });
					}
					if (url.pathname === '/api/diagnostics/preview') return send(200, diagnostics.preview(input.description));
					if (url.pathname === '/api/diagnostics/preferences') return send(200, diagnostics.setAutomatic(input.automatic));
					if (url.pathname === '/api/diagnostics/upload') return send(200, await diagnostics.upload(input));
					return send(404, { error: '接口不存在' });
				}
				if (req.method !== 'POST') return send(404, { error: '接口不存在' });
				if (updates.running()) throw new Error('接入助手正在更新，请稍后执行项目操作');
				if (job?.status === 'running' || embeddingRunning) throw new Error('请等待当前任务完成');
				if (url.pathname === '/api/config') {
					const file = saveConfig(input.config, input.target, input);
					preview = null; embeddingPreview = null;
					const state = projects.state();
					return send(200, { path: file, projects: state.projects, profileId: state.profileId, profileName: state.profileName });
				}
				if (url.pathname === '/api/browse-directory') {
					if (directoryPicking) throw new Error('目录选择窗口已打开');
					directoryPicking = true;
					try { return send(200, { target: await (options.pickDirectory || require('./studio-directory.cjs').pickDirectory)(input.target || '') }); }
					finally { directoryPicking = false; }
				}
				if (url.pathname === '/api/select-profile') {
					const state = projects.state(), selected = state.projects.find(project => project.id === input.profileId);
					if (!selected) throw new Error('找不到所选配置');
					projects.select(selected.target, selected.id);
					preview = null; embeddingPreview = null;
					return send(200, projects.state());
				}
				if (url.pathname === '/api/delete-profile') {
					projects.remove(input.profileId);
					preview = null; embeddingPreview = null;
					return send(200, projects.state(JSON.parse(fs.readFileSync(path.join(root, 'platform.config.example.json'), 'utf8'))));
				}
				if (url.pathname === '/api/addon-maps') return send(200, projectMaps(root, input));
				if (url.pathname === '/api/shutdown' && process.env.EOM_STUDIO_NATIVE === '1') {
					send(200, { stopping: true });
					setImmediate(() => server.close(() => { if (process.connected) process.disconnect(); }));
					return;
				}
				if (url.pathname === '/api/preview') { preview = { input, report: plan(input) }; embeddingPreview = null; return send(200, preview.report); }
				if (url.pathname === '/api/project-config') {
					const project = projectConfig(root, input);
					saveConfig(project.config, project.target);
					preview = null; embeddingPreview = null;
					return send(200, project);
				}
				if (url.pathname === '/api/open-project') {
					const target = projectTarget(root, input);
					if (!fs.existsSync(target)) throw new Error('找不到这个项目目录，请检查路径');
					if (!fs.statSync(target).isDirectory()) throw new Error('请选择游戏项目所在的文件夹');
					const file = safePath(target, 'platform.config.json');
					const saved = input.reloadFromProject ? null : input.config ?? (input.profileId === null ? null : projects.get(target, input.profileId));
					const stored = saved ?? (fs.existsSync(file) ? projectConfig(root, { target }).config : null);
					if (!stored) {
						const discovery = discover(target);
						projects.select(target);
						return send(200, { target, configured: false, discovery, projects: projects.state().projects });
					}
					const config = saved ? resolveProjectConfig(target, stored) : stored;
					const project = projectStatus(root, { target, config });
					let mapResult;
					try { mapResult = projectMaps(root, { target, config }); }
					catch (error) { mapResult = { error: error.message }; }
					if (saved) {
						const current = projects.state();
						const matching = current.projects.filter(project => project.target && (process.platform === 'win32' ? project.target.toLowerCase() === target.toLowerCase() : project.target === target));
						const id = Object.hasOwn(input, 'profileId') ? input.profileId : matching.find(project => project.id === current.profileId)?.id ?? matching[0]?.id ?? null;
						if (!input.config && config !== stored) saveConfig(config, target, { profileId: id });
						else projects.select(target, id);
					} else saveConfig(config, target, { profileId: input.profileId });
					preview = null; embeddingPreview = null;
					const state = projects.state();
					return send(200, { target, configured: true, config, profileId: state.profileId, profileName: state.profileName, project, mapResult, projects: state.projects });
				}
				if (url.pathname === '/api/project-status') return send(200, projectStatus(root, input));
				if (url.pathname === '/api/embedding-preview') {
					const report = embeddingPlan(input);
					embeddingPreview = { input, report };
					preview = null;
					return send(200, report);
				}
				if (url.pathname === '/api/embedding') {
					if (!embeddingPreview || input.signature !== embeddingPreview.report.signature) throw new Error('请先预览内嵌代码切换');
					const current = embeddingPlan(embeddingPreview.input);
					if (current.signature !== embeddingPreview.report.signature) throw new Error('文件或配置已变化，请重新预览内嵌代码切换');
					if (!current.canApply) throw new Error(current.restriction);
					if (!current.enabled && current.changedFiles.length && input.confirmDiscardChanges !== true) throw new Error('接入文件有变化，请确认丢弃改动后再关闭平台。');
					const config = { ...embeddingPreview.input.config, integration: { ...embeddingPreview.input.config.integration, mode: 'auto' } };
					embeddingPreview = null; preview = null;
					embeddingRunning = true;
					let log = '', applied = false;
					try {
						if (current.enabled) {
							const report = await installProject(current.target, config, { log: text => { log = (log + text).slice(-200000); } });
							return send(200, { ...report, enabled: true, target: current.target, compile: report.compilation, log });
						}
						const report = restore(current.target, config);
						applied = true;
						const compile = await compileProject(current.target, config, { log: text => { log = (log + text).slice(-200000); } });
						return send(200, { ...report, enabled: current.enabled, target: current.target, compile, log });
					} catch (error) {
						if (!applied && !error.integrationApplied) throw error;
						return send(400, { ...error.install, error: '内嵌代码切换已应用，但资源编译或校验失败：' + error.message, integrationApplied: true, enabled: current.enabled, target: current.target, compile: error.compilation ?? { stage: 'compile', status: 'failed' }, phase: error.stage ?? 'compile', log });
					} finally { embeddingRunning = false; }
				}
				if (url.pathname === '/api/discover') return send(200, discover(path.resolve(root, input.target)));
				if (url.pathname === '/api/check') return send(200, inspect(path.resolve(root, input.target), input.config));
				if (url.pathname === '/api/restore-preview') {
					preview = { restore: true, input, report: restorePlan(input) };
					embeddingPreview = null;
					return send(200, preview.report);
				}
				if (url.pathname === '/api/restore') {
					if (!preview?.restore || input.signature !== preview.report.signature) throw new Error('请先预览关闭内嵌代码');
					if (restorePlan(preview.input).signature !== preview.report.signature) throw new Error('文件或配置已变化，请重新预览关闭内嵌代码');
					const result = restore(path.resolve(root, preview.input.target), preview.input.config);
					preview = null;
					embeddingPreview = null;
					return send(200, result);
				}
				if (url.pathname === '/api/apply') {
					if (!preview || preview.restore || input.signature !== preview.report.signature) throw new Error('请先生成接入预览');
					const current = plan(preview.input);
					if (current.signature !== preview.report.signature) throw new Error('文件已变化，请重新预览');
					if (!current.canApply) throw new Error(current.restriction);
					const selected = preview.input;
					preview = null; embeddingPreview = null;
					embeddingRunning = true;
					let log = '';
					try {
						const report = await installProject(current.target, selected.config, { initialize: selected.mode === 'init', rebuilt: selected.mode === 'sync', log: text => { log = (log + text).slice(-200000); } });
						return send(200, { ...report, target: current.target, log });
					} catch (error) {
						if (!error.integrationApplied) throw error;
						return send(400, { ...error.install, error: error.message, integrationApplied: true, enabled: true, target: current.target, compile: error.compilation ?? { stage: 'compile', status: 'failed' }, phase: error.stage ?? 'compile', log });
					} finally { embeddingRunning = false; }
				}
				if (url.pathname === '/api/jobs') {
					const result = startJob(input.action, input);
					preview = null; embeddingPreview = null;
					return send(202, result);
				}
				return send(404, { error: '接口不存在' });
			}
			if (req.method === 'GET' && url.pathname.startsWith('/packages/')) {
				const name = url.pathname.slice('/packages/'.length);
				if (!/^eom-dota-platform-sdk-[\w.-]+\.tgz$/.test(name)) return send(404, { error: '包不存在' });
				const file = workspaceFile(path.join('packages', name));
				if (!fs.existsSync(file)) return send(404, { error: '包不存在' });
				return send(200, fs.readFileSync(file), 'application/gzip');
			}
			const assets = {
				'/': ['index.html', 'text/html; charset=utf-8'],
				'/app.js': ['app.js', 'text/javascript; charset=utf-8'],
				'/style.css': ['style.css', 'text/css; charset=utf-8'],
				'/assets/vg-logo.svg': ['assets/vg-logo.svg', 'image/svg+xml'],
				'/assets/vg-favicon.svg': ['assets/vg-favicon.svg', 'image/svg+xml'],
			};
			if (req.method !== 'GET' || !assets[url.pathname]) return send(404, { error: '页面不存在' });
			const [name, type] = assets[url.pathname];
			send(200, fs.readFileSync(path.join(root, 'studio', name), 'utf8').replace('__STUDIO_TOKEN__', token), type);
		} catch (error) { failureStack = error.stack; send(400, { error: error.message }); }
	});
	return server;
}

function start(port = 4173, options = {}) {
	const server = createStudio(options);
	server.on('error', error => {
		console.error(error.code === 'EADDRINUSE' ? '工作台端口已被使用，请关闭已有工作台后重试：http://127.0.0.1:' + port : error.message);
		process.send?.({ type: 'eom-studio-error', code: error.code });
		process.exitCode = 1;
		if (process.connected) process.disconnect();
	});
	server.listen(port, '127.0.0.1', () => {
		const url = 'http://127.0.0.1:' + server.address().port;
		console.log('VG 接入助手：' + url + '\n配置目录：' + (options.workspace || defaultWorkspace) + '\n项目接入写入所选目标目录。按 Ctrl+C 停止。');
		process.send?.({ type: 'eom-studio-ready', port: server.address().port });
		if (process.env.EOM_STUDIO_OPEN_BROWSER === '1') {
			const [command, args] = process.platform === 'win32' ? ['rundll32.exe', ['url.dll,FileProtocolHandler', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
			const browser = spawn(command, args, { detached: true, windowsHide: true, stdio: 'ignore' });
			browser.on('error', error => console.error('请手动打开工作台：' + url + ' (' + error.message + ')'));
			browser.unref();
		}
	});
	return server;
}

if (require.main === module) start(Number(process.env.PORT || 4173));
module.exports = { createStudio, start, writable };

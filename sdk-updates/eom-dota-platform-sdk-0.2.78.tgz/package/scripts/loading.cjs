function layoutPath(value) {
	if (typeof value !== 'string' || !/^[a-zA-Z0-9_/-]+\.xml$/.test(value) || value.startsWith('/') || value.startsWith('eom_platform/') || value === 'custom_loading_screen.xml') throw new Error('Expected the original project loading layout path');
	return value;
}

function loadingLayout(battleLayout) {
	layoutPath(battleLayout);
	return `<root>
    <scripts>
        <include src="file://{resources}/scripts/custom_game/eom_platform/integration/loading.js" />
        <include src="file://{resources}/scripts/custom_game/eom_platform/integration/loading_config.js" />
    </scripts>
    <Panel style="width: 100%; height: 100%;" hittest="false" />
</root>\n`;
}

function loadingConfigScript(battleLayout) {
	layoutPath(battleLayout);
	return 'EOMPlatformLoadScreen(' + JSON.stringify(battleLayout) + ');\n';
}

module.exports = { loadingLayout, loadingConfigScript, layoutPath };

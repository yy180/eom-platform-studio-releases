'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { validate } = require('./install.cjs');
const { normalizeCompileConfig } = require('./pipeline.cjs');
const { portableProjectConfig } = require('./project-paths.cjs');
const { writePlan } = require('./write-plan.cjs');

const key = target => target ? (process.platform === 'win32' ? path.resolve(target).toLowerCase() : path.resolve(target)) : null;
const legacyId = target => crypto.createHash('sha256').update(key(target) || 'draft').digest('hex');

function createProjectStore(workspaceFile) {
	const file = () => workspaceFile('projects.json');
	function read() {
		let state;
		if (fs.existsSync(file())) state = JSON.parse(fs.readFileSync(file(), 'utf8'));
		else {
			state = { schema: 1, target: null, projects: [] };
			const configPath = workspaceFile('platform.config.json'), sessionPath = workspaceFile('session.json');
			if (fs.existsSync(sessionPath)) state.target = JSON.parse(fs.readFileSync(sessionPath, 'utf8')).target ?? null;
			if (fs.existsSync(configPath)) {
				const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
				if (state.target) state.projects.push({ target: state.target, config });
				else state.draft = config;
			}
		}
		if (!state || ![1, 2].includes(state.schema) || !Array.isArray(state.projects) || state.target !== null && (typeof state.target !== 'string' || !path.isAbsolute(state.target))) throw new Error('项目配置列表格式无效，请保留文件并检查 projects.json');
		const ids = new Set();
		for (const project of state.projects) {
			if (!project || project.target !== null && (typeof project.target !== 'string' || !path.isAbsolute(project.target))) throw new Error('配置包含无效的项目目录');
			if (state.schema === 1) { project.id = legacyId(project.target); project.name = project.config?.displayName?.schinese || project.config?.addon; }
			if (typeof project.id !== 'string' || !/^[a-zA-Z0-9-]{1,80}$/.test(project.id) || ids.has(project.id) || typeof project.name !== 'string' || !project.name.trim() || project.name.length > 80) throw new Error('配置列表包含无效或重复的配置');
			ids.add(project.id);
			project.config = normalizeCompileConfig(portableProjectConfig(project.config));
			validate(project.config);
		}
		if (state.schema === 1) state.profileId = state.projects.find(project => key(project.target) === key(state.target))?.id ?? null;
		if (state.profileId !== null && !ids.has(state.profileId)) throw new Error('当前配置记录不存在');
		if (state.draft) { state.draft = normalizeCompileConfig(portableProjectConfig(state.draft)); validate(state.draft); }
		return { ...state, schema: 2 };
	}
	function write(state) {
		writePlan([{ destination: file(), data: Buffer.from(JSON.stringify(state, null, 2) + '\n') }]);
		return file();
	}
	function find(state, target, id) {
		if (id) {
			const profile = state.projects.find(project => project.id === id);
			if (!profile) throw new Error('找不到所选配置');
			return profile;
		}
		return state.projects.find(project => project.id === state.profileId && key(project.target) === key(target)) ?? state.projects.find(project => key(project.target) === key(target));
	}
	return {
		get(target, id) { return find(read(), target, id)?.config ?? null; },
		save(config, target, options = {}) {
			if (options.profileId !== undefined && options.profileId !== null && (typeof options.profileId !== 'string' || !/^[a-zA-Z0-9-]{1,80}$/.test(options.profileId))) throw new Error('无效的配置标识');
			config = normalizeCompileConfig(portableProjectConfig(config));
			validate(config);
			const state = read();
			let project = options.createNew || options.profileId === null ? null : find(state, target, options.profileId);
			const name = options.name ?? project?.name ?? config.displayName.schinese;
			if (typeof name !== 'string' || !name.trim() || name.trim().length > 80) throw new Error('请输入 1 至 80 个字符的配置名称');
			if (!project) { project = { id: crypto.randomUUID() }; state.projects.push(project); }
			Object.assign(project, { target: target || null, config, name: name.trim() });
			state.profileId = project.id;
			state.target = target || null;
			delete state.draft;
			return write(state);
		},
		select(target, id = null) {
			const state = read();
			if (id) find(state, target, id);
			state.target = target;
			state.profileId = id;
			write(state);
		},
		remove(id) {
			if (typeof id !== 'string' || !/^[a-zA-Z0-9-]{1,80}$/.test(id)) throw new Error('无效的配置标识');
			const state = read();
			find(state, null, id);
			state.projects = state.projects.filter(project => project.id !== id);
			if (state.profileId === id) {
				const next = state.projects[0];
				state.profileId = next?.id ?? null;
				state.target = next?.target ?? null;
				delete state.draft;
			}
			return write(state);
		},
		state(fallback) {
			const state = read(), active = state.projects.find(project => project.id === state.profileId);
			const config = active?.config ?? (state.target ? null : state.draft);
			return {
				target: state.target, profileId: active?.id ?? null, profileName: active?.name ?? '', config: config ?? fallback, configSaved: !!config, configPath: file(),
				projects: state.projects.map(project => ({ id: project.id, target: project.target, name: project.name,
					addon: project.config.addon, workshopId: project.config.workshopId })),
			};
		},
	};
}

module.exports = { createProjectStore };

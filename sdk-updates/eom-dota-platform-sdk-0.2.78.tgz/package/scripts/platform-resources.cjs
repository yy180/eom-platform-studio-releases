'use strict';
const fs = require('node:fs');
const { safePath } = require('./automatic.cjs');
const { addonRoots, resolveProjectPaths, getProjectMounts } = require('./project-paths.cjs');

// Keep dynamic Panorama entry points explicit: dependency discovery alone may
// miss layouts selected by JavaScript at runtime.
const panoramaResources = [
	'panorama/layout/custom_game/eom_platform/loading.vxml_c',
	'panorama/layout/custom_game/eom_platform/hud_platform.vxml_c',
	'panorama/scripts/custom_game/eom_platform/loading.vjs_c',
	'panorama/scripts/custom_game/eom_platform/hud_platform.vjs_c',
	'panorama/scripts/custom_game/eom_platform/polyfill.vjs_c',
	'panorama/scripts/custom_game/eom_platform/entry_config.vjs_c',
	'panorama/scripts/custom_game/eom_platform/integration/route.vjs_c',
	'panorama/styles/custom_game/eom_platform/platform.vcss_c',
];
const requiredRuntimeResources = [
	...panoramaResources,
	'scripts/vscripts/addon_game_mode.lua',
	'scripts/vscripts/addon_game_mode_client.lua',
	'scripts/vscripts/eom_platform/server.lua',
	'scripts/vscripts/eom_platform/client.lua',
	'scripts/vscripts/eom_platform/connection_client.lua',
	'scripts/vscripts/eom_platform/lobby_server.lua',
	'scripts/vscripts/eom_platform/social_server.lua',
];

function inspectCompiledResources(target, config) {
	config = resolveProjectPaths(target, config);
	const { game } = addonRoots(config), missing = [], empty = [];
	for (const relative of panoramaResources) {
		const file = game + '/' + relative;
		const full = safePath(target, file, getProjectMounts(config));
		if (!fs.existsSync(full)) { missing.push(file); continue; }
		const stats = fs.statSync(full);
		if (!stats.isFile() || stats.size === 0) empty.push(file);
	}
	return { ok: missing.length === 0 && empty.length === 0, checked: panoramaResources.length, missing, empty };
}

function assertCompiledResources(target, config) {
	const report = inspectCompiledResources(target, config);
	if (!report.ok) throw new Error('Embedded platform Panorama resources are not compiled or are empty; run the Panorama compile stage before packaging:\n' + [...report.missing, ...report.empty].join('\n'));
	return report;
}

module.exports = { panoramaResources, requiredRuntimeResources, inspectCompiledResources, assertCompiledResources };

'use strict';
const { parseKV } = require('./kv.cjs');
const platformMaps = new Set(['platform_entry', 'platform_lobby']);

// Keep value ranges so map options and unrelated addon settings survive verbatim.
function parseKV3(text) {
	const tokens = [];
	const pattern = /\s+|<!--[^]*?-->|\/\/[^\r\n]*|\/\*[^]*?\*\/|"(?:\\.|[^"\\])*"|[{}\[\]=,]|[^\s{}\[\]=,"]+/gy;
	let offset = 0;
	while (offset < text.length) {
		pattern.lastIndex = offset;
		const match = pattern.exec(text);
		if (!match) throw new Error('Unsupported addoninfo KV3 at ' + offset);
		offset = pattern.lastIndex;
		if (/^\s|^<!--|^\/\//.test(match[0]) || match[0].startsWith('/*')) continue;
		tokens.push({ raw: match[0], start: match.index, end: offset });
	}
	let index = 0;
	function value() {
		const token = tokens[index++];
		if (!token) throw new Error('Missing addoninfo KV3 value');
		if (token.raw === '{' || token.raw === '[') {
			const close = token.raw === '{' ? '}' : ']', children = [];
			while (tokens[index]?.raw !== close) {
				if (!tokens[index]) throw new Error('Unclosed addoninfo KV3 value');
				if (tokens[index].raw === ',') { index++; continue; }
				if (token.raw === '{') {
					const name = tokens[index++];
					if (tokens[index++]?.raw !== '=') throw new Error('Expected addoninfo KV3 assignment');
					children.push({ key: name.raw.startsWith('"') ? JSON.parse(name.raw) : name.raw, ...value() });
				} else children.push(value());
			}
			return { start: token.start, end: tokens[index++].end, children, kind: token.raw };
		}
		return { ...token, value: token.raw.startsWith('"') ? JSON.parse(token.raw) : token.raw };
	}
	const root = value();
	if (root.kind !== '{' || index !== tokens.length) throw new Error('Expected KV3 addoninfo.txt');
	return root;
}

function field(root, name) {
	const matches = root.children.filter(item => item.key.toLowerCase() === name.toLowerCase());
	if (matches.length > 1) throw new Error('Duplicate addoninfo declaration: ' + name);
	return matches[0];
}

function addonMaps(text) {
	let maps;
	if (text.includes('<!-- kv3 ')) {
		const entry = field(parseKV3(text), 'maps');
		if (entry && entry.kind !== '[') throw new Error('Expected addoninfo.maps array');
		maps = entry?.children.map(item => item.value) ?? [];
	} else {
		const roots = parseKV(text);
		if (roots.length !== 1 || roots[0].key.toLowerCase() !== 'addoninfo' || !roots[0].children) throw new Error('Expected AddonInfo KeyValues object');
		const entry = field(roots[0], 'maps');
		if (entry?.children) throw new Error('Expected scalar addoninfo.maps');
		maps = entry?.value.split(/[\s,]+/).filter(Boolean) ?? [];
	}
	if (maps.some(map => typeof map !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(map))) throw new Error('Invalid map name in addoninfo.txt');
	return [...new Set(maps)].filter(map => !platformMaps.has(map));
}

function retainedMaps(text, selected = []) {
	const available = addonMaps(text);
	for (const map of selected) if (!available.includes(map)) throw new Error('保留地图不在原始 addoninfo.txt 中：' + map);
	return selected;
}

function mergeKV3AddonInfo(text, selected = []) {
	retainedMaps(text, selected);
	const root = parseKV3(text), edits = [];
	let additions = '';
	const options = field(root, 'map_options');
	if (options && options.kind !== '[') throw new Error('Expected addoninfo.map_options array');
	const preserved = (options?.children ?? []).filter(option => option.kind === '{' && selected.includes(field(option, 'map')?.value)).map(option => text.slice(option.start, option.end));
	for (const [name, data] of [
		['maps', '[\n' + ['platform_entry', ...selected].map(map => '\t\t' + JSON.stringify(map) + ',').join('\n') + '\n\t]'],
		['map_options', '[\n' + ['{ map = "platform_entry" MinPlayers = 1 MaxPlayers = 1 }', ...preserved].map(option => '\t\t' + option + ',').join('\n') + '\n\t]'],
		['DefaultMap', '"platform_entry"'],
	]) {
		const existing = field(root, name);
		if (existing) edits.push({ start: existing.start, end: existing.end, text: data });
		else additions += '\t' + name + ' = ' + data + '\n';
	}
	if (additions) edits.push({ start: root.end - 1, end: root.end - 1, text: additions });
	for (const edit of edits.sort((left, right) => right.start - left.start)) text = text.slice(0, edit.start) + edit.text + text.slice(edit.end);
	return text.replace(/[\t ]+$/gm, '');
}

module.exports = { addonMaps, retainedMaps, mergeKV3AddonInfo };

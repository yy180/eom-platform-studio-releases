#!/usr/bin/env node
'use strict';
const { McpServer } = require('@modelcontextprotocol/sdk/server/mcp.js');
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
const { z } = require('zod');
const { createIntegrationService } = require('./mcp-integration.cjs');
const version = require('../package.json').version;

function createMcpServer() {
	const service = createIntegrationService();
	const server = new McpServer({ name: 'eom-dota-platform', version }, {
		instructions: 'Read platform_integration_guide before integrating SDK ' + version + '. Use absolute project paths. Discover and validate configuration, preview changes, then apply the previewId. Query platform_job until terminal status. Configured build/compile/package commands run local project code. Report not_configured stages and distinguish file checks from in-game verification.',
	});
	const target = z.string().min(1).describe('Absolute Dota 2 project directory, outside the SDK directory');
	const config = z.record(z.string(), z.unknown()).describe('platform.config.json object; if omitted, read it from the target project');
	const project = { target, config: config.optional() };
	function tool(name, description, inputSchema, method, readOnlyHint) {
		server.registerTool(name, { description, inputSchema: z.object(inputSchema).strict(), annotations: { readOnlyHint, destructiveHint: !readOnlyHint, idempotentHint: readOnlyHint, openWorldHint: !readOnlyHint } }, async input => {
			try {
				const result = await method(input);
				return { ...(result.ok === false ? { isError: true } : {}), content: [{ type: 'text', text: JSON.stringify(result, null, 2) }], structuredContent: result };
			} catch (error) { return { isError: true, content: [{ type: 'text', text: error.message }] }; }
		});
	}
	tool('platform_integration_guide', 'Read the SDK ' + version + ' integration workflow and configuration example.', {}, service.guide, true);
	tool('platform_discover', 'Identify addon roots, Lua entry paths and available npm scripts.', { target }, service.discover, true);
	tool('platform_validate_config', 'Validate the SDK configuration without writing project files.', { config }, service.validateConfig, true);
	tool('platform_project_status', 'Inspect installed SDK version, encrypted state, file conflicts and restoration support.', project, service.status, true);
	tool('platform_preview', 'Preview init, install, sync after a project rebuild, complete restore, or Lua encryption. Encryption previews execute the project local JS configuration in an isolated process. Returns a same-session previewId valid for 30 minutes; file/config changes invalidate it.', { ...project, action: z.enum(['init', 'install', 'sync', 'restore', 'encrypt', 'restore-encryption']), legacyConfig: z.string().min(1).optional().describe('Project-relative encryption config.js or .cjs; defaults to encrypt-custom-game-config.js') }, service.preview, false);
	tool('platform_apply', 'Consume a previewId, recheck its files and configuration, and start the previewed operation. Automatic install/sync/init compile Panorama using detected Dota tools; pipeline.compile optionally overrides compilation. Restore also runs configured custom compilation. Query platform_job; a compiler failure may leave the embedding change applied.', { previewId: z.string().uuid() }, service.apply, false);
	tool('platform_build', 'Start the configured finite project build → integrate → verify → compile → package pipeline. Runs local project commands. Query platform_job for progress and failures.', project, service.build, false);
	tool('platform_compile', 'Compile the selected project Panorama resources without rebuilding or wrapping its Lua and UI entry points. Runs configured local compile commands and verifies required embedded platform binaries. Query platform_job for progress, validation and failures.', project, service.compile, false);
	tool('platform_job', 'Read an operation status, bounded log, report and error by jobId in this session.', { jobId: z.string().uuid() }, service.job, true);
	tool('platform_check_package', 'Inspect the actual Workshop VPK for platform UI layouts, scripts, styles and Lua boot modules. A locally ready project does not prove these resources were packaged. Missing or unreadable required resources return isError and ok false.', { file: z.string().min(1).describe('Absolute path to the final Workshop VPK') }, service.checkPackage, true);
	server.registerResource('integration-guide', 'eom-platform://integration/guide', { description: 'Dota 2 SDK ' + version + ' integration workflow', mimeType: 'text/markdown' }, async uri => ({ contents: [{ uri: uri.href, mimeType: 'text/markdown', text: service.guide().guide }] }));
	server.registerResource('config-example', 'eom-platform://integration/config-example', { description: 'SDK configuration example; replace Workshop ID, project names and lobby addresses', mimeType: 'application/json' }, async uri => ({ contents: [{ uri: uri.href, mimeType: 'application/json', text: JSON.stringify(service.guide().configExample, null, 2) }] }));
	server.registerPrompt('integrate_dota_project', { description: 'Integrate SDK ' + version + ' into an existing Dota 2 project', argsSchema: { target } }, async ({ target: projectTarget }) => ({ messages: [{ role: 'user', content: { type: 'text', text: 'Integrate @eom/dota-platform-sdk ' + version + ' into the Dota 2 project at ' + JSON.stringify(projectTarget) + '. Read platform_integration_guide, discover the project, and validate its configuration. Resolve missing Workshop ID, three-language names and lobby host:port values from the project or ask for the missing values. Preview the applicable action and apply the previewId within the user-authorized scope. Poll platform_job until completion and report validation, unconfigured stages and any remaining in-game checks. ' + service.guide().guide } }] }));
	return server;
}

async function start() {
	const server = createMcpServer();
	await server.connect(new StdioServerTransport());
	return server;
}

if (require.main === module) start().catch(error => { process.stderr.write(error.message + '\n'); process.exitCode = 1; });
module.exports = { createMcpServer, start };

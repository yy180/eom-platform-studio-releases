const fs = require('node:fs');
const path = require('node:path');
const { safePath, hash, restore } = require('./automatic.cjs');
const { writePlan } = require('./write-plan.cjs');
const { addonRoots, resolveProjectPaths, getProjectMounts } = require('./project-paths.cjs');

function captureBuildOutputs(target, config, files) {
	config = resolveProjectPaths(target, config);
    const resolve = file => safePath(target, file, getProjectMounts(config));
    const stateFile = '.eom-platform/' + config.addon + '/state.json';
    if (!fs.existsSync(resolve(stateFile))) return null;
    const bytes = fs.readFileSync(resolve(stateFile));
    const state = JSON.parse(bytes);
    if (state.schema !== 2 || state.ledger?.exact !== true) throw new Error('Compiled outputs require a complete native restoration record');
    restore(target, config, { dryRun: true });
    const directories = new Set();
    const entries = [...new Set(files)].sort().map(file => {
        if (!file.startsWith(addonRoots(config).game + '/panorama/') || !/\.(?:vjs|vcss|vxml|vtex)_c$/.test(file)) throw new Error('Expected a compiled Panorama output: ' + file);
        const full = resolve(file);
        const before = fs.existsSync(full) ? fs.readFileSync(full) : null;
        const previous = state.ledger.files[file];
        if (previous && (before === null ? null : hash(before)) !== previous.after) throw new Error('Compiled SDK output changed: ' + file);
        for (let directory = path.posix.dirname(file); directory !== '.' && !fs.existsSync(resolve(directory)); directory = path.posix.dirname(directory)) directories.add(directory);
        return { file, before: before === null ? null : before.toString('base64'), checksum: before === null ? null : hash(before) };
    });
    return { stateFile, stateHash: hash(bytes), entries, directories: [...directories] };
}

// Capture before invoking the compiler; record even a partial compile so restore
// can remove new outputs and recover overwritten native resources after failure.
function recordBuildOutputs(target, config, snapshot) {
	config = resolveProjectPaths(target, config);
    if (!snapshot) return;
    const resolve = file => safePath(target, file, getProjectMounts(config));
    const bytes = fs.readFileSync(resolve(snapshot.stateFile));
    if (hash(bytes) !== snapshot.stateHash) throw new Error('SDK integration changed while compiling resources');
    const state = JSON.parse(bytes);
    const recorded = [];
    for (const { file, before, checksum } of snapshot.entries) {
        const full = resolve(file);
        const after = fs.existsSync(full) ? hash(fs.readFileSync(full)) : null;
        const previous = state.ledger.files[file];
        if (!previous && after === checksum) continue;
        state.ledger.files[file] = { before: previous ? previous.before : before, after };
        recorded.push(file);
    }
    state.ledger.compiledOutputs = [...new Set([...(state.ledger.compiledOutputs || []), ...recorded])].sort();
    state.ledger.createdDirectories = [...new Set([...state.ledger.createdDirectories, ...snapshot.directories.filter(directory => fs.existsSync(resolve(directory)))])]
        .sort((left, right) => right.split('/').length - left.split('/').length || left.localeCompare(right));
    writePlan([{ destination: resolve(snapshot.stateFile), data: Buffer.from(JSON.stringify(state, null, 2) + '\n') }]);
}

module.exports = { captureBuildOutputs, recordBuildOutputs };

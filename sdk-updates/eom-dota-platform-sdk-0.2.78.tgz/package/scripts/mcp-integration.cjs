'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID, createHash } = require('node:crypto');
const { fork } = require('node:child_process');
const { install, validate } = require('./install.cjs');
const { safePath, restore } = require('./automatic.cjs');
const { discover, inspect, buildProject, installProject, compileProject } = require('./pipeline.cjs');
const { projectStatus } = require('./studio-project.cjs');
const { assertNoWatchers } = require('./project-activity.cjs');
const { addonRoots, resolveProjectPaths, getProjectMounts, portableProjectConfig } = require('./project-paths.cjs');
const { checkPackage } = require('./check-package.cjs');

const sdkRoot = path.resolve(__dirname, '..');
const version = require('../package.json').version;
const digest = value => createHash('sha256').update(value).digest('hex');
const actions = ['init', 'install', 'sync', 'restore', 'encrypt', 'restore-encryption'];
const canonical = file => {
	const absolute = path.resolve(file);
	const resolved = fs.existsSync(absolute) ? fs.realpathSync(absolute) : absolute;
	return process.platform === 'win32' ? resolved.toLowerCase() : resolved;
};

function targetPath(target) {
	if (typeof target !== 'string' || !path.isAbsolute(target)) throw new Error('target must be an absolute project directory');
	const resolved = path.resolve(target), actual = canonical(resolved), sdk = canonical(sdkRoot);
	if (actual === sdk || actual.startsWith(sdk + path.sep)) throw new Error('Use a game project outside the SDK directory');
	if (fs.existsSync(resolved) && !fs.statSync(resolved).isDirectory()) throw new Error('target must be a directory');
	return fs.existsSync(resolved) ? fs.realpathSync(resolved) : resolved;
}

function projectInput(input) {
	const target = targetPath(input.target);
	const configFile = safePath(target, 'platform.config.json');
	const config = portableProjectConfig(JSON.parse(JSON.stringify(input.config ?? JSON.parse(fs.readFileSync(configFile, 'utf8')))));
	validate(config);
	return { target, config: resolveProjectPaths(target, config) };
}

function treeFingerprint(directory) {
	if (!fs.existsSync(directory)) return null;
	const visit = (file, ancestors = new Set()) => {
		const real = fs.realpathSync(file);
		if (ancestors.has(real)) throw new Error('Circular SDK input: ' + file);
		if (!fs.statSync(file).isDirectory()) return digest(fs.readFileSync(file));
		const next = new Set([...ancestors, real]);
		return fs.readdirSync(file).sort().map(name => [name, visit(path.join(file, name), next)]);
	};
	return digest(JSON.stringify(visit(directory)));
}

// Run project encryption configuration in a fresh process. Its module cache and
// console output must not affect the MCP transport or expose keys in tool logs.
function encryptionOperation(input, execute = false) {
	return new Promise((resolve, reject) => {
		const child = fork(__filename, ['--encryption-worker'], { stdio: ['ignore', 'ignore', 'ignore', 'ipc'], windowsHide: true });
		let result;
		const timeout = setTimeout(() => {
			child.kill();
			reject(new Error('Encryption configuration or operation timed out; check the local project before retrying'));
		}, execute ? 300000 : 30000);
		child.on('message', message => { result = message; });
		child.on('error', error => { clearTimeout(timeout); reject(error); });
		child.on('exit', code => {
			clearTimeout(timeout);
			if (code !== 0 || !result) reject(new Error('Encryption worker failed; inspect the local project configuration'));
			else if (result.error) reject(new Error(result.error));
			else resolve(result.report);
		});
		child.send({ input, execute, paths: digest(JSON.stringify(getProjectMounts(input.config))) });
	});
}

function createIntegrationService() {
	const previews = new Map(), jobs = new Map();
	let activeJob = null;
	function assertIdle() {
		if (activeJob?.status === 'running') throw new Error('A project operation is running; query platform_job before starting another operation');
	}
	function guide() {
		return { version, guide: fs.readFileSync(path.join(sdkRoot, 'mcp/integration-guide.md'), 'utf8'), configExample: JSON.parse(fs.readFileSync(path.join(sdkRoot, 'platform.config.example.json'), 'utf8')) };
	}
	function validateConfig({ config }) {
		validate(config);
		return { valid: true, version, addon: config.addon, integrationMode: config.integration?.mode ?? 'auto' };
	}
	function status(input) {
		return { version, ...projectStatus(sdkRoot, projectInput(input)) };
	}
	async function prepare(input) {
		if (!actions.includes(input.action)) throw new Error('Unsupported preview action');
		const { target, config } = projectInput(input);
		const { content, game } = addonRoots(config);
		if (config.integration?.mode === 'manual') throw new Error('MCP embedding requires integration.mode auto');
		assertNoWatchers(target);
		const resolve = file => safePath(target, file, getProjectMounts(config));
		const encryption = ['encrypt', 'restore-encryption'].includes(input.action);
		let report;
		if (encryption) report = await encryptionOperation({ target, config, action: input.action, legacyConfig: input.legacyConfig });
		else report = input.action === 'restore' ? restore(target, config, { dryRun: true }) : install(target, config, { initialize: input.action === 'init', rebuilt: input.action === 'sync', dryRun: true });
		const reportedActions = new Map((report.actions ?? []).map(item => [item.file, item.action]));
		const files = report.files.map(file => ({ file, action: reportedActions.get(file) === 'remove' ? 'remove' : reportedActions.get(file) === 'restore' ? 'restore' : fs.existsSync(resolve(file)) ? 'update' : 'create' }));
		const inputs = new Set([...report.files, ...(report.skippedMaps ?? []), 'platform.config.json', game + '/scripts/vscripts/addon_game_mode_client.lua', content + '/panorama/layout/custom_game/team_select.xml']);
		for (const field of ['serverEntry', 'clientEntry']) if (config.integration?.[field]) inputs.add(config.integration[field]);
		if (config.panorama?.battleLoadingLayout) inputs.add(content + '/panorama/layout/custom_game/' + config.panorama.battleLoadingLayout);
		for (const field of ['battleServer', 'battleClient']) if (config[field]) inputs.add(game + '/scripts/vscripts/' + config[field] + '.lua');
		const directories = new Set();
		const checks = [...inputs].sort().map(file => {
			for (let parent = path.posix.dirname(file); parent !== '.'; parent = path.posix.dirname(parent)) directories.add(parent);
			const full = resolve(file);
			return [file, fs.existsSync(full) ? [canonical(full), digest(fs.readFileSync(full))] : null];
		});
		const directoryChecks = [...directories].sort().map(file => {
			const full = resolve(file);
			return [file, fs.existsSync(full) ? fs.readdirSync(full).sort() : null];
		});
		const sources = ['dist/content', 'dist/game', 'templates', 'content/platform/localization', 'content/platform/maps', 'game/platform/maps', 'scripts', 'package.json'].map(file => [file, treeFingerprint(path.join(sdkRoot, file))]);
		const signature = digest(JSON.stringify([input, canonical(target), config, getProjectMounts(config), report, checks, directoryChecks, sources]));
		return { input: { target, config, action: input.action, legacyConfig: input.legacyConfig }, signature, report: { version, target, action: input.action, files, directories: report.directories ?? report.restoration?.directories ?? [], skippedMaps: report.skippedMaps ?? [], restoration: report.restoration, compile: encryption ? null : config.pipeline?.compile ?? [], encryptionPreview: encryption ? report : undefined } };
	}
	async function preview(input) {
		assertIdle();
		const original = JSON.parse(JSON.stringify(input));
		const prepared = await prepare(original);
		assertIdle();
		const previewId = randomUUID();
		while (previews.size >= 32) previews.delete(previews.keys().next().value);
		previews.set(previewId, { original, ...prepared, expires: Date.now() + 30 * 60 * 1000 });
		return { previewId, ...prepared.report };
	}
	function startJob(input, run) {
		assertIdle();
		const job = { jobId: randomUUID(), action: input.action, target: input.target, status: 'running', log: '', startedAt: new Date().toISOString() };
		activeJob = job;
		while (jobs.size >= 32) jobs.delete(jobs.keys().next().value);
		jobs.set(job.jobId, job);
		const log = text => { job.log = (job.log + text).slice(-200000); };
		setImmediate(async () => {
			try { job.report = await run(log, job); job.status = 'succeeded'; }
			catch (error) { job.error = error.message; job.status = 'failed'; }
			finally {
				try { job.state = status(input); }
				catch (error) { job.state = { error: error.message }; }
				job.finishedAt = new Date().toISOString();
			}
		});
		return { jobId: job.jobId, action: job.action, target: job.target, status: job.status };
	}
	async function apply({ previewId }) {
		assertIdle();
		const saved = previews.get(previewId);
		if (!saved || saved.expires < Date.now()) { previews.delete(previewId); throw new Error('Unknown or expired previewId; generate a new preview'); }
		previews.delete(previewId);
		const current = await prepare(saved.original);
		if (current.signature !== saved.signature) throw new Error('Project files, configuration or SDK inputs changed; generate a new preview');
		const input = current.input;
		return startJob(input, async (log, job) => {
			const latest = await prepare(saved.original);
			if (latest.signature !== saved.signature) throw new Error('Project files, configuration or SDK inputs changed; generate a new preview');
			assertNoWatchers(input.target);
			if (['encrypt', 'restore-encryption'].includes(input.action)) return encryptionOperation(input, true);
			if (input.action === 'restore') {
				job.report = { operation: restore(input.target, input.config), embeddingApplied: false, stages: [] };
				try { job.report.stages.push(await compileProject(input.target, input.config, { log })); }
				catch (error) { job.report.stages.push({ stage: 'compile', status: 'failed' }); throw error; }
				return job.report;
			}
			try {
				const { compilation, validation, ...operation } = await installProject(input.target, input.config, { initialize: input.action === 'init', rebuilt: input.action === 'sync', log });
				return { operation, embeddingApplied: true, stages: [compilation], validation };
			} catch (error) {
				if (error.integrationApplied) job.report = { operation: error.install, embeddingApplied: true, stages: [...(error.compilation ? [error.compilation] : []), { stage: error.stage ?? 'compile', status: 'failed' }] };
				throw error;
			}
		});
	}
	function compile(input) {
		assertIdle();
		const original = JSON.parse(JSON.stringify(input));
		function selectedInput() {
			const selected = projectInput(original);
			assertNoWatchers(selected.target);
			const resolve = file => safePath(selected.target, file, getProjectMounts(selected.config));
			const encryption = '.eom-platform/' + selected.config.addon + '/encryption.json';
			if (fs.existsSync(resolve(encryption))) throw new Error('Restore encrypted outputs with restore-encryption before compiling');
			const roots = addonRoots(selected.config);
			const checks = ['platform.config.json', roots.game + '/scripts/eom_platform_manifest.json'].map(file => {
				const full = resolve(file);
				return [file, fs.existsSync(full) ? digest(fs.readFileSync(full)) : null];
			});
			const signature = digest(JSON.stringify([selected, canonical(selected.target), getProjectMounts(selected.config), Object.values(roots).map(root => canonical(resolve(root))), checks]));
			return { ...selected, signature };
		}
		const selected = selectedInput();
		return startJob({ ...selected, action: 'compile' }, async (log, job) => {
			const current = selectedInput();
			if (current.signature !== selected.signature) throw new Error('Project configuration or integration changed; run platform_compile again');
			job.report = { stages: [] };
			try { job.report.stages.push(await compileProject(current.target, current.config, { log })); }
			catch (error) { job.report.stages.push({ stage: 'compile', status: 'failed' }); throw error; }
			const manifest = addonRoots(current.config).game + '/scripts/eom_platform_manifest.json';
			if (fs.existsSync(safePath(current.target, manifest, getProjectMounts(current.config)))) job.report.validation = inspect(current.target, current.config);
			return job.report;
		});
	}
	function build(input) {
		assertIdle();
		const selected = projectInput(input);
		assertNoWatchers(selected.target);
		if (!selected.config.pipeline?.build?.length) throw new Error('Configure pipeline.build with finite original project build commands');
		if (selected.config.integration?.mode === 'manual') throw new Error('MCP embedding requires integration.mode auto');
		if (fs.existsSync(safePath(selected.target, '.eom-platform/' + selected.config.addon + '/encryption.json', getProjectMounts(selected.config)))) throw new Error('Restore encrypted outputs with restore-encryption before building');
		return startJob({ ...selected, action: 'build' }, async log => {
			assertNoWatchers(selected.target);
			return buildProject(selected.target, selected.config, { log });
		});
	}
	function job({ jobId }) {
		const selected = jobs.get(jobId);
		if (!selected) throw new Error('Unknown jobId in this MCP session');
		return JSON.parse(JSON.stringify(selected));
	}
	return { guide, discover: ({ target }) => ({ version, ...discover(targetPath(target)) }), validateConfig, status, preview, apply, build, compile, job, checkPackage: ({ file }) => checkPackage(file) };
}

if (require.main === module && process.argv[2] === '--encryption-worker') {
	process.once('message', ({ input, execute, paths }) => {
		let response;
		try {
			assertNoWatchers(input.target);
			input.config = resolveProjectPaths(input.target, input.config);
			if (digest(JSON.stringify(getProjectMounts(input.config))) !== paths) throw new Error('Project link targets changed; generate a new preview');
			const prepared = require('./studio-project.cjs').prepareEncryption(sdkRoot, input);
			response = { report: execute ? prepared.execute() : prepared.preview };
		} catch (error) { response = { error: error.message }; }
		process.send(response, error => { process.exit(error ? 1 : 0); });
	});
}

module.exports = { createIntegrationService };

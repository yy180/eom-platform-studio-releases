const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
const form = $('#config-form');
const titles = { overview: '项目工作台', config: '项目设置', integration: '文件变更', project: '项目操作', release: 'SDK 维护', settings: '工具详情', diagnostics: '错误日志与反馈' };
let config = {};
let preview = null;
let busy = false;
let polling = false;
let saved = '';
let embeddingState = null;
let embeddingAction = null;
let projectState = null;
let consumerMode = false;
let currentPage = null;
let pendingRequests = 0;
let openedTarget = '';
let needsConfiguration = false;
let projectOpenError = '';
let projectOpening = false;
let nextAction = 'open';
let toolVersion = '';
let toolUpdate = { enabled: false, status: 'unconfigured', message: '尚未配置在线更新服务' };
let savedProjects = [];
let configTarget = '';
let configEdited = false;
let profileId = null;
let savedProfileName = '';
let savedTarget = '';
let availableMaps = [];
let mapChoices = [];
const loadedProfiles = new Map();
let profileSourceSignature = null;
let profileSelection = null;
let profileSelectionVersion = 0;
let disableConfirmation = null;
let deleteProfileConfirmation = null;
let noticeTimer = null;
let noticeError = false;
let noticeHovered = false;
let noticeFocused = false;
let diagnosticState = { enabled: false, automatic: false, count: 0 };
let diagnosticPreview = null;
let lobbyRows = [];
const lobbyLanguages = ['schinese', 'english', 'russian'];
const legacyLobbyLabels = {
    china: { schinese: '国服', english: 'China', russian: 'Китай' },
    overseas: { schinese: '欧服', english: 'Europe', russian: 'Европа' },
    overseas2: { schinese: '俄罗斯服', english: 'Russia', russian: 'Россия' },
};

function lobbyField(title, name, value, required = false, placeholder = '') {
    const label = document.createElement('label');
    label.textContent = title;
    const input = document.createElement('input');
    Object.assign(input, { name, value, required, placeholder });
    label.append(input);
    return { label, input };
}

function createLobbyRow(id, address = '', labels = {}) {
    const element = document.createElement('fieldset');
    element.className = 'lobby-row';
    const legend = document.createElement('legend');
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'lobby-remove';
    remove.textContent = '删除';
    const name = lobbyField('简体中文名称 *', 'lobbyLabels.' + id + '.schinese', labels.schinese ?? '', true, '例如：中国区');
    name.input.maxLength = 120;
    const endpoint = lobbyField('大厅地址（IP／域名:端口）*', 'lobbies.' + id, address, true, 'host.example.com:39000');
    endpoint.input.spellcheck = false;
    endpoint.input.pattern = '[a-zA-Z0-9.\\-]+:[0-9]+';
    const endpointFields = document.createElement('div');
    endpointFields.className = 'fields lobby-endpoint-fields';
    endpointFields.append(endpoint.label);
    const nameFields = document.createElement('div');
    nameFields.className = 'fields lobby-name-fields';
    nameFields.append(name.label);
    for (const [language, title] of [['english', 'English 名称'], ['russian', 'Русский 名称']]) {
        const translated = lobbyField(title, 'lobbyLabels.' + id + '.' + language, labels[language] ?? '', false, '留空使用简体中文名称');
        translated.input.maxLength = 120;
        nameFields.append(translated.label);
    }
    const languageDefaults = document.createElement('div');
    languageDefaults.className = 'lobby-language-defaults';
    const languageTitle = document.createElement('p');
    languageTitle.textContent = '默认跳转至此区服的语言';
    const languageOptions = document.createElement('div');
    languageOptions.className = 'lobby-language-options';
    const languages = {};
    for (const [language, title] of [['schinese', '简体中文'], ['english', 'English'], ['russian', 'Русский']]) {
        const label = document.createElement('label');
        const input = document.createElement('input');
        Object.assign(input, { type: 'radio', name: 'connection.languageRegions.' + language, value: id, required: true });
        const text = document.createElement('span');
        text.textContent = title;
        label.append(input, text);
        languageOptions.append(label);
        languages[language] = input;
        input.addEventListener('change', () => {
            if (busy || !input.checked) return;
            syncLobbyChoices({ [input.name]: id });
            configEdited = true;
            changed();
        });
    }
    languageDefaults.append(languageTitle, languageOptions);
    element.append(legend, remove, endpointFields, nameFields, languageDefaults);
    const row = { id, element, legend, remove, name: name.input, languages };
    remove.addEventListener('click', () => {
        if (busy || lobbyRows.length === 1) return;
        lobbyRows = lobbyRows.filter(item => item !== row);
        renderLobbyList();
        configEdited = true;
        changed();
    });
    return row;
}

function syncLobbyChoices(selections = {}) {
    for (const language of lobbyLanguages) {
        const selected = selections['connection.languageRegions.' + language] ?? lobbyRows.find(row => row.languages[language].checked)?.id ?? lobbyRows[0].id;
        for (const row of lobbyRows) row.languages[language].checked = row.id === selected;
    }
    for (const select of $$('[data-lobby-choice]')) {
        const selected = selections[select.name] ?? select.value;
        const options = lobbyRows.map((row, index) => {
            const option = document.createElement('option');
            option.value = row.id;
            option.textContent = row.name.value.trim() || '区服 ' + (index + 1);
            return option;
        });
        select.replaceChildren(...options);
        select.value = lobbyRows.some(row => row.id === selected) ? selected : lobbyRows[0].id;
    }
}

function renderLobbyList(selections) {
    lobbyRows.forEach((row, index) => {
        row.legend.textContent = '区服 ' + (index + 1);
        row.remove.disabled = busy || lobbyRows.length === 1;
        row.remove.setAttribute('aria-label', '删除区服 ' + (index + 1));
    });
    $('#lobby-list').replaceChildren(...lobbyRows.map(row => row.element));
    syncLobbyChoices(selections);
}

function renderLobbies(value) {
    lobbyRows = Object.entries(value.lobbies ?? {}).filter(([, address]) => address).map(([id, address]) => createLobbyRow(id, address, value.lobbyLabels?.[id] ?? legacyLobbyLabels[id]));
    if (!lobbyRows.length) lobbyRows = [createLobbyRow('region_1')];
    const fallback = lobbyRows.some(row => row.id === value.connection?.region) ? value.connection.region : lobbyRows[0].id;
    const selections = { 'connection.region': fallback };
    const legacy = { schinese: 'china', english: 'overseas', russian: 'overseas2' };
    for (const language of lobbyLanguages) selections['connection.languageRegions.' + language] = value.connection?.languageRegions?.[language] ?? (lobbyRows.some(row => row.id === legacy[language]) ? legacy[language] : fallback);
    renderLobbyList(selections);
}

$('#add-lobby').addEventListener('click', () => {
    if (busy) return;
    let number = 1;
    while (lobbyRows.some(row => row.id === 'region_' + number) || Object.hasOwn(config.lobbies ?? {}, 'region_' + number)) number++;
    const row = createLobbyRow('region_' + number);
    lobbyRows.push(row);
    renderLobbyList();
    configEdited = true;
    changed();
    row.name.focus();
});

function recordUiError(error, operation = '') {
    api('diagnostics/event', { message: error?.message || String(error), stack: error?.stack || '', operation }).then(() => api('diagnostics')).then(renderDiagnostics).catch(() => {});
}

function renderDiagnostics(state) {
    diagnosticState = state;
    $('#diagnostics-count').textContent = (state.count || 0) + ' 条';
    $('#diagnostics-auto').checked = state.automatic === true;
    $('#diagnostics-auto').disabled = !state.enabled;
    $('#diagnostics-status').textContent = state.error ? '日志已在本机保留：' + state.error : state.enabled ? '日志接收服务已配置，可查看内容后发送。' : '尚未配置远程接收服务，可先查看并导出本机错误日志。';
    $('#diagnostics-destination').textContent = state.endpoint ? '发送至：' + state.endpoint : '接收服务由工具开发者配置，使用者无需填写服务器地址。';
    $('#diagnostics-upload').disabled = !state.enabled || !diagnosticPreview || !$('#diagnostics-consent').checked || state.sending === true;
}

for (const name of ['error', 'unhandledrejection']) window.addEventListener(name, event => recordUiError(event.error || event.reason || new Error(event.message || '界面运行错误'), name));

async function previewDiagnostics() {
    diagnosticPreview = await api('diagnostics/preview', { description: $('#diagnostics-description').value });
    $('#diagnostics-content').textContent = JSON.stringify(diagnosticPreview, null, 2);
    $('#diagnostics-preview-card').hidden = false;
    $('#diagnostics-preview-card').open = true;
    $('#diagnostics-consent').checked = false;
    renderDiagnostics(await api('diagnostics'));
    return diagnosticPreview;
}

$('#diagnostics-preview').addEventListener('click', () => run(previewDiagnostics));
$('#diagnostics-consent').addEventListener('change', () => renderDiagnostics(diagnosticState));
$('#diagnostics-description').addEventListener('input', () => { diagnosticPreview = null; $('#diagnostics-consent').checked = false; renderDiagnostics(diagnosticState); });
$('#diagnostics-auto').addEventListener('change', () => run(async () => {
    try { renderDiagnostics(await api('diagnostics/preferences', { automatic: $('#diagnostics-auto').checked })); }
    catch (error) { renderDiagnostics(diagnosticState); throw error; }
}));
$('#diagnostics-upload').addEventListener('click', () => run(async () => {
    if (!diagnosticPreview || !$('#diagnostics-consent').checked) return;
    $('#diagnostics-upload').disabled = true;
    try {
        const result = await api('diagnostics/upload', { reportId: diagnosticPreview.reportId, consent: true });
        $('#diagnostics-upload-result').textContent = '报告已提交，编号：' + result.reportId;
        $('#diagnostics-consent').checked = false;
    } finally { renderDiagnostics(await api('diagnostics')); }
}));
$('#diagnostics-export').addEventListener('click', () => run(async () => {
    const report = await previewDiagnostics();
    const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2) + '\n'], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = url; link.download = 'eom-studio-report-' + report.reportId + '.json'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}));

function renderSavedProjects(projects, selected = profileId) {
    savedProjects = projects || [];
    $('#delete-profile').disabled = busy || !profileId;
    const list = $('#saved-projects');
    list.replaceChildren();
    $('#saved-project-count').textContent = String(savedProjects.length);
    for (const project of savedProjects) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'saved-project-entry';
        button.dataset.target = project.target;
        button.title = project.target || '尚未选择项目目录';
        button.disabled = busy;
        button.setAttribute('aria-pressed', String(project.id ? project.id === selected : project.target === selected));
        const name = document.createElement('strong');
        name.textContent = project.name;
        const directory = document.createElement('small');
        directory.textContent = project.target || '尚未选择项目目录';
        button.append(name, directory);
        button.addEventListener('click', () => run(() => busy ? undefined : project.id ? selectProfile(project.id) : openProject(false, project.target)));
        list.append(button);
    }
    renderSavedProjectState();
}

function renderSavedProjectState() {
    const embedding = currentEmbedding();
    for (const button of $$('#saved-projects button')) {
        button.dataset.platformState = embedding && button.dataset.target === embedding.target
            ? embedding.enabled ? 'enabled' : 'disabled'
            : 'unknown';
    }
}

function status(selector, text, state) {
    const element = $(selector);
    if (!element) return;
    element.textContent = text;
    element.dataset.state = state;
}

function activity() {
    const active = busy || pendingRequests > 0;
    $('main').setAttribute('aria-busy', String(active));
    status('#task-indicator', active ? '正在处理' : '空闲', active ? 'running' : 'idle');
}

function invalidateProjectStatus(message = '配置已变化，请刷新项目状态') {
    projectState = null;
    status('#project-status', message, 'stale');
    status('#overview-project-state', $('#target').value ? '等待检查' : '尚未选择', 'stale');
    $('#project-problem').hidden = true;
    renderEmbeddingState();
    renderNextAction();
}

function renderNextAction() {
    const target = $('#target').value.trim();
    const opened = !!openedTarget && openedTarget === target;
    let title = '先打开一个游戏项目', description = '填写下方项目目录，打开后即可开启平台功能。', label = '打开项目';
    nextAction = 'open';
    if (projectOpening) { title = '正在打开项目…'; description = '正在读取项目设置和平台状态。'; label = '正在打开…'; }
    else if (projectOpenError) { title = '项目未能打开'; description = projectOpenError; label = '重新打开项目'; }
    else if (opened && needsConfiguration) { title = '先完成项目设置'; description = '填写游戏信息和大厅地址，保存后即可开启平台功能。'; label = '设置项目'; nextAction = 'config'; }
    else if (opened) {
        const embedding = currentEmbedding();
        title = embedding ? (embedding.enabled ? '平台已开启' : '平台已关闭') : '平台状态待检查';
        description = embedding?.enabled ? '关闭平台会丢弃接入文件的改动，还原原项目文件，并移除平台新增文件。' : '点击下方按钮，接入平台大厅和连接功能，并保存还原备份。';
        if (hasChanges()) description = '设置有未保存的修改，请先保存设置。';
        else if (!projectState) description = '检查当前项目后，即可切换平台功能。';
        else if (projectState.encrypted) description = '请使用原项目工具恢复明文，再切换平台功能。';
        else if (projectState.state === 'needs-sync') description = embedding?.enabled ? '接入文件有变化，仍可关闭平台；关闭时会丢弃这些变化并还原原项目文件。' : '游戏文件有变化，可在下方“文件变更预览”中同步接入。';
        else if (projectState.state === 'needs-compile') description = '平台资源编译未完成，请检查 Dota 2 Workshop Tools 后重新接入。';
        else if (embedding?.enabled && toolVersion && projectState.version && projectState.version !== toolVersion) description = '平台有新版本，可在下方“文件变更预览”中更新。';
    }
    $('#next-title').textContent = title;
    $('#next-description').textContent = description;
    $('#next-status').textContent = title;
    $('#next-status').hidden = !opened;
    $('#next-action').textContent = label;
    $('#next-action').hidden = opened && !needsConfiguration;
    $('#next-action').disabled = busy;
    $('#other-actions').hidden = !opened || needsConfiguration || !projectState;
    $('#refresh-project').hidden = !opened || needsConfiguration;
    $('#page-title').textContent = opened ? (config.displayName?.schinese || config.addon || '项目工作台') : '项目工作台';
    if (!opened) { status('#project-name', '尚未打开项目', 'idle'); status('#workspace-save-state', '', 'idle'); }
    renderEmbeddingState();
}

function readConfigSafely() { try { return readConfig(); } catch { return null; } }

async function api(route, input) {
    if (route !== 'select-profile' && profileSelection) {
        const expected = profileSourceSignature;
        const selected = await profileSelection;
        if (expected && selected && profileSignature(selected) !== expected) throw new Error('配置已在其他位置更新，请检查当前设置后重试。');
    }
    pendingRequests++;
    activity();
    try {
        let response;
        try {
            response = await fetch('/api/' + route, {
                method: input === undefined ? 'GET' : 'POST',
                headers: { 'Content-Type': 'application/json', 'X-Studio-Token': $('meta[name="studio-token"]').content },
                body: input === undefined ? undefined : JSON.stringify(input),
            });
        } catch (error) {
            status('#connection-status', '连接失败', 'error');
            throw new Error('无法连接本地工作台，请确认服务已启动后刷新页面。');
        }
        status('#connection-status', '本地服务已连接', 'connected');
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || '请求失败');
        return result;
    } finally {
        pendingRequests--;
        activity();
    }
}

function notify(message, error = false) {
    const notice = $('#notice');
    stopNoticeTimer();
    noticeError = error;
    notice.hidden = false;
    noticeHovered = notice.matches(':hover');
    noticeFocused = notice.contains(document.activeElement);
    notice.className = error ? 'error' : 'success';
    notice.setAttribute('role', error ? 'alert' : 'status');
    notice.setAttribute('aria-live', error ? 'assertive' : 'polite');
    ($('#notice-message') || notice).textContent = message;
    scheduleNoticeDismiss();
}

function stopNoticeTimer() {
    clearTimeout(noticeTimer);
    noticeTimer = null;
}

function dismissNotice() {
    stopNoticeTimer();
    $('#notice').hidden = true;
    noticeHovered = false;
    noticeFocused = false;
}

function scheduleNoticeDismiss() {
    stopNoticeTimer();
    if ($('#notice').hidden || noticeError || noticeHovered || noticeFocused) return;
    const timer = setTimeout(() => {
        if (noticeTimer === timer) dismissNotice();
    }, 6000);
    noticeTimer = timer;
}

function show(page, focus = true) {
    if (consumerMode && page === 'release') page = 'project';
    if (!titles[page]) page = 'overview';
    $$('[data-section]').forEach(section => {
        section.hidden = (consumerMode && section.dataset.section === 'release') || (['settings', 'diagnostics'].includes(section.dataset.section) && section.dataset.section !== page);
    });
    const section = $('[data-section="' + page + '"]');
    if (section) section.open = true;
    if ($('#page-description')) $('#page-description').textContent = '配置大厅地址，将平台功能接入游戏。';
    if (currentPage !== page && focus) {
        if (page === 'overview') window.scrollTo({ top: 0, behavior: 'instant' });
        else section?.scrollIntoView({ block: 'start' });
        (page === 'overview' ? $('#page-title') : section)?.focus({ preventScroll: true });
    }
    currentPage = page;
    $('.project-workspace').hidden = false;
    $('#page-description').hidden = false;
    renderNextAction();
    if (location.hash !== '#' + page) location.hash = page;
}

function readConfig() {
    const next = structuredClone(config);
    delete next.integration?.mounts;
    next.lobbies = {};
    next.lobbyLabels = Object.fromEntries(lobbyRows.filter(row => config.lobbyLabels?.[row.id]?.tchinese).map(row => [row.id, { tchinese: config.lobbyLabels[row.id].tchinese }]));
    next.connection ??= {};
    next.connection.languageRegions = {};
    for (const input of form.elements) {
        if (!input.name || input.type === 'radio' && !input.checked) continue;
        const keys = input.name.split('.');
        let parent = next;
        for (const key of keys.slice(0, -1)) parent = parent[key] ??= {};
        const key = keys.at(-1);
        if (input.value.trim() || input.required) parent[key] = input.value.trim();
        else delete parent[key];
    }
    for (const labels of Object.values(next.lobbyLabels)) {
        for (const language of lobbyLanguages) labels[language] ||= labels.schinese || '';
    }
    delete next.connection?.mode;
    const retained = mapChoices.filter(choice => choice.input.checked).map(choice => choice.map);
    if (retained.length || next.integration?.retainedMaps !== undefined) (next.integration ??= {}).retainedMaps = retained;
    if (next.panorama && !Object.keys(next.panorama).length) delete next.panorama;
    return next;
}

function renderConfig(value, persisted = false) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('配置必须是 JSON 对象');
    // Keep unknown configuration keys when editing a newer config with this tool.
    for (const field of ['displayName', 'lobbies', 'lobbyLabels', 'panorama', 'integration', 'connection', 'pipeline']) {
        if (value[field] !== undefined && (!value[field] || typeof value[field] !== 'object' || Array.isArray(value[field]))) throw new Error(field + ' 必须是对象');
    }
    for (const [id, address] of Object.entries(value.lobbies ?? {})) {
        if (!/^[a-z][a-z0-9_]{0,63}$/.test(id) || ['constructor', 'prototype', 'lobby_address', 'overseas_lobby_address', 'overseas2_lobby_address'].includes(id)) throw new Error('无效的区服标识：' + id);
        if (typeof address !== 'string') throw new Error('lobbies.' + id + ' 必须是字符串');
    }
    for (const [id, labels] of Object.entries(value.lobbyLabels ?? {})) {
        if ((!Object.hasOwn(value.lobbies ?? {}, id) && !Object.hasOwn(legacyLobbyLabels, id)) || !labels || typeof labels !== 'object' || Array.isArray(labels) || Object.values(labels).some(label => typeof label !== 'string')) throw new Error('无效的区服名称：' + id);
    }
    const defaults = value.connection?.languageRegions;
    if (defaults !== undefined && (!defaults || typeof defaults !== 'object' || Array.isArray(defaults) || Object.entries(defaults).some(([language, id]) => !lobbyLanguages.includes(language) || typeof id !== 'string' || !Object.hasOwn(value.lobbies ?? {}, id) || !value.lobbies[id]))) throw new Error('语言默认跳转必须选择已配置的区服');
    for (const input of form.elements) {
        if (!input.name) continue;
        const field = input.name.split('.').reduce((parent, key) => parent?.[key], value);
        if (field !== undefined && typeof field !== 'string') throw new Error(input.name + ' 必须是字符串');
    }
    config = value;
    configEdited = false;
    for (const input of form.elements) if (input.name) input.value = input.name.split('.').reduce((parent, key) => parent?.[key], config) ?? '';
    renderLobbies(value);
    renderMapChoices(value.integration?.retainedMaps ?? []);
    if (persisted) rememberSaved();
    changed();
}

function rememberSaved() {
    saved = JSON.stringify(readConfig());
    savedProfileName = $('#profile-name').value.trim();
    savedTarget = $('#target').value.trim();
}

function hasChanges() {
    return JSON.stringify(readConfigSafely()) !== saved || $('#profile-name').value.trim() !== savedProfileName || $('#target').value.trim() !== savedTarget;
}

function renderMapChoices(selected = mapChoices.filter(choice => choice.input.checked).map(choice => choice.map)) {
    $('#retained-maps').replaceChildren();
    mapChoices = [...new Set([...availableMaps, ...selected])].map(map => {
        const label = document.createElement('label'), input = document.createElement('input'), text = document.createElement('span');
        input.type = 'checkbox';
        input.checked = selected.includes(map);
        input.disabled = busy;
        text.textContent = map + (availableMaps.includes(map) ? '' : '（原始文件中未找到）');
        input.addEventListener('change', () => { configEdited = true; changed(); });
        label.append(input, text);
        $('#retained-maps').append(label);
        return { map, input };
    });
}

function renderMapsResult(result) {
    availableMaps = result.maps ?? [];
    renderMapChoices();
    $('#maps-hint').textContent = result.error ? '读取地图失败：' + result.error
        : availableMaps.length ? '从原始 addoninfo.txt 读取，可多选。修改后保存设置，再生成文件预览并应用。' : '原始 addoninfo.txt 中没有可选地图。';
    return !result.error;
}

async function refreshMaps() {
    if (!$('#target').value.trim() || !/^[a-z][a-z0-9_]*$/.test(form.elements.addon.value)) return;
    try {
        const result = await api('addon-maps', { target: $('#target').value, config: readConfig() });
        return renderMapsResult(result);
    } catch (error) {
        return renderMapsResult({ error: error.message });
    }
}

function invalidatePreview() {
    preview = null;
    $('#apply').disabled = true;
    $('#file-summary').textContent = '等待预览';
    $('#file-list').replaceChildren();
    $('#preview-hint').textContent = '配置或目标变化后，需要重新预览。';
}

function currentEmbedding() {
    const value = readConfigSafely();
    return embeddingState?.target === $('#target').value.trim() && embeddingState.addon === value?.addon ? embeddingState : null;
}

function renderEmbeddingState() {
    const embedding = currentEmbedding();
    const enabled = embedding?.enabled === true;
    const dirty = hasChanges();
    const locked = busy || !embedding || !projectState || dirty || needsConfiguration || embedding.encrypted || (enabled && !embedding.canDisable);
    const toggle = $('#embedding-toggle');
    const state = !embedding ? 'unknown' : enabled ? 'enabled' : 'disabled';
    toggle.dataset.state = state;
    $('main').dataset.platformState = state;
    toggle.disabled = locked;
    $('#embedding-toggle-state').textContent = embeddingAction !== null ? embeddingAction ? '正在开启…' : '正在关闭…'
        : busy && embedding ? '处理中…' : !embedding ? '检查后开启' : enabled ? '关闭平台' : '开启平台';
    toggle.title = !embedding ? '先打开并检查项目' : dirty ? '请先保存设置' : enabled ? '点击关闭平台并还原项目' : '点击开启平台功能';
    $('#embedding-hint').textContent = embedding?.reason || '';
    $('#embedding-hint').hidden = !embedding?.reason;
    $('#project-status').hidden = !!projectState && ['ready', 'uninitialized'].includes(projectState.state);
    renderSavedProjectState();
}

function changed() {
    invalidatePreview();
    invalidateProjectStatus();
    status('#project-name', config.addon || '尚未选择项目', 'idle');
    try {
        const value = readConfig();
        const isSaved = !hasChanges();
        status('#project-name', value.addon || '尚未选择项目', 'idle');
        $('#config-json').textContent = JSON.stringify(value, null, 2);
        status('#dirty-state', isSaved ? '配置已保存' : '配置有未保存的更改', isSaved ? 'saved' : 'draft');
        $('#save-config').disabled = busy || isSaved;
        status('#workspace-save-state', isSaved ? '配置已保存' : '配置未保存', isSaved ? 'saved' : 'draft');
        status('#overview-config-state', isSaved ? '已保存' : '未保存的草稿', isSaved ? 'saved' : 'draft');
    } catch (error) {
        $('#config-json').textContent = error.message;
        status('#dirty-state', '配置有误', 'error');
        status('#workspace-save-state', '配置有误', 'error');
        status('#overview-config-state', 'JSON 格式有误', 'error');
    }
    renderNextAction();
}

function configValid() {
    if (form.checkValidity()) return true;
    show('config');
    form.reportValidity();
    return false;
}

function setBusy(value) {
    busy = value;
    activity();
    $$('[data-action], #load-project, #refresh-project, #runtime-python, #preview, #save-config, #import-config, #target, #discover, #check-project, #saved-projects button, #open-other-project, [name="mode"], #config-form input, #config-form select, #config-form textarea, #add-lobby').forEach(control => { control.disabled = busy; });
    lobbyRows.forEach(row => { row.remove.disabled = busy || lobbyRows.length === 1; });
    $('#save-config').disabled = busy || !hasChanges();
    $('#delete-profile').disabled = busy || !profileId;
    for (const control of [$('#browse-directory'), $('#new-profile'), $('#profile-name'), $('#save-profile-as'), $('#refresh-maps'), ...mapChoices.map(choice => choice.input)]) control.disabled = busy;
    $('#apply').disabled = busy || !preview?.canApply;
    renderToolUpdate(toolUpdate);
    renderEmbeddingState();
    renderNextAction();
}

async function run(task) {
    try { await task(); }
    catch (error) { notify(error.message, true); recordUiError(error); }
}

function renderJob(job) {
    $('#task-log-card').hidden = !job;
    if (!job) return;
    const labels = { build: '构建 SDK', test: '脚本与 UI 测试', runtime: 'Lua 运行时测试', pack: '打包 SDK' };
    const states = { running: '运行中', succeeded: '成功', failed: '失败' };
    $('#job-status').textContent = labels[job.action] + ' · ' + states[job.status] + (job.exitCode !== null ? ' · 退出码 ' + job.exitCode : '');
    $('#job-status').dataset.state = job.status;
    const log = $('#job-log');
    const atBottom = log.scrollTop + log.clientHeight >= log.scrollHeight - 30;
    log.textContent = job.log.replace(/\x1b\[[0-9;]*m/g, '') || '任务启动中…';
    if (atBottom) log.scrollTop = log.scrollHeight;
    $('#job-summary').replaceChildren();
    for (const stage of job.report?.stages ?? []) {
        const item = document.createElement('span');
        item.textContent = stage.stage + ' · ' + ({ succeeded: '已完成', not_configured: '未配置，未执行' }[stage.status] || stage.status);
        $('#job-summary').append(item);
    }
}

function revealTaskLog() {
    show(consumerMode ? 'project' : 'release');
    $('#task-log-card').scrollIntoView({ block: 'start' });
}

async function refreshProjectStatus() {
    invalidateLoadedTarget($('#target').value);
    invalidateProjectStatus('正在检查项目…');
    let result;
    try {
        result = await api('project-status', { target: $('#target').value, config: readConfig() });
    } catch (error) {
        embeddingState = null;
        status('#project-status', '项目检查失败', 'error');
        status('#overview-project-state', '检查失败', 'error');
        $('#project-problem').textContent = error.message;
        $('#project-problem').hidden = false;
        renderNextAction();
        throw error;
    }
    return renderProjectStatus(result);
}

function renderProjectStatus(result) {
    projectState = result;
    embeddingState = result.embedding ? { ...result.embedding, target: $('#target').value.trim(), addon: readConfig().addon, encrypted: result.encrypted === true } : null;
    const labels = { ready: '平台已启用', encrypted: '旧版加密记录', 'needs-compile': '需要编译资源', 'needs-sync': '需要同步', 'encryption-conflict': '旧版加密记录有冲突', uninitialized: '平台未启用' };
    $('#project-status').textContent = labels[result.state];
    $('#project-status').dataset.state = result.state;
    status('#overview-project-state', labels[result.state] || '等待检查', result.state);
    $('#project-summary').textContent = (config.addon || '当前项目') + (result.version ? ' · 平台版本 ' + result.version : '');
    $('#project-problem').hidden = !result.error;
    $('#project-problem').textContent = result.error || '';
    renderEmbeddingState();
    renderNextAction();
    return result;
}

async function refresh() {
    const state = await api('state');
    renderToolUpdate(state.update);
    await api('diagnostics').then(renderDiagnostics).catch(() => {});
    renderSavedProjects(state.projects, state.profileId ?? state.target);
    toolVersion = state.version;
    consumerMode = state.consumer === true;
    $$('[data-maintainer]').forEach(element => { element.hidden = consumerMode; });
    $$('[data-consumer]').forEach(element => { element.hidden = !consumerMode; });
    $$('[data-action="build"], [data-action="test"], [data-action="runtime"], [data-action="pack"]').forEach(element => { element.hidden = consumerMode; });
    if (consumerMode) $('[data-section="project"]').append($('#task-log-card'));
    if (consumerMode && location.hash === '#release') show('project');
    $('#tool-location-label').textContent = consumerMode ? '工具目录' : '当前仓库';
    $('#tool-location-title').textContent = consumerMode ? '已安装的 SDK 工具与资源' : '独立 SDK 源码与工具';
    $('#config-storage-path').textContent = state.configPath || (state.workspace ? state.workspace.replace(/[\\/]$/, '') + '/projects.json' : '.studio/projects.json');
    $('#version').textContent = 'v' + state.version;
    $('#root-path').textContent = state.root;
    $('#build-status').textContent = state.built ? '构建产物已存在' : '等待首次构建';
    $('#build-status').dataset.state = state.built ? 'ready' : 'stale';
    status('#overview-build-state', state.built ? '构建产物可用' : '等待首次构建', state.built ? 'ready' : 'stale');
    const packages = $('#packages');
    packages.replaceChildren();
    if (!state.packages.length) packages.textContent = '尚无包产物。';
    for (const item of state.packages) {
        const row = document.createElement('div');
        row.className = 'package-row';
        const title = document.createElement('a');
        title.textContent = item.name;
        title.href = item.url;
        title.download = item.name;
        const file = document.createElement('code');
        file.textContent = item.path;
        row.append(title, file);
        packages.append(row);
    }
    return state;
}

async function pollJob() {
    if (polling) return;
    polling = true;
    try {
        let result;
        do {
            result = await api('job');
            renderJob(result.job);
            if (result.job?.status === 'running') await new Promise(resolve => setTimeout(resolve, 800));
        } while (result.job?.status === 'running');
        if (result.job) notify(result.job.status === 'succeeded' ? '任务已完成，可查看日志与产物。' : '任务失败，请查看日志。', result.job.status === 'failed');
        await refresh();
        await refreshProjectStatus().catch(() => {});
    } finally { polling = false; setBusy(false); }
}

$$('[data-page], [data-go]').forEach(button => button.addEventListener('click', () => show(button.dataset.page || button.dataset.go)));
$('#dismiss-notice')?.addEventListener('click', dismissNotice);
$('#notice').addEventListener('mouseenter', () => { noticeHovered = true; stopNoticeTimer(); });
$('#notice').addEventListener('mouseleave', () => { noticeHovered = false; scheduleNoticeDismiss(); });
$('#notice').addEventListener('focusin', () => { noticeFocused = true; stopNoticeTimer(); });
$('#notice').addEventListener('focusout', event => {
    noticeFocused = $('#notice').contains(event.relatedTarget);
    scheduleNoticeDismiss();
});
window.addEventListener('hashchange', () => { if (titles[location.hash.slice(1)]) show(location.hash.slice(1)); });
form.addEventListener('submit', event => event.preventDefault());
form.addEventListener('input', () => {
    configEdited = true;
    syncLobbyChoices();
    if (!consumerMode && $('#target').value.startsWith('.studio/projects/')) $('#target').value = '.studio/projects/' + (form.elements.addon.value || 'my_game');
    changed();
});
$('#target').addEventListener('input', () => {
    configEdited = true;
    availableMaps = [];
    renderMapChoices();
    openedTarget = '';
    projectOpenError = '';
    invalidatePreview();
    invalidateProjectStatus('点击“打开项目”以继续');
    setBusy(busy);
    localStorage.setItem('sdk-studio-target', $('#target').value);
});
$$('[name="mode"]').forEach(input => input.addEventListener('change', invalidatePreview));
async function saveProfile(createNew = false) {
    if (busy || !configValid()) return;
    const value = readConfig();
    invalidateLoadedTarget($('#target').value);
    loadedProfiles.delete(profileId);
    setBusy(true);
    try {
        let name = $('#profile-name').value.trim() || value.displayName.schinese;
        if (createNew && name === savedProfileName) name += '（副本）';
        const result = await api('config', { config: value, target: $('#target').value, profileId, name, createNew });
        profileSourceSignature = null;
        profileId = result.profileId ?? profileId;
        $('#profile-name').value = result.profileName || name;
        rememberSaved();
        configEdited = false;
        configTarget = $('#target').value.trim();
        renderSavedProjects(result.projects);
        needsConfiguration = false;
        changed();
        if (openedTarget && openedTarget === $('#target').value.trim()) await refreshProjectStatus();
        notify(createNew ? '已另存为新配置。' : '配置已保存。');
    } finally { setBusy(false); }
}
$('#save-config').addEventListener('click', () => run(() => saveProfile()));
$('#save-profile-as').addEventListener('click', () => run(() => saveProfile(true)));
$('#profile-name').addEventListener('input', () => { configEdited = true; changed(); });
$('#refresh-maps').addEventListener('click', () => run(async () => { if (busy) return; invalidateLoadedTarget($('#target').value); setBusy(true); try { await refreshMaps(); } finally { setBusy(false); } }));
$('#export-config').addEventListener('click', () => run(async () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(readConfig(), null, 2) + '\n'], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'platform.config.json';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}));
$('#import-config').addEventListener('click', () => $('#config-file').click());
$('#config-file').addEventListener('change', () => run(async () => {
    const file = $('#config-file').files[0];
    if (!file) return;
    if (file.size > 128000) throw new Error('配置文件过大');
    renderConfig(JSON.parse(await file.text()));
    configEdited = true;
    if (!consumerMode) $('#target').value = '.studio/projects/' + (config.addon || 'my_game');
    $('#config-file').value = '';
    notify('配置已导入，检查后可保存。');
}));
$('#preview').addEventListener('click', () => run(async () => {
    if (busy || !configValid()) return;
    setBusy(true);
    invalidatePreview();
    try {
        preview = await api('preview', { mode: consumerMode && projectState?.embedding?.enabled ? 'sync' : $('[name="mode"]:checked').value, target: $('#target').value, config: readConfig() });
        $('#file-summary').textContent = preview.files.length + ' 个待写入 · ' + preview.skippedMaps.length + ' 张地图保留';
        $('#preview-hint').textContent = preview.canApply ? '目标：' + preview.target + '。已有文件标为覆盖，请核对后生成。' : '只读预览：' + preview.restriction;
        $('#file-list').replaceChildren();
        for (const item of [...preview.files, ...preview.skippedMaps.map(file => ({ file, action: 'keep' }))]) {
            const row = document.createElement('div');
            const badge = document.createElement('span');
            badge.className = 'file-action ' + item.action;
            badge.textContent = { create: '新增', update: '覆盖', remove: '移除', keep: '保留' }[item.action];
            const name = document.createElement('code');
            name.textContent = item.file;
            row.append(badge, name);
            $('#file-list').append(row);
        }
        notify('预览完成，尚未写入目标文件。');
    } finally { setBusy(false); }
}));
$('#apply').addEventListener('click', () => run(async () => {
    if (!preview || busy) return;
    invalidateLoadedTarget($('#target').value);
    setBusy(true);
    try {
        const result = await api('apply', { signature: preview.signature });
        invalidatePreview();
        await refreshProjectStatus();
        notify('已生成 ' + result.files.length + ' 个文件：' + result.target);
    } finally { setBusy(false); }
}));
$$('[data-action]').forEach(button => button.addEventListener('click', () => run(async () => {
    if (busy) return;
    const action = button.dataset.action;
    loadedProfiles.clear();
    setBusy(true);
    invalidatePreview();
    try {
        renderJob(await api('jobs', { action, ...(action === 'runtime' ? { python: $('#runtime-python').value.trim() } : {}) }));
        revealTaskLog();
        await pollJob();
    } catch (error) { setBusy(false); throw error; }
})));

function checklist(selector, items) {
    for (const text of items) {
        const label = document.createElement('label');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        const description = document.createElement('span');
        description.textContent = text;
        label.append(checkbox, description);
        $(selector).append(label);
    }
}
checklist('#integration-checklist', [
    '在 Workshop Tools 中挂载 content/<addon> 与 game/<addon>，地图有修改时重新编译 platform_entry 和 platform_lobby。',
    '使用项目自己的流程完成构建及可选加密，再预览接入平台；接入完成后打包发布。',
    '使用恢复功能前先预览；原始入口保存在项目 .eom-platform 目录，需保留该目录以便升级与恢复。',
    '服务机在服务端初始化前注入 PlatformLobbyConfig（url、token、addon）；真实 token 仅保存在服务机。',
]);
checklist('#runtime-checklist', [
    '使用 dota_launch_custom_game <addon> platform_entry 启动，检查已配置大厅和自动连接策略。',
    '验证可信大厅的 Steam 身份、创建房间、成员和聊天功能。',
    '验证开始与取消匹配、比赛启动、房间恢复与比赛重连。',
    '验证平台地图的选队保护，以及战斗地图的原玩法与加载画面。',
    '验证比赛服拒绝非房间成员，进服票据与身份校验有效。',
]);
show(titles[location.hash.slice(1)] ? location.hash.slice(1) : 'overview', false);
run(async () => {
    setBusy(true);
    try {
        const state = await refresh();
        profileId = state.profileId ?? null;
        profileSourceSignature = profileSignature(state);
        $('#profile-name').value = state.profileName || '';
        const rememberedTarget = state.profileId ? state.target : state.target || localStorage.getItem('sdk-studio-target');
        $('#target').value = rememberedTarget && (!consumerMode || /^(?:[a-z]:[\\/]|[\\/])/i.test(rememberedTarget)) ? rememberedTarget : consumerMode ? '' : '.studio/projects/' + (config.addon || 'my_game');
        renderConfig(state.config, state.configSaved);
        invalidateProjectStatus($('#target').value ? '正在打开项目…' : '尚未打开项目');
        if (consumerMode) {
            $('#target').placeholder = '填写游戏项目的绝对路径，例如 E:/Repository/my_game';
            $('[name="mode"][value="install"]').checked = true;
        }
        renderJob(state.job);
        if (state.job?.status === 'running') {
            revealTaskLog();
            await pollJob();
        } else if ($('#target').value && (state.target || rememberedTarget)) await openProject().catch(error => { projectOpenError = error.message; renderNextAction(); });
    } finally { setBusy(false); }
});
$('#discover').addEventListener('click', () => run(async () => {
    if (busy) return;
    setBusy(true);
    try {
        const result = await api('discover', { target: $('#target').value });
        if (result.addons.length === 1) {
            const addon = result.addons[0];
            form.elements.addon.value = addon.addon;
            form.elements['integration.serverEntry'].value = addon.serverEntry;
            form.elements['integration.clientEntry'].value = addon.clientEntry;
            config.integration ??= {};
            config.integration.layout = addon.layout;
            changed();
        }
        notify('发现 Addon：' + result.addons.map(item => item.addon).join('、') + '。可用构建命令：' + Object.keys(result.scripts).join('、') + '。请在配置中选择构建命令。');
    } finally { setBusy(false); }
}));
$('#check-project').addEventListener('click', () => run(async () => {
    if (busy || !configValid()) return;
    setBusy(true);
    try {
        const result = await api('check', { target: $('#target').value, config: readConfig() });
        notify('接入检查通过：' + result.checked + ' 个文件。游戏内流程仍需实测。');
    } finally { setBusy(false); }
}));
function confirmDisableChanges(files) {
    $('#disable-confirm-message').textContent = '检测到 ' + files.length + ' 个接入文件在开启后发生变化。继续关闭将丢弃这些变化，恢复原项目文件，并移除平台新增文件。';
    $('#disable-confirm-files').replaceChildren(...files.map(item => {
        const row = document.createElement('li');
        const change = document.createElement('span');
        change.textContent = ({ modified: '已修改', deleted: '已删除', created: '已新增' })[item.change] || '已变化';
        const file = document.createElement('code');
        file.textContent = item.file;
        row.append(change, file);
        return row;
    }));
    return new Promise(resolve => {
        disableConfirmation = resolve;
        $('#disable-confirm').showModal();
        $('#disable-confirm-cancel').focus();
    });
}

function finishDisableConfirmation(confirmed) {
    const resolve = disableConfirmation;
    if (!resolve) return;
    disableConfirmation = null;
    $('#disable-confirm').close();
    resolve(confirmed);
}

$('#disable-confirm-cancel').addEventListener('click', () => finishDisableConfirmation(false));
$('#disable-confirm-apply').addEventListener('click', () => finishDisableConfirmation(true));
$('#disable-confirm').addEventListener('cancel', event => { event.preventDefault(); finishDisableConfirmation(false); });
$('#disable-confirm').addEventListener('close', () => finishDisableConfirmation(false));

$('#embedding-toggle').addEventListener('click', () => run(async () => {
    const embedding = currentEmbedding();
    if (busy || $('#embedding-toggle').disabled || !embedding || !configValid()) return;
    const enabled = !embedding.enabled;
    embeddingAction = enabled;
    setBusy(true);
    invalidatePreview();
    try {
        await refreshProjectStatus();
        const current = projectState.embedding;
        if (current?.enabled === enabled) return;
        if (!current || projectState.encrypted || (!enabled && !current.canDisable)) throw new Error(current?.reason || '当前项目无法切换平台功能，请检查项目状态。');
        const planned = await api('embedding-preview', { target: $('#target').value, config: readConfig(), enabled });
        if (!planned.canApply) throw new Error(planned.restriction || '当前项目无法切换平台功能。');
        const needsConfirmation = !enabled && planned.changedFiles?.length > 0;
        if (needsConfirmation && !await confirmDisableChanges(planned.changedFiles)) return;
        const result = await api('embedding', { signature: planned.signature, ...(needsConfirmation ? { confirmDiscardChanges: true } : {}) });
        notify(enabled ? '平台已开启，已保存还原备份。' : '平台已关闭，原项目文件已还原。' + (result.retainedDirectories?.length ? ' 含新增内容的目录已保留。' : ''));
    } finally {
        await refreshProjectStatus().catch(() => {});
        embeddingAction = null;
        setBusy(false);
    }
}));

async function openProject(reloadFromProject = false, target = $('#target').value.trim(), selectedProfileId = profileId) {
    if (!target) { $('#target').focus(); return; }
    if (reloadFromProject) { invalidateLoadedTarget(target); profileSourceSignature = null; }
    if (configEdited && selectedProfileId !== profileId) {
        $('#target').value = configTarget;
        openedTarget = configTarget;
        show('config');
        notify('当前项目有未保存的修改，请先保存设置，再切换项目。', true);
        return;
    }
    projectOpenError = '';
    openedTarget = '';
    projectOpening = true;
    embeddingState = null;
    const preserve = !reloadFromProject && form.checkValidity() && (profileId || configEdited);
    const pending = preserve ? readConfig() : null;
    const previousSaved = { saved, savedProfileName, savedTarget, configEdited };
    setBusy(true);
    try {
        const result = await api('open-project', { target, reloadFromProject, profileId: selectedProfileId, ...(pending ? { config: pending } : {}) });
        openedTarget = result.target;
        configTarget = result.target;
        $('#target').value = result.target;
        profileId = result.profileId ?? selectedProfileId;
        if (!pending) $('#profile-name').value = result.profileName || '';
        renderSavedProjects(result.projects ?? savedProjects);
        availableMaps = [];
        needsConfiguration = !result.configured;
        if (result.configured) {
            renderConfig(result.config, true);
            if (pending) {
                saved = previousSaved.saved; savedProfileName = previousSaved.savedProfileName; savedTarget = previousSaved.savedTarget; configEdited = previousSaved.configEdited;
                changed();
            }
            renderProjectStatus(result.project);
        } else {
            const addon = result.discovery?.addons?.length === 1 ? result.discovery.addons[0] : null;
            renderConfig({ addon: addon?.addon || '', workshopId: '', displayName: { schinese: '', english: '', russian: '' }, lobbies: {}, integration: { mode: 'auto', ...(addon ? { layout: addon.layout, serverEntry: addon.serverEntry, clientEntry: addon.clientEntry } : {}) } });
            status('#project-status', '需要设置', 'stale');
            $('#project-summary').textContent = addon ? '已识别游戏目录：' + addon.addon : '项目尚无平台配置。';
        }
        localStorage.setItem('sdk-studio-target', $('#target').value);
        const mapsReady = result.mapResult ? renderMapsResult(result.mapResult) : await refreshMaps();
        if (mapsReady) rememberLoadedProfile();
    } catch (error) {
        projectOpenError = error.message;
        status('#project-status', '打开失败', 'error');
        renderNextAction();
        throw error;
    } finally { projectOpening = false; setBusy(false); }
}
async function browseDirectory() {
    if (busy) return;
    setBusy(true);
    let selected;
    try { selected = await api('browse-directory', { target: $('#target').value }); }
    finally { setBusy(false); }
    if (!selected.target) return;
    if ($('#target').value !== selected.target) configEdited = true;
    $('#target').value = selected.target;
    await openProject(false, selected.target);
}

function profileSignature(state) {
    return JSON.stringify([state.target || '', state.profileName || '', state.config]);
}

function invalidateLoadedTarget(target) {
    const key = value => value.replace(/\\/g, '/').replace(/\/$/, '').toLowerCase();
    for (const [id, view] of loadedProfiles) if (key(view.target) === key(target || '')) loadedProfiles.delete(id);
}

function rememberLoadedProfile() {
    if (!profileId || !profileSourceSignature || !projectState || projectState.error || needsConfiguration || hasChanges()) return;
    loadedProfiles.set(profileId, JSON.parse(JSON.stringify({ signature: profileSourceSignature, target: openedTarget,
        name: $('#profile-name').value, config: readConfig(), project: projectState, maps: availableMaps, mapsHint: $('#maps-hint').textContent })));
}

function restoreLoadedProfile(id, view) {
    const snapshot = JSON.parse(JSON.stringify(view));
    profileId = id;
    profileSourceSignature = snapshot.signature;
    $('#profile-name').value = snapshot.name;
    $('#target').value = configTarget = openedTarget = snapshot.target;
    projectOpenError = '';
    projectOpening = false;
    needsConfiguration = false;
    embeddingState = null;
    availableMaps = snapshot.maps;
    renderConfig(snapshot.config, true);
    renderSavedProjects(savedProjects);
    renderProjectStatus(snapshot.project);
    $('#maps-hint').textContent = snapshot.mapsHint;
    localStorage.setItem('sdk-studio-target', snapshot.target);
}

function requestProfileSelection(id, version) {
    const request = () => version === profileSelectionVersion ? api('select-profile', { profileId: id }) : null;
    const pending = profileSelection ? profileSelection.catch(() => {}).then(request) : request();
    profileSelection = Promise.resolve(pending);
    const current = profileSelection;
    current.finally(() => { if (profileSelection === current) profileSelection = null; }).catch(() => {});
    return current;
}

async function selectProfile(id) {
    if (configEdited && hasChanges()) { notify('当前配置有未保存的修改，请先保存设置，再切换配置。', true); return; }
    const version = ++profileSelectionVersion;
    const cached = loadedProfiles.get(id);
    if (cached) restoreLoadedProfile(id, cached);
    else setBusy(true);
    try {
        const state = await requestProfileSelection(id, version);
        if (!state || version !== profileSelectionVersion) return;
        const signature = profileSignature(state);
        if (cached && signature === cached.signature) { renderSavedProjects(state.projects); return; }
        loadedProfiles.delete(id);
        if (cached && hasChanges()) return;
        profileSourceSignature = signature;
        profileId = state.profileId;
        $('#profile-name').value = state.profileName;
        $('#target').value = state.target || '';
        configTarget = state.target || '';
        openedTarget = '';
        availableMaps = [];
        renderConfig(state.config, true);
        renderSavedProjects(state.projects);
        if ($('#target').value && !(cached && busy)) await openProject();
    } catch (error) {
        if (version !== profileSelectionVersion) return;
        loadedProfiles.delete(id);
        embeddingState = null;
        invalidateProjectStatus('配置切换失败，请重试');
        throw error;
    } finally { if (!cached && version === profileSelectionVersion) setBusy(false); }
}

function startNewProfile() {
    profileId = null;
    profileSelectionVersion++;
    profileSourceSignature = null;
    $('#profile-name').value = '';
    $('#target').value = '';
    configTarget = ''; openedTarget = ''; saved = ''; availableMaps = [];
    embeddingState = null;
    projectOpenError = '';
    projectOpening = false;
    needsConfiguration = true;
    renderConfig({ addon: '', workshopId: '', displayName: { schinese: '', english: '', russian: '' }, lobbies: {}, integration: { mode: 'auto' } });
    renderSavedProjects(savedProjects);
    show('config');
    $('#profile-name').focus();
    localStorage.setItem('sdk-studio-target', '');
}

function confirmDeleteProfile(project) {
    $('#delete-profile-confirm-message').textContent = '确定删除配置“' + project.name + '”？'
        + (project.target ? '项目目录：' + project.target + '。' : '')
        + '仅删除助手中的配置存档，游戏项目文件和平台接入状态保持不变。'
        + (hasChanges() ? '当前未保存的修改也将丢弃。' : '');
    return new Promise(resolve => {
        deleteProfileConfirmation = resolve;
        $('#delete-profile-confirm').showModal();
        $('#delete-profile-cancel').focus();
    });
}

function finishDeleteProfileConfirmation(confirmed) {
    if (!deleteProfileConfirmation) return;
    const resolve = deleteProfileConfirmation;
    deleteProfileConfirmation = null;
    $('#delete-profile-confirm').close();
    resolve(confirmed);
}

async function deleteProfile() {
    if (busy || !profileId) return;
    const project = savedProjects.find(item => item.id === profileId);
    if (!project) return;
    setBusy(true);
    try {
        if (profileSelection) await profileSelection;
        if (!await confirmDeleteProfile(project)) return;
        const state = await api('delete-profile', { profileId: project.id });
        profileSelectionVersion++;
        loadedProfiles.delete(project.id);
        loadedProfiles.delete(state.profileId);
        profileSourceSignature = state.profileId ? profileSignature(state) : null;
        profileId = state.profileId;
        renderSavedProjects(state.projects);
        if (!profileId) startNewProfile();
        else {
            $('#profile-name').value = state.profileName;
            $('#target').value = configTarget = state.target || '';
            openedTarget = '';
            availableMaps = [];
            embeddingState = null;
            projectOpenError = '';
            needsConfiguration = false;
            renderConfig(state.config, true);
            localStorage.setItem('sdk-studio-target', $('#target').value);
            if (state.target) {
                try { await openProject(); }
                catch (error) {
                    notify('已删除配置“' + project.name + '”，但下一配置的项目未能打开：' + error.message, true);
                    recordUiError(error);
                    return;
                }
            }
        }
        notify('已删除配置“' + project.name + '”。');
    } finally { setBusy(false); }
}

$('#delete-profile').addEventListener('click', () => run(deleteProfile));
$('#delete-profile-cancel').addEventListener('click', () => finishDeleteProfileConfirmation(false));
$('#delete-profile-apply').addEventListener('click', () => finishDeleteProfileConfirmation(true));
$('#delete-profile-confirm').addEventListener('cancel', event => { event.preventDefault(); finishDeleteProfileConfirmation(false); });
$('#delete-profile-confirm').addEventListener('close', () => finishDeleteProfileConfirmation(false));

$('#new-profile').addEventListener('click', () => {
    if (busy) return;
    if (configEdited && hasChanges()) { notify('当前配置有未保存的修改，请先保存设置，再新建配置。', true); return; }
    startNewProfile();
});
$('#browse-directory').addEventListener('click', () => run(browseDirectory));
$('#open-other-project').addEventListener('click', () => run(browseDirectory));
$('#load-project').addEventListener('click', () => run(() => busy ? undefined : openProject(true)));
$('#target').addEventListener('keydown', event => { if (event.key === 'Enter' && !busy) run(openProject); });
$('#next-action').addEventListener('click', () => run(async () => {
    if (busy) return;
    if (nextAction === 'open') return openProject();
    if (nextAction === 'config' || nextAction === 'project') { show(nextAction); return; }
}));
$('#refresh-project').addEventListener('click', () => run(async () => {
    if (busy || !configValid()) return;
    setBusy(true);
    try {
        const result = await refreshProjectStatus();
        notify(result.error || (result.installed ? '项目接入检查通过。' : '项目尚未接入 SDK。'), !!result.error);
    } finally { setBusy(false); }
}));

function renderToolUpdate(value = toolUpdate) {
    toolUpdate = value || { enabled: false, status: 'unconfigured', message: '尚未配置在线更新服务' };
    const active = busy || ['checking', 'downloading', 'installing', 'restarting'].includes(toolUpdate.status);
    $('#tool-update-status').textContent = toolUpdate.message;
    $('#tool-update-check').disabled = active || !toolUpdate.enabled;
    $('#tool-update-install').hidden = toolUpdate.status !== 'available';
    $('#tool-update-install').disabled = active;
    $('#tool-update-restart').hidden = toolUpdate.status !== 'ready';
    $('#tool-update-restart').disabled = active;
    const progress = $('#tool-update-progress');
    progress.hidden = !['downloading', 'installing'].includes(toolUpdate.status);
    progress.max = toolUpdate.total || 1;
    progress.value = toolUpdate.downloaded || 0;
}

async function checkToolUpdate() {
    if (busy) return;
    setBusy(true);
    try { renderToolUpdate(await api('update/check', {})); }
    finally { await api('update').then(renderToolUpdate).catch(() => {}); setBusy(false); }
}

async function installToolUpdate() {
    if (busy || toolUpdate.status !== 'available') return;
    setBusy(true);
    const version = toolUpdate.availableVersion;
    const timer = setInterval(() => api('update').then(renderToolUpdate).catch(() => {}), 500);
    try { renderToolUpdate(await api('update/install', { version })); }
    finally { clearInterval(timer); await api('update').then(renderToolUpdate).catch(() => {}); setBusy(false); }
}

async function restartToolUpdate() {
    if (busy || toolUpdate.status !== 'ready') return;
    if (configEdited && hasChanges()) { notify('请先保存项目设置，再重启应用。', true); return; }
    setBusy(true);
    const before = $('meta[name="studio-token"]').content;
    try {
        renderToolUpdate(await api('update/restart', {}));
        for (let attempt = 0; attempt < 75; attempt++) {
            await new Promise(resolve => setTimeout(resolve, 400));
            try {
                const response = await fetch('/', { cache: 'no-store', signal: AbortSignal.timeout(1000) });
                const token = /name="studio-token" content="([a-f0-9]{64})"/.exec(await response.text())?.[1];
                if (response.ok && token && token !== before) { window.location.reload(); return; }
            } catch { /* The old server closes before the new version starts. */ }
        }
        throw new Error('应用尚未恢复，请关闭并重新打开接入助手。');
    } finally { setBusy(false); }
}

$('#tool-update-check').addEventListener('click', () => run(checkToolUpdate));
$('#tool-update-install').addEventListener('click', () => run(installToolUpdate));
$('#tool-update-restart').addEventListener('click', () => run(restartToolUpdate));

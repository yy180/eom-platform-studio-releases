if _G.debug == nil then _G.debug = {} end; if _G.debug.traceback == nil then _G.debug.traceback = function(message) if message == nil then return "" end return tostring(message) end end; if _G.debug.getinfo == nil then _G.debug.getinfo = function(level, options) if level == 1 and options == nil then return {source = "", what = "", short_src = ""} end return nil end end; local __TSTL_FILE_PATH__ = "addon_game_mode_client"; local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 2,["7"] = 3,["8"] = 5,["9"] = 6,["10"] = 7,["13"] = 8,["16"] = 9,["17"] = 10,["18"] = 11,["21"] = 12,["22"] = 13,["23"] = 14,["24"] = 15,["25"] = 6,["26"] = 18,["27"] = 19});
---
-- @noSelfInFile *
platformClientModule = "eom_platform.client"
require(platformClientModule)
tuiEntryConnectionStarted = false
function ConnectTuiEntryLobby()
    if tuiEntryConnectionStarted or GetMapName() ~= "platform_entry" and GetMapName() ~= "maps/platform_entry.vpk" then
        return
    end
    -- if GameRules:State_Get() < DOTA_GAMERULES_STATE_CUSTOM_GAME_SETUP then
    --     return
    -- end
    local routing = LoadKeyValues("scripts/platform_routing.txt")
    local address = routing and routing.lobby_address
    if type(address) ~= "string" or (string.match(address, "^[%w%.%-]+:%d+$")) == nil then
        return
    end
    tuiEntryConnectionStarted = true
    print("[platform] TUI entry: connect " .. address)
    SendToConsole("password \"\"")
    SendToConsole("connect " .. address)
end
ListenToGameEvent("game_rules_state_change", ConnectTuiEntryLobby, nil)
ConnectTuiEntryLobby()

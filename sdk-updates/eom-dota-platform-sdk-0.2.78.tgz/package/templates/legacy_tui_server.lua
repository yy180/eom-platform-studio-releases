if _G.debug == nil then _G.debug = {} end; if _G.debug.traceback == nil then _G.debug.traceback = function(message) if message == nil then return "" end return tostring(message) end end; if _G.debug.getinfo == nil then _G.debug.getinfo = function(level, options) if level == 1 and options == nil then return {source = "", what = "", short_src = ""} end return nil end end; local __TSTL_FILE_PATH__ = "addon_game_mode"; local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 2,["7"] = 4,["8"] = 5,["9"] = 6,["11"] = 8,["13"] = 11,["14"] = 12,["15"] = 13,["17"] = 15,["19"] = 11,["20"] = 19,["21"] = 20,["22"] = 20,["24"] = 19,["25"] = 23,["26"] = 24,["27"] = 24,["29"] = 23});
---
-- @noSelfInFile *
isPlatformMap = GetMapName() == "platform_entry" or GetMapName() == "platform_lobby"
if isPlatformMap then
    local moduleName = "eom_platform.server"
    platformRuntime = require(moduleName)
else
    require("addon_game_mode_battle")
end
function Activate()
    if isPlatformMap then
        platformRuntime.ActivatePlatform()
    else
        ActivateBattle()
    end
end
function Precache(context)
    if not isPlatformMap then
        PrecacheBattle(context)
    end
end
function SpawnGroupPrecache(group, context)
    if not isPlatformMap then
        SpawnGroupPrecacheBattle(group, context)
    end
end

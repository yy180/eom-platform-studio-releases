local map = GetMapName()
local platform = map == 'platform_entry' or map == 'platform_lobby'
local runtime
if platform then
    runtime = require('eom_platform.server')
else
    local config = LoadKeyValues('scripts/eom_platform.txt')
    if config and config.battle_server and config.battle_server ~= '' then
        require(config.battle_server)
    end
end

function Activate()
    if platform then
        runtime.ActivatePlatform()
    elseif ActivateBattle then
        ActivateBattle()
    end
end

function Precache(context)
    if not platform and PrecacheBattle then PrecacheBattle(context) end
end

function SpawnGroupPrecache(group, context)
    if not platform and SpawnGroupPrecacheBattle then SpawnGroupPrecacheBattle(group, context) end
end

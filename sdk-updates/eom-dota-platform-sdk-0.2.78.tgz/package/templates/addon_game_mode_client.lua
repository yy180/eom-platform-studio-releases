require('eom_platform.client').Initialize()
